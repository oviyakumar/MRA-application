# StoresInventoryReceiving.Mobile.Test



To get Started 

1. Install Node.js and appium from http://www.automationtestinghub.com/download-and-install-appium-1-6/ (follow the document-Steps to Install Appium server)

2. Ensure or Install java 8.

3. Download android studio from https://developer.android.com/studio/index.html (follow the document for installation > Android Studio Installation)
   Refer the URL
   https://www.javaworld.com/article/3095406/android-studio-for-beginners-part-1-installation-and-setup.html
   https://www.javaworld.com/article/3104622/android-studio-for-beginners-part-3-build-and-run-the-app.html

4. Set ANDROID_HOME to your Appium configuration Environment Variables
  For example Android_Home C:\Users\hkaur1\AppData\Local\Android\Sdk

5. Download maven from https://maven.apache.org/download.cgi
and add to classpath

6. Clone repository
	 https://github.wsgc.com/Stores-IT/StoresInventoryReceiving.Mobile.Test/tree/test_features
    
7. Import maven project in eclipse

8. Download the latest build of MRA application from Hockey App website and save in  location  "C:\dev\wsi\apk" (don't change the location)

	https://rink.hockeyapp.net/apps/634a37b031a14a5faa9a7c538c6a0fdd

#development

1. Update maven project
   right click on project > maven> update project
2. Add Page class in package "com.pdt.POM"  
3. Add TestNG tests in  package "com.pdt, "com.pdt"

#Create emulator
 1.Lauch Android studio
 2.	Click Tools >AVD Manager and click  Create New Virtual Device 
 3.	Select Phone > 4.7” WXGA with size- 4.7” and  resolution 720*1280 and xhdpi
 4.	Click Next 
 5. Download Nougat >Android 7.1.1x86
 6. Set the AVD Name as Honeywell 
 
 #Capabilities For opening MRA App in Emulator through appium server
 {
  "platformName": "Android",
  "deviceName": "pdt",
  "app": "C:\\\\dev\\\\wsi\\\\apk\\\\com.si-Signed.apk"
}
Note: Please install the latest version of MRA app's apk file and place it in the below mentioned location
"C:\\\\dev\\\\wsi\\\\apk\\\\com.si-Signed.apk"
 
 
 

#Running tests
 
1. Run project as maven test
	``` mvn clean test```

