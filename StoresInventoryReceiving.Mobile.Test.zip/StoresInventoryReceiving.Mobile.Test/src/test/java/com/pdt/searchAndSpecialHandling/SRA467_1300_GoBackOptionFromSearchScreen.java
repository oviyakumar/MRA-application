package com.pdt.searchAndSpecialHandling;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.GlobalSearchPage;
import com.pdt.Pom.LoginPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validating the Transfer number search in Global search")
@Description("Validating the Transfer number search in Global search")

public class SRA467_1300_GoBackOptionFromSearchScreen extends BaseTest {

	public void SRA1300_GoBackFromGlobalSearchToVariousScreens() {

		LoginPage login = new LoginPage();

		GlobalSearchPage globalSearch = new GlobalSearchPage();

		login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));
		globalSearch.validateHomePageDisplayed();
		globalSearch.validateAuditingPageDisplayed();
		globalSearch.validateInStoreDamagesDisplayed();
		globalSearch.validateAddDamagedSkuPageDisplayed();

	}

}
