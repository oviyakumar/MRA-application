package com.pdt.searchAndSpecialHandling;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.GlobalSearchPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validates the GoBack Button in Global Search of PO and Transfer ")
@Description("Validates the GoBack Button in Global Search of PO and Transfer")

public class SRA1392_ValidatesTheGoBackButtonInPoAndTransfer extends BaseTest{
	
	public void SRA1392_ValidateTheGoBackButton_InGlobalSearchForPO() throws IOException, ParseException {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();

		GlobalSearchPage globalSearchPage = new GlobalSearchPage();

		Document doc = createDocFromFile("PO135.json");

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("ETADateTime", ExpectedArrival);

		updateDocInPOCollection(doc);
		login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		homescreen.clickOnReceiving();

		receivingPage.clickOnStoreToStoreTransfer();

		sendnReceivetransfer.clickOnSendStoreTransfer();

		globalSearchPage.validateGoBackSearchInGlobalSearchForPO(getProperty("PONumberpo20931847"));

	}
	
	public void SRA1392_ValidateTheGoBackButton_InGlobalSearchForTransfer() throws IOException, ParseException {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();

		GlobalSearchPage globalSearchPage = new GlobalSearchPage();

		Document doc = createDocFromFile("StoreSRA706.json");

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 1);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("ETADateTime", ExpectedArrival);

		updateDocToStoreTransferDb(doc);

		
		login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		homescreen.clickOnReceiving();

		receivingPage.clickOnStoreToStoreTransfer();

		sendnReceivetransfer.clickOnSendStoreTransfer();

		globalSearchPage.validateGoBackSearchInGlobalSearchForTransferNo(getProperty("transferNumber200452"));

	}
	

	
	

}
