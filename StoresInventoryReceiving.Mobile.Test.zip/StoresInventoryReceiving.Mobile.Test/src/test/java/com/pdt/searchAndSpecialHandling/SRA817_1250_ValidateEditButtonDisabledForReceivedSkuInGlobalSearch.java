package com.pdt.searchAndSpecialHandling;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "To Validate the received transfer/sku cannot be edited")
@Description("To Validate the received transfer/sku cannot be edited")

//By Harmeet

public class SRA817_1250_ValidateEditButtonDisabledForReceivedSkuInGlobalSearch extends BaseTest {
	final static Logger logger = Logger.getLogger(SRA817_1250_ValidateEditButtonDisabledForReceivedSkuInGlobalSearch.class.getName());

	public void SRA817_ValidateEditButtonDisabledForReceivedSkuInGlobalSearch() throws IOException, ParseException {

			LoginPage login = new LoginPage();
			HomePage homeScreen = new HomePage();
			ReceivingPage receivingPage = new ReceivingPage();
			SendAndReceiveTransferPage sendnReceiveTransfer = new SendAndReceiveTransferPage();
			ReceivingTransferPage receivingTransferPage = new ReceivingTransferPage();

			Document doc = createDocFromFile("SRA582Transfer.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			updateDocToStoreTransferDb(doc);
			
			String transferNumber = doc.getString("TransferNumber");
			logger.info("Transfer Number is -------"+transferNumber);
			String storeNumber = doc.getString("DestinationStoreNumber");

			// login as storeNo: 104
			login.loginInMRA(storeNumber, getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			homeScreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendnReceiveTransfer.clickOnReceiveStoreTransfer();

			receivingTransferPage.submitTheStoreTransferInReceiving(transferNumber,"5");
			receivingTransferPage.validateReceivedTransferCannotBeEditedInGlobalSearch(transferNumber);

	}
	
	
}
