package com.pdt.searchAndSpecialHandling;

import static com.util.BaseUtil.getDateDecreaseDay;
import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.GlobalSearchPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "To Validate the orphan carton/Sku search in global search Screen")
@Description("To Validate the orphan carton/Sku search in global search Screen")

public class SRA1632_1597_SearchForOrphanCartonInGlobalSearch extends BaseTest {
	final static Logger logger = Logger
			.getLogger(SRA1632_1597_SearchForOrphanCartonInGlobalSearch.class.getName());

	public void SRA1632_SearchForOrphanCartonWithSkus() throws IOException, ParseException, InterruptedException {
		SoftAssert assertion = new SoftAssert();
		
		LoginPage login = new LoginPage();
		HomePage homeScreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		

		GlobalSearchPage globalSearch = new GlobalSearchPage();

		Document doc = createDocFromFile("OrphanCarton_withSkus.json");
		updateDocInOrphanCartonCollection(doc);

		logger.info("Added  a record in orphan carton collection");

		login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));

//		homeScreen.clickOnReceiving();
//		receivingPage.clickOnDcShipment();
//		receivingShipmentScanPage.scanAndSubmitOrphanCartonWithoutSkus("1111115151854R");
		globalSearch.validateDetailsofOrphanCartonWithSkus("1111115151854R");
		
//		globalSearch.validateCartonAndETA(getProperty("cartonNumber1111232526213"), assertion);
//		logger.info("Carton and ETA validated");
//
//		globalSearch.markSpecialHandlingForCarton(getProperty("cartonNumber1111232526213"), assertion);

	}

	
}
