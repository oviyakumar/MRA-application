package com.pdt.searchAndSpecialHandling;

import static com.util.BaseUtil.getDateDecreaseDay;
import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.GlobalSearchPage;
import com.pdt.Pom.LoginPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "Validating the special Handling in Global search for a carton")
@Description("Validating the special Handling in Global search for a carton")

public class SRA46_1404_SearchForCartonInGlobalSearchAndSetSpecialHandling extends BaseTest {
	final static Logger logger = Logger
			.getLogger(SRA46_1404_SearchForCartonInGlobalSearchAndSetSpecialHandling.class.getName());

	public void SRA1404_setSpecialHandlingForCartonInSearch() throws IOException, ParseException, InterruptedException {
		SoftAssert assertion = new SoftAssert();
		LoginPage login = new LoginPage();
		GlobalSearchPage globalSearch = new GlobalSearchPage();

		Document firstCarton = createDocFromFile("SRA46.json");
		SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrival = formatDate.parse(EtaDate);
		firstCarton.put("EtaDateTime", ExpectedArrival);
		updateDocToDb(firstCarton);
		logger.info("Added  a record in DC Shipment");

		login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		globalSearch.validateCartonAndETA(getProperty("cartonNumber1111232526213"), assertion);
		logger.info("Carton and ETA validated");

		globalSearch.markSpecialHandlingForCarton(getProperty("cartonNumber1111232526213"), assertion);

	}

	@SuppressWarnings("unchecked")
	public void SRA1404_setSpecialHandlingForCartonInSearchETAWithInLast30Days()
			throws IOException, ParseException, InterruptedException {

		SoftAssert assertion = new SoftAssert();
		LoginPage login = new LoginPage();
		GlobalSearchPage globalSearch = new GlobalSearchPage();

		Document firstCarton = createDocFromFile("SRA46_1.json");
		SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateDecreaseDay("yyyy-MM-dd", 29);
		Date ExpectedArrival = formatDate.parse(EtaDate);
		firstCarton.put("EtaDateTime", ExpectedArrival);
		updateDocToDb(firstCarton);
		logger.info("Added  a record in DC Shipment");

		String cartonNumber = ((List<Document>) firstCarton.get("Cartons")).get(0).getString("CartonNumber");
		logger.info("carton number is " + cartonNumber);
		
		login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		globalSearch.validateCartonAndETA(cartonNumber, assertion);
		logger.info("Carton and ETA validated");

		globalSearch.markSpecialHandlingForCarton(cartonNumber, assertion);

	}

	public void SRA1404_validateCartonDoesNotAppearForETAMoreThan30Days() throws IOException, ParseException {

		LoginPage login = new LoginPage();
		GlobalSearchPage globalSearch = new GlobalSearchPage();

		Document firstCarton = createDocFromFile("SRA46_2.json");
		SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateDecreaseDay("yyyy-MM-dd", 32);
		Date ExpectedArrival = formatDate.parse(EtaDate);
		firstCarton.put("EtaDateTime", ExpectedArrival);
		updateDocToDb(firstCarton);
		logger.info("Added  a record in DC Shipment");

		login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));

		globalSearch.markSpecialHandlingForCartonETAMoreThan365(getProperty("cartonNumber1111346526117"));

	}

	@SuppressWarnings("unchecked")
	public void SRA1404_validateReceivedCartonSearchableFor365Days() throws IOException, ParseException {

		LoginPage login = new LoginPage();
		GlobalSearchPage globalSearch = new GlobalSearchPage();

		Document firstCarton = createDocFromFile("SRA46_3.json");
		SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateDecreaseDay("yyyy-MM-dd", 364);
		Date ExpectedArrival = formatDate.parse(EtaDate);
		firstCarton.put("EtaDateTime", ExpectedArrival);
		updateDocToDb(firstCarton);

		logger.info("Added a scanned DC shipment record  in DC Shipment");
		
		
		String cartonNumber = ((List<Document>) firstCarton.get("Cartons")).get(0).getString("CartonNumber");
		logger.info("carton number is " + cartonNumber);

		login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));

		globalSearch.validateRecdCartonSearchableInGlobalSearchFor365Days(cartonNumber);

	}

}
