package com.pdt.searchAndSpecialHandling;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.GlobalSearchPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.PurchaseOrderPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validate tick and Dot Image is visible to  PO in Global Search")
@Description("Validate tick and Dot Image is visible to  PO in Global Search")

public class SRA1602_ValidateTickAndDotImageForPOInGlobalSearch extends BaseTest {

	final static Logger logger = Logger.getLogger("SRA1602_ValidateTickAndDotImageForPOInGlobalSearch");
	static  String FILEPATH=null;
	
	public void SRA1602_validateTickAndDotImageForPOInGlobalSearch() throws IOException, ParseException {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();
		GlobalSearchPage globalSearch = new GlobalSearchPage();

		Document doc = createDocFromFile("POwithSingleSku.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("ETADateTime", ExpectedArrival);
		updateDocInPOCollection(doc);

		String storeNumber = doc.getString("DestinationStoreNumber");
		String purchaseOrderNumber = doc.getString("PurchaseOrderNumber");
		logger.info("PO Number is " + purchaseOrderNumber);

		int shippedQty = ((List<Document>) doc.get("SKUs")).get(0).getInteger("ShippedQuantity");
		logger.info("shippedQty " + shippedQty);

		login.loginInMRA(storeNumber, this.getProperty("valid_username9792"), this.getProperty("valid_password9792"));
		globalSearch.enterPONumberInGlobalSearch(purchaseOrderNumber);

		FILEPATH=getImageFilePath("dot_image.PNG");
		Screen s = new Screen();
		Pattern pattern = new Pattern(FILEPATH);

		boolean found = false;
		if (s.exists(pattern) != null) {
			found = true;
			logger.info("Dot image found");
		}

		Assert.assertTrue(found);

		homescreen.clickOnMenuBar();
		homescreen.clickOnPurchaseOrdersOnSideMenuBar();

		purchaseOrderPage.editQuantityOfPOForCompletelyReceived(purchaseOrderNumber, String.valueOf(shippedQty));

		globalSearch.enterPONumberInGlobalSearch(purchaseOrderNumber);
		FILEPATH=getImageFilePath("tick_image.PNG");
		
		Pattern tickimagepattern = new Pattern(FILEPATH); 
		boolean foundtick = false;
		if (s.exists(tickimagepattern) != null) {
			foundtick = true;
			logger.info("Tick image found");
		}

		Assert.assertTrue(foundtick);
	}

}
