
package com.pdt.auditingMispicksTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.bson.Document;
import org.junit.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.MispicksScanPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "To validate online Vs offline state for mispicks")
@Description("To validate online Vs offline state for mispicks")

public class SRA801_1308_OnlineVSOfflineStateForMispicks extends BaseTest {

	public void SRA1308_validateMispickedCartonState_BeforeSubmitting()
			throws IOException, ParseException, ClassNotFoundException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {

		Document doc = createDocFromFile("Mispick801.json");

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);

		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("EtaDateTime", ExpectedArrival);

		updateDocToDb(doc);

		LoginPage login = new LoginPage();
		HomePage home = new HomePage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		AuditingPage auditingPage = new AuditingPage();
		MispicksScanPage mispicksScanPage = new MispicksScanPage();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();

		login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		homescreen.clickOnReceiving();
		receivingPage.clickOnDcShipment();

		receivingShipmentScanPage.addCartonAsReceived("0010411111345R");
		homescreen.clickOnMenuBar();
		homescreen.clickOnAuditingOnSideMenuBar();
		auditingPage.clickMispicks();
		mispicksScanPage.addMispickedCarton("0010411111345R");
		// Method to off wifi if it is on
		receiveStoreTransfer.wifi();
		mispicksScanPage.clickOnSubmitMispicksButton();
		String NetworkConnectivityErrorMessage = mispicksScanPage.getNetworkConnectivityMessage();
		Assert.assertEquals(NetworkConnectivityErrorMessage, "Network error. Please check connectivity and try again");
		mispicksScanPage.clickOkAndConnectAgain();
		receiveStoreTransfer.wifi();
		
		home.clickOnMenuBar();
		home.logout();

	}
}
