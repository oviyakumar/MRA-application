
package com.pdt.auditingMispicksTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.bson.Document;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.MispicksScanPage;
import com.pdt.Pom.ReceivingPage;

import com.pdt.Pom.ReceivingShipmentScanPage;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "To validate adding a Sku to scanned carton in the discrepancy carton detail page")
@Description("To validate adding a Sku to scanned carton in the discrepancy carton detail page")

public class SRA208_1309_AddSkuToDiscrepancyCartonDetailPage extends BaseTest {

	public void SRA1309_addValidSkuToDiscrepancyCartonDetailPage()
			throws IOException, ParseException, InterruptedException {
		SoftAssert softassert =new SoftAssert();
		HomePage homescreen = new HomePage();

			Document doc = createDocFromFile("Mispicks.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);

			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);

			updateDocToDb(doc);

			LoginPage login = new LoginPage();
			ReceivingPage receivingPage = new ReceivingPage();
			ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
			AuditingPage auditingPage = new AuditingPage();
			MispicksScanPage mispicksScanPage = new MispicksScanPage();
			ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();

			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnDcShipment();

			receivingShipmentScanPage.addCartonAsReceived("0010411111896R");
			homescreen.clickOnMenuBar();
			homescreen.clickOnAuditingOnSideMenuBar();
			auditingPage.clickMispicks();
			mispicksScanPage.addMispickedCarton("0010411111896R");

			// To validate error message while adding invalid sku
			mispicksScanPage.validateErrorMessageWhileAddingInValidSkuToCarton("112");

			// To validate error message while adding duplicate sku
			mispicksScanPage.validateErrorMessageWhileAddingDuplicateSkuToCarton(getProperty("sku7363391"));

			// To validate adding extra sku to the mispicked carton
			mispicksScanPage.validateAddingValidSkuToCarton(getProperty("sku1023998"),softassert);

			// To edit the Received qty for extra added sku and to validate if both the sku
			// number and edited qty gets updated in the DB
			mispicksScanPage.editReceivedSkuQtyForExtraAddedSku("3");

			validateFromMongoDB.getSkuDetailsForMispickedCarton("0010411111896R", getProperty("sku1023998"), softassert, "3",getProperty("valid_storeno104"));
			softassert.assertAll();
		}
}
