
package com.pdt.auditingMispicksTests;

import static com.util.BaseUtil.getDateDecreaseDay;
import static com.util.BaseUtil.getDateIncementDay;
import static com.util.BaseUtil.getTodayDate;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.Assert;
import org.testng.annotations.Ignore;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.MispicksScanPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "To validate adding an Orphan carton to the Mispicks Home Screen")
@Description("To validate adding an Orphan carton to the Mispicks Home Screen")

public class SRA1680_ToValidateMarkingOrphanCartonAsMispicks extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA_1680");

	
	public void SRA1680_ValidateAddingValidAndInvalidOrphanCartonsToMispicksScreen() throws IOException, ParseException, InterruptedException {

		    LoginPage login = new LoginPage();
		    
		    HomePage homescreen = new HomePage();
		    AuditingPage auditingPage = new AuditingPage();
		    MispicksScanPage mispicksScanPage = new MispicksScanPage();
		    ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
			ReceivingPage receivingPage = new ReceivingPage();
	
		    String orphanCartonNumber=null;
		    try {
		    			Document doc = createDocFromFile("OrphanCarton_withSkus.json");
		    			// updateDocInOrphanCartonCollection(doc);
		    			// logger.info("Added  a record in orphan carton collection");
		    			
		    			 orphanCartonNumber = doc.getString("CartonNumber");
		    			logger.info("orphanCartonNumber is " + orphanCartonNumber);
		    			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
		    					getProperty("valid_password9792"));

		    			homescreen.clickOnReceiving();
		    			receivingPage.clickOnDcShipment();
		    			receivingShipmentScanPage.addCartonAsScanned(orphanCartonNumber);
		    			homescreen.clickOnMenuBar();
		    			homescreen.clickOnAuditingOnSideMenuBar();
		    			auditingPage.clickMispicks();
		    			logger.info("To add a carton number which is scanned, but not submitted and to validate the error message");
		    			mispicksScanPage.addScannedCartonNumberToMispicksHomeScreen(orphanCartonNumber);
		    			homescreen.clickOnMenuBar();
		    			homescreen.clickOnDCShipmentsOnSideMenuBar();
		    			receivingShipmentScanPage.submitCartonAsReceived();
		    			homescreen.clickOnMenuBar();
		    			homescreen.clickOnAuditingOnSideMenuBar();
		    			auditingPage.clickMispicks();
		    			logger.info("To add a invalid carton number to Mispicks screen and to validate the error message");
		    			mispicksScanPage.addInvalidCartonNumberToMispicksHomeScreen("987654S");
		    			
		    			logger.info("To incorrectly enter last 4 digits of the carton and to validate the error message");
		    			mispicksScanPage.validateErrorMessageForEnteringInvalidFourDigitsForValidCarton(orphanCartonNumber);
		    			
		    			logger.info("To add a Valid carton number to the Mispicks home screen");
		    			mispicksScanPage.addValidCartonNumberToMispicksHomeScreen(orphanCartonNumber);
		    			
		    			
		    			logger.info("To add a Duplicate carton number to the Mispicks home screen and to validate the error message");
		    			mispicksScanPage.addDuplicateCartonNumberToMispicksHomeScreen(orphanCartonNumber);
		} 
		    finally {
				deleteOrphanCarton(orphanCartonNumber);
				}
		
	}

	
	public void SRA1680_ValidateAddingScannedOrphanCartonsToMispicksHomeScreen()
		throws IOException, ParseException {
		HomePage home=new HomePage();
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		AuditingPage auditingPage = new AuditingPage();
		MispicksScanPage mispicksScanPage = new MispicksScanPage();
		
		Document doc = createDocFromFile("OrphanCarton_withoutSkus.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String DecreasedDate = getDateDecreaseDay("yyyy-MM-dd", 6);
		Date UpdatedScannedDate = format.parse(DecreasedDate);
		logger.info("updated Scanned date is " + UpdatedScannedDate);

		logger.info("Change the scanned Time to T-5 days"); 
	    doc.put("ScannedTime", UpdatedScannedDate);
		doc.put("IsScanned", true);
		doc.put("ScannedBy", "9792");
		updateDocInOrphanCartonCollection(doc);
		
		String orphanCartonNumber = doc.getString("CartonNumber");
		logger.info("orphanCartonNumber is " + orphanCartonNumber);


		login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		
		homescreen.clickOnAuditing();
		auditingPage.clickMispicks();
		mispicksScanPage.addInvalidCartonNumberToMispicksHomeScreen(orphanCartonNumber);
		logger.info("Cartons scanned before 5 days are not added to Mispicks screen today");
		
		home.clickOnMenuBar();
		home.logout();
		logger.info("Logged out successfully");	
		
		String receivedDate = getDateDecreaseDay("yyyy-MM-dd", 3);
		Date UpdatedReceivedDate = format.parse(receivedDate);
		logger.info("updated Scanned date is " + UpdatedReceivedDate);
		
		logger.info("Change the scanned Time to T-3 days"); 
	    doc.put("ScannedTime", UpdatedReceivedDate);
		doc.put("IsScanned", true);
		doc.put("ScannedBy", "9792");
		updateDocInOrphanCartonCollection(doc);
		login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		
		homescreen.clickOnAuditing();
		auditingPage.clickMispicks();
		mispicksScanPage.addMispickedCarton(orphanCartonNumber);
}
	
	public void SRA1680_ToValidateAddSkusAndEditReceivedQtyForOrphanCarton()
			throws IOException, ParseException, InterruptedException {
		
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		AuditingPage auditingPage = new AuditingPage();
		MispicksScanPage mispicksScanPage = new MispicksScanPage();
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		SoftAssert softassert =new SoftAssert();
		String orphanCartonNumber=null;
		
		try {
		Document doc = createDocFromFile("OrphanCarton_withSkus.json");
		orphanCartonNumber = doc.getString("CartonNumber");
		logger.info("orphanCartonNumber is " + orphanCartonNumber);
		String destinationStoreNumber = doc.getString("DestinationStoreNumber");
		logger.info("orphanCartonNumber is " + orphanCartonNumber);
		
		login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		homescreen.clickOnReceiving();
		receivingPage.clickOnDcShipment();

		receivingShipmentScanPage.addCartonAsReceived(orphanCartonNumber);
		homescreen.clickOnMenuBar();
		homescreen.clickOnAuditingOnSideMenuBar();
		auditingPage.clickMispicks();
		mispicksScanPage.addMispickedCarton(orphanCartonNumber);

		logger.info("To validate error message while adding invalid sku");
		mispicksScanPage.validateErrorMessageWhileAddingInValidSkuToCarton("112");

		logger.info("To validate adding extra sku to the mispicked carton");
		mispicksScanPage.validateAddingValidSkuToCarton(getProperty("sku1023998"),softassert);
		
		logger.info("To validate error message while adding duplicate sku");
		mispicksScanPage.validateErrorMessageForAddingDuplicateSkuToOrphanCarton(getProperty("sku1023998"));

		logger.info("To edit the Received qty for extra added sku and to validate if both the sku number and edited qty gets updated in the DB");
		mispicksScanPage.editReceivedSkuQtyForExtraAddedSku("3");

		validateFromMongoDB.getSkuDetailsForOrphanCartonMarkedAsMispicks(orphanCartonNumber,destinationStoreNumber, getProperty("sku1023998"), softassert, "3");
		softassert.assertAll();
		}
		finally {
			deleteOrphanCarton(orphanCartonNumber);
		}
		}
	}
	
	

