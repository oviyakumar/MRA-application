
package com.pdt.auditingMispicksTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.MispicksScanPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "To validate Details of the Carton which is marked as Discrepancies/Mispicks")
@Description("To validate Details of the Carton which is marked as Discrepancies/Mispicks")

public class test extends BaseTest{

	
	final static Logger logger = Logger.getLogger("test");

	
public void SRA1370_ViewDetailsOfMispickedCarton_MultipleSku() throws IOException, ParseException, InterruptedException {
		HomePage homescreen = new HomePage();
		
		Document doc = createDocFromFile("Mispicks_MultipleSku.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);

		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("EtaDateTime", ExpectedArrival);

		String cartonNumber = ((List<Document>) doc.get("Cartons")).get(0).getString("CartonNumber");
		logger.info("carton marked as mispicks is " + cartonNumber);

		Document doc2 = ((List<Document>) doc.get("Cartons")).get(0);

		updateDocToDb(doc);

		LoginPage login = new LoginPage();
		ReceivingPage receivingPage = new ReceivingPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		AuditingPage auditingPage = new AuditingPage();
		MispicksScanPage mispicksScanPage = new MispicksScanPage();
		

		login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		homescreen.clickOnReceiving();
		receivingPage.clickOnDcShipment();
		receivingShipmentScanPage.addCartonAsReceived(cartonNumber);

		
		receivingShipmentScanPage.clickOnScannedCarton();
		String pagesource= receivingShipmentScanPage.pageSource();
		System.out.println(pagesource);
}
}
	
	


