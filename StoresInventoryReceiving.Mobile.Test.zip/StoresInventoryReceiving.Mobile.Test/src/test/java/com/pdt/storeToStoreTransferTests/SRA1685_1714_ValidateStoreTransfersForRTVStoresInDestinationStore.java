package com.pdt.storeToStoreTransferTests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.pdt.Pom.SendStoreTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;
@Listeners(BaseListener.class)
@Test(description = "Validating transfer order initiated for an RTV store is available in Destination Store")
@Description("Validating transfer order initiated for an RTV store is available in Destination Store")

public class SRA1685_1714_ValidateStoreTransfersForRTVStoresInDestinationStore extends BaseTest  {
	final static Logger logger = Logger.getLogger(SRA1685_1714_ValidateStoreTransfersForRTVStoresInDestinationStore.class.getName());
	
	public void SRA_1714_SearchForCreatedTransferorderInDestinationStoreForRTVStore()  {
		String transferNumberCreated = null;

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendAndReceiveTransferPage = new SendAndReceiveTransferPage();
		SendStoreTransferPage sendStoreTransfer = new SendStoreTransferPage();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		SoftAssert softassert=new SoftAssert();
		try {
			login.loginInMRA(this.getProperty("valid_storeno2"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendAndReceiveTransferPage.clickOnSendStoreTransfer();

			logger.info("Creating a new transfer order for RTV Store and submitting the transfer order");
			transferNumberCreated = sendStoreTransfer.createTransferforSingleSku(getProperty("destinationStore900"),
					getProperty("sku5739995"));
	
			homescreen.clickOnMenuBar();
			homescreen.logout();
			
			
			logger.info("To validate if the created Transfer order is displayed in the Receive Transfer Home page");
			androidDriverConfig.clearData();
			login.loginInMRA(this.getProperty("destinationStore900"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendAndReceiveTransferPage.clickOnReceiveStoreTransfer();
			boolean isTransferDisplayed = receiveStoreTransfer.searchForReceiveTransfer(transferNumberCreated);
			Assert.assertTrue(isTransferDisplayed);
			
			receiveStoreTransfer.validateLabelsInReceiveStoreTransfersHomePage(softassert);

			
		} 
		
		catch (Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false);
		}
		finally {
			deleteStoreTransfer(transferNumberCreated);
			
		}
	}

}
