package com.pdt.storeToStoreTransferTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;

import com.pdt.Pom.ReceivingTransferPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validate Receive Transfers summary screen after submitting")
@Description("Validate Receive Transfers summary screen after submitting")

//By Oviya

public class SRA156_1247_ConfirmSummaryAndSubmitReceivedSkusForStoreTransfer_CompletelyReceived extends BaseTest {
	
	

	public void SRA_1247_validateTransferSummary_SingleSku_AfterSubmission_CompletelyReceived()
			throws IOException, ParseException, InterruptedException {
		
		
		String transferNumber = null;
		String storeNumber = null;
		
		
		LoginPage login = new LoginPage();

		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
	
			Document doc = createDocFromFile("ReceiveTransferswithSingleSku.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateIncementDay("yyyy-MM-dd", 6);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			updateDocToStoreTransferDb(doc);
			
			

			transferNumber = doc.getString("TransferNumber");
			storeNumber = doc.getString("DestinationStoreNumber");
			System.out.println("Transfer Number is "+transferNumber);
			
			// Navigate to receive Transfers screen and search for the Inserted transfer

			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendnReceivetransfer.clickOnReceiveStoreTransfer();

			// Validating Transfer summary After Submitting skus for single sku which is
			// completely received
			receiveStoreTransfer.validateTransferSummaryAfterSubmittingSkus(transferNumber, "1", "1",storeNumber);
			
		
	}

}