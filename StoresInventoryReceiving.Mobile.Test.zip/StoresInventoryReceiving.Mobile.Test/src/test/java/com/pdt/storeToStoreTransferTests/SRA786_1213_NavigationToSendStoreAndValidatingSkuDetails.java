package com.pdt.storeToStoreTransferTests;

import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.pdt.Pom.SendStoreTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "View the transfer detail in send store transfer")
@Description("View the transfer detail in send store transfer")
// Written By Ruthra
// Reviewed By Harmeet

public class SRA786_1213_NavigationToSendStoreAndValidatingSkuDetails extends BaseTest {

	
	public void SRA1213_NavigateToSendStoreTransferValidationforSingleSku() {
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		SendStoreTransferPage sendStoreTransfer = new SendStoreTransferPage();
		SoftAssert softassertion = new SoftAssert();
		String transferNumberCreated = null;

		try {
			login.loginInMRA(getProperty("valid_storeno3"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendnReceivetransfer.clickOnSendStoreTransfer();

			transferNumberCreated = sendStoreTransfer.createTransferforSingleSku(getProperty("valid_storeno104"),
					"5739995");
			//validation in TransferDetailPage
			sendStoreTransfer.validationInTransferDetailPageForSingleSku(softassertion);
			
			//validation in SkuDetailPage
			sendStoreTransfer.validateSkuDetailPageForSingleSku("5739995",transferNumberCreated,softassertion);
			softassertion.assertAll();
		} 
		catch (InterruptedException e) {
			
			e.printStackTrace();
		}

		

	}

	
	public void SRA1213_NavigateToSendStoreTransferValidationforMultipleSku() {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		SendStoreTransferPage sendStoreTransfer = new SendStoreTransferPage();
		SoftAssert softassertion = new SoftAssert();
		String transferNumberCreated = null;

		try {
			login.loginInMRA(this.getProperty("valid_storeno3"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendnReceivetransfer.clickOnSendStoreTransfer();

			transferNumberCreated = sendStoreTransfer
					.createTransferforMultipleSkuQTYValidation(getProperty("valid_storeno104"), "5739995", "1023998");
			
			//validation in TransferDetailPage
			sendStoreTransfer.validationInTransferDetailPageForMultipleSku(transferNumberCreated, "5739995", "1023998",softassertion);
			
			//validation in SkuDetailPage
			sendStoreTransfer.validateSkuDetailPageForMultipleSku(softassertion);
			softassertion.assertAll();
		
		} 
		catch (InterruptedException e) {
			
			e.printStackTrace();
		}

		
	}
}

	