package com.pdt.storeToStoreTransferTests;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.pdt.Pom.SendStoreTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Create a new partial transfer order")
@Description("Create a new partial transfer order")

//By Harmeet
public class SRA805_1210_CreateAPartialTransferOrder extends BaseTest {
	
	public void SRA1210_createNewPartialTransferOrder() {
		LoginPage login = new LoginPage();
		HomePage homeScreen=new HomePage();
		ReceivingPage receivingPage=new ReceivingPage();
		SendAndReceiveTransferPage sendAndReceiveTransferPage=new SendAndReceiveTransferPage();
		SendStoreTransferPage sendStoreTransferPage=new SendStoreTransferPage();
		
		login.loginInMRA(this.getProperty("valid_storeno3"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));
		homeScreen.clickOnReceiving();
		receivingPage.clickOnStoreToStoreTransfer();
		sendAndReceiveTransferPage.clickOnSendStoreTransfer();
		sendStoreTransferPage.initiatePartialSendStoreTransfer(getProperty("valid_storeno104"));
		
		
	}
	

}
