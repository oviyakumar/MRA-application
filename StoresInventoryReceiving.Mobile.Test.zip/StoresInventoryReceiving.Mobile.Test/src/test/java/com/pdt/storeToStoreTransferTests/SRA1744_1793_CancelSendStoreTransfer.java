package com.pdt.storeToStoreTransferTests;

import java.text.ParseException;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.pdt.Pom.SendStoreTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "Cancel a new Transfer in send store Transfer")
@Description("Cancel a new transfer in send store Transfer")

public class SRA1744_1793_CancelSendStoreTransfer extends BaseTest  {
	
	final static Logger logger = Logger.getLogger(SRA1744_1793_CancelSendStoreTransfer.class.getName());
	
	public void SRA1793_ValidateCancelFunctionInSendStoreTransferBeforeAddingSku() throws InterruptedException {
		
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		SendStoreTransferPage sendStoreTransfer = new SendStoreTransferPage();
		

			login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendnReceivetransfer.clickOnSendStoreTransfer();

		 sendStoreTransfer.validateCancelButtonIsEnabledBeforeAddingSku(getProperty("valid_storeno104"),
					"5739995");
		 sendStoreTransfer.validateSummaryButtonIsDisabledBeforeAddingSku();
		 sendStoreTransfer.cancleTransferBeforeAddingSku();
		 
		 sendStoreTransfer.cancleTransferAfterAddingSku(getProperty("valid_storeno3"),"5739995");
		 
		 sendStoreTransfer.ValidateCancelTransferOrderAfterLogout(getProperty("valid_storeno104"),"1023998");
		 homescreen.clickOnMenuBar();
		 homescreen.logout();
		 
		login.loginWithRegisteredStore(this.getProperty("valid_username9792"), this.getProperty("valid_password9792"));
		homescreen.clickOnReceiving();
		receivingPage.clickOnStoreToStoreTransfer();
		sendnReceivetransfer.clickOnSendStoreTransfer();

		sendStoreTransfer.CancelTransferOrderAfterLogout();

		}
	
     public void SRA1793_ValidateCancelFunctionInSendStoreTransferForCrossBrand() throws InterruptedException {
		
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		SendStoreTransferPage sendStoreTransfer = new SendStoreTransferPage();
		

			login.loginInMRA(getProperty("valid_storeno665"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendnReceivetransfer.clickOnSendStoreTransfer();
			
			sendStoreTransfer.cancleTransferAfterAddingSkuForCrossBrand(getProperty("valid_storeno879"), "1023998");
			
}		
     
     public void SRA1793_ValidateCancelFunctionInSendStoreTransferForSubmittedTransfer() throws InterruptedException, ParseException {
 		
 		LoginPage login = new LoginPage();
 		HomePage homescreen = new HomePage();
 		ReceivingPage receivingPage = new ReceivingPage();
 		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
 		SendStoreTransferPage sendStoreTransfer = new SendStoreTransferPage();
 		

 			login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
 					getProperty("valid_password9792"));
 			homescreen.clickOnReceiving();
 			receivingPage.clickOnStoreToStoreTransfer();
 			sendnReceivetransfer.clickOnSendStoreTransfer();
 			
 			String transferNumber=sendStoreTransfer.ValidateSubmittedTransferOrder(getProperty("valid_storeno104"), "5739995");
 			
 			sendStoreTransfer.ValidateCanceledTransferOrderInDB(getProperty("valid_storeno104"), "5739995", transferNumber);
 			
 }		
     
  


}
