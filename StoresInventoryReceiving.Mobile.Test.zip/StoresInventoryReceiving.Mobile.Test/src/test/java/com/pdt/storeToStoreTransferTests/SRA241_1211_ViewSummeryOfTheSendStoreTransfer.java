package com.pdt.storeToStoreTransferTests;

import static com.util.BaseUtil.getDateDecreaseDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.pdt.Pom.SendStoreTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "ViewSummeryOfTheSendStoreTransfer")
@Description("ViewSummeryOfTheSendStoreTransfer")

public class SRA241_1211_ViewSummeryOfTheSendStoreTransfer extends BaseTest {

	public void SRA1211_validateSummeryOfTheSendStoreTransfer() throws ParseException, IOException {

		Document doc = createDocFromFile("StoreSRA769.json");

		// Transfer No 212343
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateDecreaseDay("yyyy-MM-dd", 10);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("ETADateTime", ExpectedArrival);
		
		SimpleDateFormat formatCreatedDate = new SimpleDateFormat("yyyy-MM-dd");
		String createdDate = getDateDecreaseDay("yyyy-MM-dd", 10);
		Date createdDateNTime = formatCreatedDate.parse(createdDate);
		doc.put("CreatedDateTime", createdDateNTime);
		

		updateDocToStoreTransferDb(doc);

		LoginPage loginScreen = new LoginPage();
		ReceivingPage receivingpage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		SendStoreTransferPage sendTransfer = new SendStoreTransferPage();
		
		

			loginScreen.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			HomePage homescreen = new HomePage();
			homescreen.clickOnReceiving();

			receivingpage.clickOnStoreToStoreTransfer();

			sendnReceivetransfer.clickOnSendStoreTransfer();

			sendTransfer.validateTheTransferSummeryDetail(getProperty("transferNumber212343"));
		

	}

}
