package com.pdt.storeToStoreTransferTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "Validating SKU Detail in Receive Transfer#")
@Description("Validating SKU Detail in Receive Transfer#")

//By Ruthra

public class SRA582_1245_ValidateSkuDetailsInReceiveTransferForSingleSku extends BaseTest{
	final static Logger logger = Logger.getLogger(SRA582_1245_ValidateSkuDetailsInReceiveTransferForSingleSku.class.getName());
	 String transferNumberCreated=null;
	  String skuNumber1023998=null;
	  String shippedQty=null;
	 String storeNumber=null;
	
	
	
	public void SRA1245_ValidateSkuDetailForSingleSku() throws Exception
	{
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		
			
			
			Document doc = createDocFromFile("SRA582Transfer.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 7);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			updateDocToStoreTransferDb(doc);

			transferNumberCreated = doc.getString("TransferNumber");
			storeNumber = doc.getString("DestinationStoreNumber");
			logger.info("Transfer Number is -------"+transferNumberCreated);
			
			skuNumber1023998 = ((List<Document>) doc.get("SKUs")).get(0).getString("SkuNumber");
			logger.info("skuNumber " + skuNumber1023998);
			
			int ShippedQuantity  = ((List<Document>) doc.get("SKUs")).get(0).getInteger("ShippedQuantity");
			logger.info("ShippedQuantity " + ShippedQuantity);
			shippedQty=String.valueOf(ShippedQuantity);
			
             login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			
			homescreen.clickOnReceiving();
	        receivingPage.clickOnStoreToStoreTransfer();
	        sendnReceivetransfer.clickOnReceiveStoreTransfer();
	       receiveStoreTransfer.validatingSkuDetailInReceiveTransfer(transferNumberCreated,skuNumber1023998,shippedQty,storeNumber);
	       receiveStoreTransfer.editSkuQty("2");
		
       	
	}
	
	@Test(dependsOnMethods={"SRA1245_ValidateSkuDetailForSingleSku"})
	public void SRA1245_ValidateSkuDetailForPartiallyReceivedTransfer(){
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		
			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
		    homescreen.clickOnReceiving();
	        receivingPage.clickOnStoreToStoreTransfer();
	        sendnReceivetransfer.clickOnReceiveStoreTransfer();
	        logger.info("Transfer Number is -------"+transferNumberCreated);
	        receiveStoreTransfer.validatePartiallyReceivedTransfer(transferNumberCreated, skuNumber1023998,shippedQty,"2");
	        
		
		
	}
	
	@Test(dependsOnMethods={"SRA1245_ValidateSkuDetailForSingleSku"})
	public void SRA1245_ValidateSkuDetailForReceivedQtyGreaterThanShippedQty(){
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		
			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
		    homescreen.clickOnReceiving();
	        receivingPage.clickOnStoreToStoreTransfer();
	        sendnReceivetransfer.clickOnReceiveStoreTransfer();
	        logger.info("Transfer Number is -------"+transferNumberCreated);
	        receiveStoreTransfer.validateReceiveTransferGreaterThanShippedQty(transferNumberCreated, skuNumber1023998,shippedQty, "7");
		
		
	}
	
	
}
