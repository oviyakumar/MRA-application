package com.pdt.storeToStoreTransferTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "ViewDetailsOfReceiveStoreTransfer")
@Description("ViewDetailsOfReceiveStoreTransfer")
public class SRA149_1216_ViewDetailsOfReceiveStoreTransferForMultipleSku extends BaseTest {
	final static Logger logger = Logger.getLogger(SRA149_1216_ViewDetailsOfReceiveStoreTransferForMultipleSku.class.getName());

	
	public void SRA1216_ViewDetailsOfReceiveStoreTransferforMultipleSku() throws InterruptedException, IOException, ParseException {
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		SoftAssert softassert = new SoftAssert();
		ValidateFromMongoDB mongoDB= new ValidateFromMongoDB();
		
			
			Document doc = createDocFromFile("ReceiveTransferswithMultipleSku.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateIncementDay("yyyy-MM-dd", 7);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			updateDocToStoreTransferDb(doc);

			//String transferNumber = doc.getString("TransferNumber");
			String storeNumber = doc.getString("DestinationStoreNumber");
			//logger.info("Transfer Number is -------"+transferNumber);

			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendnReceivetransfer.clickOnReceiveStoreTransfer();
			
			String transferNumber=mongoDB.getValidStoreTransferNumberWithMultipleSku(storeNumber);
			logger.info("Transfer Number is -------"+transferNumber);

			receiveStoreTransfer.validationInReceiveTransferDetailforMultipeSku(transferNumber,softassert,storeNumber);
			softassert.assertAll();
		
	}

}
