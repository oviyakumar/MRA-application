package com.pdt.storeToStoreTransferTests;

import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.pdt.Pom.SendStoreTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "To Validate Add SKUs in send store transfer")
@Description("To Validate Add SKUs in send store transfer")

//By Ruthra
//Reviewed By Harmeet

//Since i am initiating a driver only once for every class, for this class i am using loginwithRegistered method 

public class SRA236_1215_ValidatesAddSKuInStoreToStoreTransfer extends BaseTest {
	final static Logger logger = Logger.getLogger(SRA236_1215_ValidatesAddSKuInStoreToStoreTransfer.class.getName());

	
	public void SRA1215_VerifyNewTransferforValidStoreNumberAndValidSku() throws InterruptedException, ClassNotFoundException, SQLException {
		LoginPage login = new LoginPage();
		HomePage homeScreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendandReceive = new SendAndReceiveTransferPage();
		SendStoreTransferPage sendStoreTransfer = new SendStoreTransferPage();
		String transferNumberCreated=null;
		
       try{
		login.loginInMRA(this.getProperty("valid_storeno3"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));

		homeScreen.clickOnReceiving();
		receivingPage.clickOnStoreToStoreTransfer();
		sendandReceive.clickOnSendStoreTransfer();
		
		transferNumberCreated=sendStoreTransfer.validatationInSendStoreTransfer(this.getProperty("valid_storeno104"), getProperty("sku5739995"));
       }
       
       finally{
    	deleteStoreTransfer(transferNumberCreated);
       }

	}

	
	public void SRA1215_VerifyNewTransferforSameOrInvalidStoreNumber() {
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendandreceive = new SendAndReceiveTransferPage();
		SendStoreTransferPage sendStoreTransfer = new SendStoreTransferPage();
        
		
			login.loginInMRA(this.getProperty("valid_storeno3"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));

		homescreen.clickOnReceiving();
		receivingPage.clickOnStoreToStoreTransfer();
		sendandreceive.clickOnSendStoreTransfer();
		
		sendStoreTransfer
				.validatationInSendStoreTransferforSameOrInvalidStoreNumber(this.getProperty("valid_storeno3"));
		
	}

	@Test(dependsOnMethods={"SRA1215_VerifyNewTransferforValidStoreNumberAndValidSku"})
	public void SRA1215_VerifyNewTransferforInvalidAndDuplicateSkuNumber() {
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendandreceive = new SendAndReceiveTransferPage();
		SendStoreTransferPage sendstoretransfer = new SendStoreTransferPage();
        String transferNumberCreated=null;
		try{
		login.loginInMRA(this.getProperty("valid_storeno3"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));

		homescreen.clickOnReceiving();
		receivingPage.clickOnStoreToStoreTransfer();
		sendandreceive.clickOnSendStoreTransfer();
		
		//validate for Invalid Sku Number
		logger.info("validate for Invalid Sku Number");
		sendstoretransfer.validatationInSendStoreTransferforforInvalidSkuNumber(getProperty("valid_storeno104"),
				getProperty("invalidSkuNumber"));
		logger.info("Validate for Duplicate Sku number");
		//Validate for Duplicate Sku number
		transferNumberCreated=sendstoretransfer.validatationInSendStoreTransferforforDuplicateSkuNumber(getProperty("valid_storeno104"),
				getProperty("sku1023998"));
		}
        
		finally{
		deleteStoreTransfer(transferNumberCreated);
		}

	}

	
}
