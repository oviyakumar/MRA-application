package com.pdt.storeToStoreTransferTests;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;

import com.pdt.Pom.SendAndReceiveTransferPage;
import com.pdt.Pom.SendStoreTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validating transfer order once created and submitted successfully cannot be edited")
@Description("Validating transfer order once created and submitted successfully cannot be edited")

//Created By oviya
//Reviewed By Harmeet

public class SRA245_1208_ValidateSubmittedTransferOrderCannotBeEdited extends BaseTest {

	public void validatesSubmittedTransferOrderCannotBeEdited() throws Exception {
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendAndReceiveTransferPage = new SendAndReceiveTransferPage();
		SendStoreTransferPage sendStoreTransfer = new SendStoreTransferPage();

		String transferNumberCreated = null;

		try {
			login.loginInMRA(this.getProperty("valid_storeno3"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendAndReceiveTransferPage.clickOnSendStoreTransfer();
			transferNumberCreated = sendStoreTransfer.createTransferforSingleSku(getProperty("destinationStore104"),
					getProperty("sku5739995"));
			sendStoreTransfer.TransferOrderCanNotBeEditedOnceSubmitted(transferNumberCreated);
		}

		finally {
			deleteStoreTransfer(transferNumberCreated);
			
		}

	}
}
