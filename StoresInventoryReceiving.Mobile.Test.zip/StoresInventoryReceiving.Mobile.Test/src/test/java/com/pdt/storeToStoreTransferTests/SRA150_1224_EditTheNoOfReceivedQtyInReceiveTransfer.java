package com.pdt.storeToStoreTransferTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.bson.Document;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "Edit the number of received qty and damaged qty for a SKU for a Store Transfer")
@Description("Edit the number of received qty and damaged qty for a SKU for a Store Transfer")

//Harmeet
public class SRA150_1224_EditTheNoOfReceivedQtyInReceiveTransfer extends BaseTest {

	
	public void SRA150_ValidateToEditTheSkuInReceivingTransfer() throws InterruptedException, IOException, ParseException {

		LoginPage login = new LoginPage();
		HomePage homeScreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		ReceivingTransferPage receivingTransferPage = new ReceivingTransferPage();
	

		Document doc = createDocFromFile("StoreSRA706.json");

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("ETADateTime", ExpectedArrival);

		updateDocToStoreTransferDb(doc);

		// login as receiving store

		login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		homeScreen.clickOnReceiving();
		receivingPage.clickOnStoreToStoreTransfer();
		sendnReceivetransfer.clickOnReceiveStoreTransfer();
		
		// To validate if associate is able to edit the received SKU qty
		receivingTransferPage.validateReceiveTransferSkuCanBeEdited(getProperty("transferNumber200452"),
				getProperty("sku5739995"),"4");
		
		// To validate if associate is able to edit the received SKU qty upto 99
		receivingTransferPage.validateAbleToEditReceivedQtyUpTo99("99");
		
		// To validate if click on cancel button does not save the edited sku qty
		receivingTransferPage.validateSkuQuantityNotChangedWhenClickOnCancel("5");
		
		// Validate associates is not able to edit the received SKU Qty above 99
		receivingTransferPage.validateNotAbletoEditReceivedQtyAbove99("110");
		
	}

	
	
}
