package com.pdt.AuditingInTransitDamages;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.AuditingInTransitDamagesScanPage;
import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Navigate To In-Transit Damages screen and validate the default message")
@Description("Navigate To In-Transit Damages screen and validate the default message")

public class SRA189_1479_NavigateToInTransitDamageScreen extends BaseTest {

	final static Logger logger = Logger.getLogger("SRA189_1479");

	public void SRA1479_ValidateDefaultMessageIn_InTrasitDamageScreen() {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		AuditingPage auditingPage = new AuditingPage();
		AuditingInTransitDamagesScanPage inTransitDamagePage = new AuditingInTransitDamagesScanPage();

			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			homescreen.clickOnAuditing();
			auditingPage.clickInTransitDamages();

			inTransitDamagePage.isInTransitDamagesHeadingDisplayed();

			if (inTransitDamagePage.isDefaultMessageDisplayed()) {
				String defaultMessage = inTransitDamagePage.captureDefaultMessage();
				logger.info(defaultMessage + " message is displayed");
				Assert.assertEquals(defaultMessage, "Start Scanning to see damaged cartons");
			} else {
				inTransitDamagePage.inTransitDamagedCartonDisplayed();
				logger.info("cartons marked as Damage is Displayed in place of Default Message");
			}
		}


	
	

	
	}


