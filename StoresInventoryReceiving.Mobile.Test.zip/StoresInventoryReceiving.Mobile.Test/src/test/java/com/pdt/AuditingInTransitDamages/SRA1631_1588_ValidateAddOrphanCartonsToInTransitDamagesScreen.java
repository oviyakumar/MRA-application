package com.pdt.AuditingInTransitDamages;

import java.io.IOException;
import java.text.ParseException;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.AuditingInTransitDamagesScanPage;
import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;


@Listeners(BaseListener.class)
@Test(description ="To validate adding an Orphan carton to the In-Transit Damages Home Screen")
@Description("To validate adding an Orphan carton to the In-Transit Damages Home Screen")

public class SRA1631_1588_ValidateAddOrphanCartonsToInTransitDamagesScreen extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA1631_1588");
	HomePage home=new HomePage();

	
	public void SRA1631_ValidateAddingOrphanCartonWithSkusToInTransitDamages() throws IOException, ParseException{
		
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		AuditingPage auditingPage = new AuditingPage();
		AuditingInTransitDamagesScanPage inTransitDamagePage = new AuditingInTransitDamagesScanPage();
		ReceivingShipmentScanPage receivingShipmentscan = new ReceivingShipmentScanPage();
		ReceivingPage receivingPage = new ReceivingPage();
		String orphanCartonNumber=null;
try {
			Document doc = createDocFromFile("OrphanCarton_withSkus.json");
			// updateDocInOrphanCartonCollection(doc);
			// logger.info("Added  a record in orphan carton collection");
			
			 orphanCartonNumber = doc.getString("CartonNumber");
			logger.info("orphanCartonNumber is " + orphanCartonNumber);


			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));

			homescreen.clickOnReceiving();
			receivingPage.clickOnDcShipment();
			receivingShipmentscan.addCartonAsScanned(orphanCartonNumber);
			homescreen.clickOnMenuBar();
			homescreen.clickOnAuditingOnSideMenuBar();
			auditingPage.clickInTransitDamages();
			logger.info("To add a carton number which is scanned, but not submitted and to validate the error message");
			inTransitDamagePage.addScannedCartonToInTransitDamage(orphanCartonNumber);
			homescreen.clickOnMenuBar();
			homescreen.clickOnDCShipmentsOnSideMenuBar();
			receivingShipmentscan.submitCartonAsReceived();
			homescreen.clickOnMenuBar();
			homescreen.clickOnAuditingOnSideMenuBar();
			auditingPage.clickInTransitDamages();
			logger.info("To add a invalid carton number to In-Transit screen and to validate the error message");
			inTransitDamagePage.addInvalidCartonNumberToInTransitDamages("9975432621897B");
			
			logger.info("To incorrectly enter last 4 digits of the carton and to validate the error message");
			inTransitDamagePage.validateErrorMessageForEnteringInvalidFourDigitsForValidCarton(orphanCartonNumber);
			
			logger.info("To add a Valid carton number to In-Transit Damages");
			inTransitDamagePage.addValidCartonNumberToInTransitDamages(orphanCartonNumber);
			inTransitDamagePage.clickOnSubmitDamagesButton();
			
			logger.info("To add a Duplicate carton number and to validate the error message");
			inTransitDamagePage.addDuplicateCartonNumberToInTransitDamages(orphanCartonNumber);
			
			inTransitDamagePage.validateGobackInAddCartonPage();
}
			finally {
			deleteOrphanCarton(orphanCartonNumber);
			}
	
		}
	

	

 
}
