package com.pdt.AuditingInTransitDamages;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.AuditingInTransitDamagesScanPage;
import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.util.BaseUtil;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "To  edit damaged sku qty for carton marked as Intransit Damages")
@Description("To  edit damaged sku qty for carton marked as Intransit Damages")

public class SRA193_1482_EditDamagedQuantity_InTransitDamage extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA193_1482");
	
	@SuppressWarnings("unchecked")
	public void SRA1482_EditDamagedQuantity_InTransitDamage() throws InterruptedException, IOException, ParseException{
		
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		AuditingPage auditingPage = new AuditingPage();
		AuditingInTransitDamagesScanPage inTransitDamagePage = new AuditingInTransitDamagesScanPage();
		ReceivingShipmentScanPage receivingShipmentscan = new ReceivingShipmentScanPage();
		ReceivingPage receivingPage = new ReceivingPage();
		
		SoftAssert localAssert= new SoftAssert();

			Document doc = createDocFromFile("Mispicks.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 10);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);
			updateDocToDb(doc);

			String cartonNumber = ((List<Document>) doc.get("Cartons")).get(0).getString("CartonNumber");
			logger.info("carton number is " + cartonNumber);
            
			Document doc2 = ((List<Document>) doc.get("Cartons")).get(0);
			String skuNumber = ((List<Document>) doc2.get("Skus")).get(0).getString("SkuNumber");
			logger.info("skuNumber " + skuNumber);
			
			int shippedQty = ((List<Document>) doc2.get("Skus")).get(0).getInteger("ShippedQuantity");
			logger.info("receivedQty " + shippedQty);
			
			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnDcShipment();
			
			receivingShipmentscan.addCartonAsReceived(cartonNumber);
			homescreen.clickOnMenuBar();
			homescreen.clickOnAuditingOnSideMenuBar();
			auditingPage.clickInTransitDamages();
			inTransitDamagePage.addCartonToInTransitDamages(cartonNumber);

			String CartondamagedTime =BaseUtil.getTodayDate("MM/dd/yyyy HH:mm");
			logger.info("Carton DamagedTime is "+CartondamagedTime);
			
			// To edit damaged Qty to less than Sku Qty  
			inTransitDamagePage.editAndSaveDamagedSkuQty("3");	
			
			
			// To validate click on cancel doesnot save the edited damaged qty
			inTransitDamagePage.editAndCancelDamagedSkuQty("5");
			
			// To validate associates is not able to edit damaged Qty more than Sku received Qty
			inTransitDamagePage.editDamagedQtyMoreThanSkuReceivedQty(String.valueOf(shippedQty+2));
			
			// validate able to edit damage Qty to zero 
			inTransitDamagePage.editAndSaveDamagedSkuQty("0");
			
			// To validate associates is not able to edit the Damaged SKU Qty above 99
			inTransitDamagePage.editDamagedQtyAbove99("101");
			
			 // To validate if the saved Damaged qty is updated in DB
			inTransitDamagePage.editAndSaveDamagedSkuQty("5");
			
			String skuDamagedTime =BaseUtil.getTodayDate("MM/dd/yyyy HH:mm");
			logger.info("Current DamagedTime is "+skuDamagedTime);
			inTransitDamagePage.clickOnSubmitDamagesButton();
			
			Thread.sleep(5000);
			new ValidateFromMongoDB().validateDamagedQuantityAndTimeFromDB(cartonNumber,"5",getProperty("valid_username9792"),skuDamagedTime,CartondamagedTime,localAssert,getProperty("valid_storeno104"));
			
			Thread.sleep(3000);
			homescreen.clickOnMenuBar();
			homescreen.clickOnDCShipmentsOnSideMenuBar();
			
			receivingShipmentscan.SRA1482_ValidateDamagedQuantityInReceiving("5",cartonNumber,localAssert);
			
			localAssert.assertAll();
			
		}
}
