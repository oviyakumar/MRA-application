package com.pdt.AuditingInTransitDamages;

import static com.util.BaseUtil.getDateDecreaseDay;
import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.AuditingInTransitDamagesScanPage;
import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validate if Yesterday Damaged Carton is not Displayed in In-Transit home Page")
@Description("To Validate if Yesterday Damaged Carton is not Displayed in In-Transit home Page")

public class SRA189_1479_ValidateYesterdayDamagedCarton_NotDisplayedIn_InTansitDamageHomeScreen extends BaseTest{
	final static Logger logger = Logger.getLogger(SRA189_1479_ValidateYesterdayDamagedCarton_NotDisplayedIn_InTansitDamageHomeScreen.class.getName());
	
	@SuppressWarnings("unchecked")
	public void SRA1479_ValidateYesterdayDamagedCarton_NotDisplayedIn_InTansitDamageHomeScreen() throws InterruptedException, IOException, ParseException {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		AuditingPage auditingPage = new AuditingPage();
		AuditingInTransitDamagesScanPage inTransitDamagePage = new AuditingInTransitDamagesScanPage();

	
			Document doc = createDocFromFile("SRA189_DamagedTrue.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 10);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);

			String yesterdayDate = getDateDecreaseDay("yyyy-MM-dd", 1);
			Date UpdatedYesterdayDate = format.parse(yesterdayDate);
			logger.info("updated Yesterday date is " + UpdatedYesterdayDate);

			// Change the scanned Time and Damaged Time To yesterday
			((List<Document>) doc.get("Cartons")).get(0).put("ScannedTime", UpdatedYesterdayDate);
			((List<Document>) doc.get("Cartons")).get(0).put("DamagedTime", UpdatedYesterdayDate);
			updateDocToDb(doc);
			
			login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			homescreen.clickOnAuditing();
			auditingPage.clickInTransitDamages();
			Thread.sleep(2000);
			
			inTransitDamagePage.isDamagedCartonNotDisplayed("1111245633389R");
			logger.info("Cartons marked Damaged Yesterday is not displayed in In-Transit Home screen today");

		}


}
