
package com.pdt.auditingInStoreDamages;

import java.io.IOException;
import java.text.ParseException;

import org.apache.log4j.Logger;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.AuditingInStoreDamagesScanPage;
import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;

import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "To validate adding a Damaged Sku To In-Store Damages Screen")
@Description("To validate adding a Damaged Sku To In-Store Damages Screen")

public class SRA199_1356_TypeAndAddSKULabelNumbersToInStoreDamagesScreen extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA199_1356");
	SoftAssert softassert =new SoftAssert();
			
	public void SRA1356_VerifyAddingSkuNumbersToInStoreDamagesHomeScreen() throws IOException, ParseException, InterruptedException {
		
		HomePage homescreen = new HomePage();
		LoginPage login = new LoginPage();
		AuditingPage auditingPage = new AuditingPage();
		AuditingInStoreDamagesScanPage InStoreDamagesPage = new AuditingInStoreDamagesScanPage();
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
	
			//Method to update all the In-store damaged skus to previous date, so that I can add it today
			validateFromMongoDB.updateSkuMarkedAsInStoreDamages(getProperty("sku2099406"));
			
			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			
		homescreen.clickOnAuditing();
		auditingPage.clickInStoreDamages();
		logger.info("To add a Valid Sku number to In-store Damages Screen");
		InStoreDamagesPage.createInStoreDamages(getProperty("sku2099406"),softassert);
		
		logger.info("To Validate error message for invalid sku number");
		InStoreDamagesPage.validateErrorMessageForInvalidSkuNumber(getProperty("invalidSkuNumber"),softassert);
		
		logger.info("To Validate error message for Duplicate sku number");
		InStoreDamagesPage.validateErrorMessageForDuplicateSkuNumber(getProperty("sku2099406"),softassert);
		Thread.sleep(2000);
		validateFromMongoDB.validateDamagedSkuaddedToInStoreDamagesScreen(getProperty("sku2099406"), softassert);
		softassert.assertAll();
		
		}
}