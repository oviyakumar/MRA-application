
package com.pdt.auditingInStoreDamages;

import java.io.IOException;
import java.text.ParseException;

import org.apache.log4j.Logger;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.AuditingInStoreDamagesScanPage;
import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.util.BaseUtil;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "To validate edit damaged sku qty for a sku marked as damaged")
@Description("To validate edit damaged sku qty for a sku marked as damaged")

public class SRA201_1467_EditAndUpdateDamagedSkuQuantityForInStoreDamages extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA_1465");
	SoftAssert softassert =new SoftAssert();

	public void SRA1467_EditDamagedSkuQtyForInStoreDamages() throws IOException, ParseException, InterruptedException {
		
		HomePage homescreen = new HomePage();
		LoginPage login = new LoginPage();
		AuditingPage auditingPage = new AuditingPage();
		AuditingInStoreDamagesScanPage InStoreDamagesPage = new AuditingInStoreDamagesScanPage();
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();

//			Document doc = createDocFromFile("InStoreDamagesScanned.json");
//			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
//		
//			String TodayDate = getTodayDate("yyyy-MM-dd");
//			Date UpdatedTodayDate = format.parse(TodayDate);
//			logger.info("updated Today date is " + UpdatedTodayDate);
//			
//			String skuNumber = doc.getString("SkuNumber");
//			logger.info("sku number is " + skuNumber);
//			
//			// Changed the Created and Modified time of In-store Damaged Sku To today date 
//			 doc.put("CreatedTime", UpdatedTodayDate);
//			 doc.put("ModifiedTime", UpdatedTodayDate);
//			 
//			 updateDocInStoreCollection(doc);
		
			//Method to update all the In-store damaged skus to previous date, so that I can add it today
			validateFromMongoDB.updateSkuMarkedAsInStoreDamages(getProperty("sku5739995"));
			
			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username4850"),
					getProperty("valid_password4850"));
			homescreen.clickOnAuditing();
			auditingPage.clickInStoreDamages();
			logger.info("To add a Valid Sku number to In-store Damages Screen");
			InStoreDamagesPage.createInStoreDamages(getProperty("sku5739995"),softassert);
			
			InStoreDamagesPage.isDamagedSkuDisplayed();
			logger.info("Skus marked as Damaged today is displayed in In-store Damages Home screen today");
		
			logger.info("To validate if edited damaged sku qty gets updated on saving");
			InStoreDamagesPage.editAndSaveDamagedSkuQty(getProperty("sku5739995"),"3", softassert);
		
			logger.info("To validate edit damaged sku qty more than 10 for damaged sku");
			InStoreDamagesPage.editAndSaveDamagedSkuQty(getProperty("sku5739995"),"24", softassert);

			logger.info("To validate edit damaged sku qty to 99 for damaged sku");
			InStoreDamagesPage.editAndSaveDamagedSkuQty(getProperty("sku5739995"),"99", softassert);

			logger.info("To validate click on cancel doesnot save the edited damaged sku qty");
			InStoreDamagesPage.editAndCancelDamagedSkuQty(getProperty("sku5739995"),"4", softassert);
			
			// To validate if associate is able to edit the  SKU qty to 0
			logger.info("To validate if associate is able to edit the damaged qty to 0");
			InStoreDamagesPage.validateErrorMessageForDamagedQty0(getProperty("sku5739995"),"0",softassert);
			
			logger.info("To validate associates is not able to edit the damaged SKU Qty above 99");
			InStoreDamagesPage.editAndSaveDamagedSkuQtyAbove99(getProperty("sku5739995"),"101", softassert);
			
			String skuModifiedTime =BaseUtil.getTodayDate("MM/dd/yyyy HH:mm");
			logger.info("Current DamagedTime is "+skuModifiedTime);
			
			logger.info("To validate if the saved sku qty is updated in DB");
            Thread.sleep(5000);
            validateFromMongoDB.validateEditedDamagedQuantityForInStoreDamages(getProperty("sku5739995"),"10",skuModifiedTime, getProperty("valid_username4850"), softassert);
	        
			softassert.assertAll();
		} 
		
}
