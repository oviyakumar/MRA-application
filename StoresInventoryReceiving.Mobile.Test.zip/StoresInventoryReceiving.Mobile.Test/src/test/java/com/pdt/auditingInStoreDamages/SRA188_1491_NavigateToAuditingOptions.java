
package com.pdt.auditingInStoreDamages;

import java.io.IOException;
import java.text.ParseException;

import org.apache.log4j.Logger;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Navigate to various auditing screens and To validate the headers displayed")
@Description("Navigate to various auditing screens and To validate the headers displayed")

public class SRA188_1491_NavigateToAuditingOptions extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA188_1491");
	SoftAssert softassert =new SoftAssert();
			
	public void SRA1491_NavigateToAuditingOptions() throws IOException, ParseException, InterruptedException {
		
		HomePage homescreen = new HomePage();
		LoginPage login = new LoginPage();
		AuditingPage auditingPage = new AuditingPage();
		
			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			
		homescreen.clickOnAuditing();
		String AuditingHeader= auditingPage.captureAuditingHeader();
		softassert.assertEquals(AuditingHeader, "AUDITING");
		logger.info(AuditingHeader +" Heading is Displayed");	
		
		logger.info("To validate In-Tranist damages button and to validate the home page header");
		auditingPage.navigateToInTransitDamagesPage(softassert);
		
		
		logger.info("To validate In-Store damages button and to validate the home page header");
		auditingPage.navigateToInStoreDamagesPage(softassert);
		
		logger.info("To validate Mispicks/Discrepancies button and to validate the home page header");
		auditingPage.navigateToMispicksPage(softassert);
		softassert.assertAll();
		}
}

