package com.pdt.DCShipmentTests;

import static com.util.BaseUtil.getDateDecreaseDay;
import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.mongodb.client.MongoCollection;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentPage;
import com.util.DataBase.MongoDBManager;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "View Sanpshot of all expected Shipments")
@Description("View Sanpshot of all expected Shipments")

public class SRA7_1090_View_SnapshotOf_Receiving_Shipment extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA7_1090");

	public void SRA7_View_Snapshot_OfExpectedShipments() throws ParseException, IOException 

	{
		SoftAssert softassert =new SoftAssert();
		LoginPage login = new LoginPage();
		HomePage home = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
	

			Document doc = createDocFromFile("SRA7_DcShipment1.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm");
			String EtaDate = getDateIncementDay("yyyy-MM-dd hh:mm", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);
			logger.info("Date after increment " + ExpectedArrival);
			updateDocToDb(doc);

			MongoCollection<Document> collection = MongoDBManager.getCollection();
			ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();

			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));

			home.clickOnReceiving();
			receivingPage.clickOnDcShipment();
			validateFromMongoDB.validateInTransitShipment(collection, "104",softassert);
			softassert.assertAll();
		} 
	

	public void SRA7_ETAInvalid_GreaterThan365() throws ParseException, IOException 

	{
		LoginPage login = new LoginPage();
		HomePage home = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		
			Document doc = createDocFromFile("SRA7_DcShipment2.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateDecreaseDay("yyyy-MM-dd", 367);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);
			logger.info("Date after decrement " + ExpectedArrival);
			updateDocToDb(doc);

			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));

			home.clickOnReceiving();
			receivingPage.clickOnDcShipment();
			ReceivingShipmentPage receivingShipmentPage = new ReceivingShipmentPage();
			boolean shipmentStatus = receivingShipmentPage.isShipmentDisplayed("111143800104");
			Assert.assertFalse(shipmentStatus);
		} 
	

	public void SRA7_ETAInvalid_GreaterThan30Days() throws ParseException, IOException 

	{
		LoginPage login = new LoginPage();
		HomePage home = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		

			Document doc = createDocFromFile("SRA7_DcShipment3.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 32);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);
			logger.info("Date after increment " + ExpectedArrival);
			updateDocToDb(doc);

			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));

			home.clickOnReceiving();
			receivingPage.clickOnDcShipment();
			ReceivingShipmentPage receivingShipmentPage = new ReceivingShipmentPage();
			boolean shipmentStatus = receivingShipmentPage.isShipmentDisplayed("111123800104");
			Assert.assertFalse(shipmentStatus);
		} 

}
