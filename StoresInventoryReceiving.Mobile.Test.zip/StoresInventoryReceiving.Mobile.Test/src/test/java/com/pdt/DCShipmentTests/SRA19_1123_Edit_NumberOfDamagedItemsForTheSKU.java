
package com.pdt.DCShipmentTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.util.BaseUtil;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Mark a carton as damaged")
@Description("Mark a carton as damaged")

public class SRA19_1123_Edit_NumberOfDamagedItemsForTheSKU extends BaseTest {

	final static Logger logger = Logger.getLogger("SRA1123");
	public void SRA19_ValidatingDamagedSKUQty() throws IOException, ParseException, InterruptedException {
		
		SoftAssert assertion=new SoftAssert();
		ReceivingShipmentScanPage receivingShipmentscan = new ReceivingShipmentScanPage();
		LoginPage login = new LoginPage();
		HomePage home = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		ValidateFromMongoDB mongoDB= new ValidateFromMongoDB();

		Document doc = createDocFromFile("SRA19_EditSKUForDamagedSKU.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("EtaDateTime", ExpectedArrival);
		updateDocToDb(doc);

		
		login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		home.clickOnReceiving();
		receivingPage.clickOnDcShipment();
		receivingShipmentscan.markCartonAsDamaged("0010411113120R", "2", assertion);
		
		receivingShipmentscan.clickSkuNumber();
		String qty = receivingShipmentscan.damagedSkuQtyOnDetailPage();
		assertion.assertEquals("2", qty);
		

		receivingShipmentscan.clickOnGoBackButton();
		receivingShipmentscan.clickOnGoBackButtonOnCarton();
		receivingShipmentscan.clickOnShipmentSummery();
		receivingShipmentscan.clickOnSubmitShipmentSummery();
		receivingShipmentscan.clickOnOkButtonOnCartonSucceefullySubmitted();
		
		String currentTime =BaseUtil.getTodayDate("MM/dd/yyyy HH:mm");
		logger.info("Current Time is "+currentTime);
		
		Thread.sleep(3000);
		mongoDB.validateScannedTimeFromDB("0010411113120R", currentTime, getProperty("valid_username9792"), assertion,getProperty("valid_storeno104"));
		mongoDB.validateDamagedQuantityAndTimeFromDB("0010411113120R","2",getProperty("valid_username9792"),currentTime,currentTime,assertion,getProperty("valid_storeno104"));
		
		assertion.assertAll();
		}

	public void SRA19_ValidatingTheDamgedSKUNeverMoreThanRecdSKUQty() throws IOException, ParseException {
		SoftAssert assertion=new SoftAssert();
		LoginPage login = new LoginPage();
		HomePage home = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		ReceivingShipmentScanPage receivingShipmentscan = new ReceivingShipmentScanPage();
	
		Document doc = createDocFromFile("SRA19_EditSKUForDamagedSKU_2.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("EtaDateTime", ExpectedArrival);
		updateDocToDb(doc);

		
		login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		home.clickOnReceiving();
		receivingPage.clickOnDcShipment();
		receivingShipmentscan.markCartonAsDamaged("0010411111896R", "9", assertion);
		String errorMessage = receivingShipmentscan.validatingErrorMessage();
		assertion.assertEquals(
				"Please ensure that the damaged qty is never more than the expected SKU quantity for that carton",
				errorMessage);
		receivingShipmentscan.clickOnCancelBtn();

		receivingShipmentscan.clickSkuNumber();
		String damagedSKUQty = receivingShipmentscan.getDamagedSKUQty();
		assertion.assertEquals("0", damagedSKUQty);
		assertion.assertAll();
		}
		
	
	@Description("To  edit damaged sku qty and mark as non Damaged in DC shipment")
     public void SRA1490_EditDamagedQuantityAndCancelInDCShipment() throws ParseException, IOException, InterruptedException{
		
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingShipmentScanPage receivingShipmentscan = new ReceivingShipmentScanPage();
		ReceivingPage receivingPage = new ReceivingPage();
		SoftAssert assertion = new SoftAssert();
	
			Document doc = createDocFromFile("Mispicks.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 10);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);
			updateDocToDb(doc);

			String cartonNumber = ((List<Document>) doc.get("Cartons")).get(0).getString("CartonNumber");
			logger.info("carton number is " + cartonNumber);
            
			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));

			homescreen.clickOnReceiving();
			receivingPage.clickOnDcShipment();
			receivingShipmentscan.markCartonAsDamaged(cartonNumber, "1", assertion);
			receivingShipmentscan.clickSkuNumber();
			String qty = receivingShipmentscan.damagedSkuQtyOnDetailPage();
			assertion.assertEquals("1", qty);
			receivingShipmentscan.clickOnGoBackButton();
			receivingShipmentscan.clickOnGoBackButtonOnCarton();
			receivingShipmentscan.swipeCartonForDamage(cartonNumber, assertion);
			
			receivingShipmentscan.clickOnGoBackButton();
			receivingShipmentscan.clickOnGoBackButtonOnCarton();
			receivingShipmentscan.clickOnShipmentSummery();
			receivingShipmentscan.clickOnSubmitShipmentSummery();
			receivingShipmentscan.clickOnOkButtonOnCartonSucceefullySubmitted();
			
			Thread.sleep(3000);
			new ValidateFromMongoDB().validateDamagedQuantityNotUpdatedInDB(cartonNumber, assertion,getProperty("valid_storeno104"));
			
			assertion.assertAll();
			
			
			
		} 
	
}
