package com.pdt.DCShipmentTests;

import java.text.ParseException;

import org.apache.log4j.Logger;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.util.BaseUtil;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Scan 200 Carton")
@Description("Scan 200 carton")

public class SRA1805_Scan200OrphanCartons extends BaseTest {

	final static Logger logger = Logger.getLogger(SRA1805_Scan200OrphanCartons.class.getName());

	public void SRA1805_Scan200Carton() throws ParseException, InterruptedException {

		LoginPage login = new LoginPage();
		HomePage home = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		ValidateFromMongoDB mongoDB= new ValidateFromMongoDB();

		login.loginInMRA(getProperty("valid_storeno859"), getProperty("valid_username9792"), getProperty("valid_password9792"));
		home.clickOnReceiving();
		receivingPage.clickOnDcShipment();
		receivingShipment.clickOnScanButton();

		// 0085911112000S
		String cartonStoreNumber = "00859";
		String cartonVariable = "S";
		long cartonValue = 11113000L;
		int cartonCount=0;

		String startingTime =BaseUtil.getTodayDate("yyyy-MM-dd HH:mm");
		logger.info("Starting Time is "+startingTime);
		
		
		for (int i = 1; i <= 20; i++) {

			long cartonNewValue = cartonValue + i;
			String cartonNumber = cartonStoreNumber.concat(String.valueOf(cartonNewValue)).concat(cartonVariable);
			logger.info("Carton number is " + cartonNumber);

			receivingShipmentScanPage.ValidateBulkCartonScanning(cartonNumber);
			cartonCount=cartonCount+1;
		}
		
		logger.info("Carton count is "+cartonCount);
		
		receivingShipmentScanPage.submitAllReceivedCarton();
		
		Thread.sleep(50000);
		
		String submittedTime =BaseUtil.getTodayDate("yyyy-MM-dd HH:mm");
		logger.info("Submitted Time is "+submittedTime);
		
		mongoDB.validateScannedOrphanCartonCount(getProperty("valid_storeno859"), startingTime, submittedTime, cartonCount);
	}
	
	
	
	public void SRA1805_DeleteScanned200Carton()  {

		// 0085911112000S
		String cartonStoreNumber = "00859";
		String cartonVariable = "S";
		long cartonValue = 11112020L;
		int cartonCount=0;
		
		for (int i = 1; i <= 60; i++) {

			long cartonNewValue = cartonValue + i;
			String cartonNumber = cartonStoreNumber.concat(String.valueOf(cartonNewValue)).concat(cartonVariable);
			logger.info("Carton number is " + cartonNumber);

			deleteOrphanCarton(cartonNumber); 
			cartonCount=cartonCount+1;
		}
		
		logger.info("Carton count is "+cartonCount);
	}
}
