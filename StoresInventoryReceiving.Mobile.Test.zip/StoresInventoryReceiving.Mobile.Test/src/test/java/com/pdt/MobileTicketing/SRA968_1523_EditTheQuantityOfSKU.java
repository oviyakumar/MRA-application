package com.pdt.MobileTicketing;

import org.apache.log4j.Logger;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.MobileTicketingPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validates skuPrice and SkuQty in ItemLookUp")
@Description("Validates skuPrice and SkuQty in ItemLookUp")

public class SRA968_1523_EditTheQuantityOfSKU extends BaseTest{
	
	final static Logger logger = Logger.getLogger(SRA967_1522_EditThePriceOfSKU.class.getName());

	public void SRA1523_ValidateEditSKUQuantityInTicketing() {

		LoginPage login = new LoginPage();
		HomePage home = new HomePage();
		MobileTicketingPage mobileTicketing = new MobileTicketingPage();
		

			login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			home.clickOnItemLookUp();
			
			logger.info("Edit Valid SKU Quantity");
			mobileTicketing.ValidateSkuPrintQuantity(getProperty("sku3301702"),"20");
			
			logger.info("Verify Not able to Edit Print Quantity to 0");
			mobileTicketing.VerifyNotAbleToEditPrintQuantityZero(getProperty("sku3301702"), "0");
			
			logger.info("Verify Not able to Edit Print Quantity Above 99");
			mobileTicketing.VerifyNotAbleToEditPrintQuantityAbove99(getProperty("sku3301702"), "101");
			
			logger.info("Verify Able to Edit Print Quantity to 99");
			mobileTicketing.ValidateSkuPrintQuantity(getProperty("sku3301702"),"99");
			
			logger.info("Verify Able to Print Ticket After Editing");
			mobileTicketing.verifyAbleToPrintAfterEdit(getProperty("sku3301702"), "20.05");
			
			
	}

}
