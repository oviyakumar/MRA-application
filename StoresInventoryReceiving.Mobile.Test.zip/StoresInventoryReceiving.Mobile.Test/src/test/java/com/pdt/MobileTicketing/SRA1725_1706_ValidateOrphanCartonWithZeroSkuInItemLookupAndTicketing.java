package com.pdt.MobileTicketing;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.MobileTicketingPage;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validates Orphan Carton with Zero Sku Quantity in ItemLookUp and Ticketing Screen")
@Description("Validates Orphan Carton with Zero Sku Quantity in ItemLookUp and Ticketing Screen")

public class SRA1725_1706_ValidateOrphanCartonWithZeroSkuInItemLookupAndTicketing extends BaseTest{
	
final static Logger logger = Logger.getLogger(SRA1725_1706_ValidateOrphanCartonWithZeroSkuInItemLookupAndTicketing.class.getName());
	
	public void SRA1725_ValidateOrphanCartonWithZeroSKUQuantityInItemLookUpAndTicketing() throws IOException, ParseException {
		
		LoginPage login = new LoginPage();
		HomePage home=new HomePage();
		MobileTicketingPage mobileTicketing=new MobileTicketingPage();
		ValidateFromMongoDB mongoDB= new ValidateFromMongoDB();
		
		Document doc = createDocFromFile("OrphanCartonWithOutSKUforPrint.json");
		updateDocInOrphanCartonCollection(doc);
		
		HashMap<String, String> map=mongoDB.getReceivedOrphanCartonNumberWithZeroSkuQuantity(getProperty("valid_storeno104"));
		logger.info("Orphan Carton Number is -------"+ map.get("dbCartonNumber"));

		login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		
		home.clickOnItemLookUp();
		
		logger.info("Validating Orphan Carton Details with Zero SKU Quantity in ItemLookUp and Ticketing");
		mobileTicketing.validateCartonDetailsInTicketingPage(map.get("dbCartonNumber"), map.get("numberOfSku"), map.get("totalReceivedQuantity"));
		
	}


}
