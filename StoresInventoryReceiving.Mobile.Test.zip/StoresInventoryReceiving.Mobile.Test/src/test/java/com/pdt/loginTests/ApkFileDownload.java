package com.pdt.loginTests;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.util.APKFileDownloader;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = " Download APK file from Hockey App")
@Description("Description: Download APK file from Hockey App")

public class ApkFileDownload extends BaseTest {
	
	APKFileDownloader apkFileDownloader= null;
	public void unistallAndDownloadAPKFile() throws InterruptedException{
	
		apkFileDownloader= new APKFileDownloader();
		apkFileDownloader.deleteAppFromPDT(getProperty("packageName"));
		apkFileDownloader.deleteAPKFileFromFolder(getProperty("apk_file_location"));
		apkFileDownloader.lauchWebBrowser();
		apkFileDownloader.loginToHockeyApp(getProperty("email"), getProperty("hockeyAppPassword"));
		apkFileDownloader.downloadAPKFileFromChrome();
		apkFileDownloader.signOutFromHockeyApp();
		
	}
	
	@AfterClass
	public void quit() throws InterruptedException{
		
		apkFileDownloader.quitDriver();
	}
	
	

}
