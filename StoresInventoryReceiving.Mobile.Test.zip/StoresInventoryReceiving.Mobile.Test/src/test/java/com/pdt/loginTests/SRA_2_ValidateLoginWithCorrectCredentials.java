package com.pdt.loginTests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "To verify if Associate is able to login successfully,")
@Description("Description:To verify if Associate is able to login successfully")

public class SRA_2_ValidateLoginWithCorrectCredentials extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA2");

	public void SRA2_validateLoginWithCorrectCredentials() {

		HomePage homescreen = new HomePage();

		final LoginPage login = new LoginPage();
		logger.info("Login with valid username and password and verify if home page is displayed");
		login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		boolean value = homescreen.isHomeScreen();
		Assert.assertEquals(true, value);
		homescreen.clickOnMenuBar();
		homescreen.logout();
		String storeNumber = login.getStoreNumber();
		Assert.assertEquals("Store ID: 2", storeNumber);
		logger.info("Displayed store number after logout is --> " + storeNumber);

	}

}
