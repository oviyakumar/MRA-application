package com.pdt.loginTests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "View Receiving shipment functionality")
@Description("View Receiving shipment functionality")

public class SRA5_1091_Receiving_HomePage_Icon_Validation extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA5_1091");

	public void sra5_validateReceivingHomePageIcon() {
		HomePage homeScreen = new HomePage();
		LoginPage login = new LoginPage();
		ReceivingPage receivingPage = new ReceivingPage();

		login.loginInMRA(this.getProperty("valid_storeno2"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));

		homeScreen.clickOnReceiving();
		String displayedReceivingTitle = homeScreen.captureHeadingInReceivingHomePage();
		Assert.assertEquals(displayedReceivingTitle, "RECEIVING HOME");
		logger.info(displayedReceivingTitle + " Heading is Displayed in the Receiving Home Page");

		receivingPage.isDcShpmentDisplayed();
		receivingPage.isPurchaseOrdersDisplayed();
		receivingPage.isStoreToStoreTransferDisplayed();

	}
}
