package com.pdt.loginTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.AuditingInTransitDamagesScanPage;
import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.MispicksScanPage;
import com.pdt.Pom.ReceivingShipmentPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Screen Scroll in DC Shipment and Auditing")
@Description("Validate able to scroll in DC Shipment and Auditing")

public class SRA_676_1558_ScreenScrollInDCShipmentAndAuditing extends BaseTest {
	final static Logger logger = Logger.getLogger(SRA_676_1558_ScreenScrollInDCShipmentAndAuditing.class);

	public void SRA1558_ValidateScreenScrollInDCShipmentAndAuditing() throws IOException, ParseException {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		AuditingPage auditingPage = new AuditingPage();
		AuditingInTransitDamagesScanPage inTransitDamagePage = new AuditingInTransitDamagesScanPage();
		MispicksScanPage mispicksScanPage = new MispicksScanPage();

		Document doc = createDocFromFile("Mispicks_MultipleSku.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("EtaDateTime", ExpectedArrival);
		updateDocToDb(doc);

		@SuppressWarnings("unchecked")
		String cartonNumber = ((List<Document>) doc.get("Cartons")).get(0).getString("CartonNumber");
		logger.info("carton Number is  " + cartonNumber);

		login.loginInMRA(getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));

		homescreen.clickOnMenuBar();
		homescreen.clickOnDCShipmentsOnSideMenuBar();
		receivingShipment.scrollInDCShipmentHomePage();
		receivingShipmentScanPage.addCartonAsScanned(cartonNumber);
		receivingShipmentScanPage.scrollInCartonDetailPage();

		receivingShipmentScanPage.swipeCartonForDamageYes(cartonNumber);
		receivingShipmentScanPage.submitScannedCarton();

		homescreen.clickOnMenuBar();
		homescreen.clickOnAuditingOnSideMenuBar();
		auditingPage.clickInTransitDamages();
		inTransitDamagePage.scrollInCartonDetailPageInTransitDamages(cartonNumber);

		homescreen.clickOnMenuBar();
		homescreen.clickOnAuditingOnSideMenuBar();
		auditingPage.clickMispicks();
		mispicksScanPage.addMispickedCarton(cartonNumber);
		mispicksScanPage.scrollInCartonDetailPageInMispick(cartonNumber);
	}

}
