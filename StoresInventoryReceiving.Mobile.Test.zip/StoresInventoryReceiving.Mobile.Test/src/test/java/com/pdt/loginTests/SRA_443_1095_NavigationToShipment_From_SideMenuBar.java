package com.pdt.loginTests;

import org.apache.log4j.Logger;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Verify sideMenuBar icons and navigation to respective home pages")
@Description("Verify sideMenuBar icons and navigation to respective home pages")


public class SRA_443_1095_NavigationToShipment_From_SideMenuBar extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA443_1095");
	SoftAssert softassert =new SoftAssert();
	
	public void navigation_To_And_from_sideMenuBar() {
		
		LoginPage login = new LoginPage();
		login.loginInMRA(this.getProperty("valid_storeno2"), this.getProperty("valid_username9792"), this.getProperty("valid_password9792"));
		HomePage homeScreen=new HomePage();
		homeScreen.clickOnMenuBar();
		
		String displayedHeading=homeScreen.captureHeadingInMenuBar();
		softassert.assertEquals(displayedHeading, "Store Receiving");
		logger.info(displayedHeading +" Heading is Displayed in the MenuBar");	
		
		logger.info("To Validate if all the menu icons are Displayed in the Menu Bar");	
		homeScreen.validateMenuIconsInSideMenuBar();
		
		
	   logger.info("To Validate if the Home icon in the menu bar navigates to homepage");
	   homeScreen.navigateToHomePageOnSideMenuBar(softassert);
	  
		
		logger.info("To validate if all the major icons are displayed in the Receiving Home Page");
		homeScreen.navigateToReceivingPageOnSideMenuBar(softassert);
		
		
		logger.info("To validate if associate is able to navigate to the respective receiving pages from sidemenu bar");
		homeScreen.navigateToDCShipmentsOnSideMenuBar(softassert);
		homeScreen.navigateToPurchaseOrdersOnSideMenuBar(softassert);
		homeScreen.navigateToStoreTransfersOnSideMenuBar(softassert);
		
		logger.info("To validate if associate is able to navigate to the Auditing Home Page from sidemenu bar");
		homeScreen.navigateToAuditingPageOnSideMenuBar(softassert);
		
		logger.info("To validate if associate is able to navigate to the ItemLookup Home Page from sidemenu bar");
		homeScreen.navigateToItemLookUpPageOnSideMenuBar(softassert);
		
		logger.info("To validate if associate is able to navigate to the Setup Printer Home Page from sidemenu bar");
		homeScreen.navigateToSetupPrinterWifiOnSideMenuBar(softassert);
		homeScreen.navigateToSetupPrinterBluetoothOnSideMenuBar(softassert);
		softassert.assertAll();
		}
	
}