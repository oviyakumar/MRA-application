package com.pdt.loginTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.PurchaseOrderPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Screen Scroll in Purchase Order and Receive transfer")
@Description("Validate able to scroll in PO and Receive Transfer")

public class SRA_676_1558_ScreenScrollInPOAndReceiveTransfer extends BaseTest{
	final static Logger logger = Logger.getLogger(SRA_676_1558_ScreenScrollInPOAndReceiveTransfer.class);
	
	 
	public void SRA1558_ValidateScreenScrollInPOAndReceiveTransfer() throws IOException, ParseException {
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		PurchaseOrderPage purchaseOrder = new PurchaseOrderPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		
		
		
		Document doc = createDocFromFile("PO130.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 10);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("ETADateTime", ExpectedArrival);
		updateDocInPOCollection(doc);
		
		String purchaseOrderNumber = doc.getString("PurchaseOrderNumber");
		logger.info("PO is Number " + purchaseOrderNumber);
		
		Document doctransfer = createDocFromFile("StoresSRA676.json");
        String EtaDatetransfer = getDateIncementDay("yyyy-MM-dd", 7);
		Date ETATransfer = format.parse(EtaDatetransfer);
		doctransfer.put("ETADateTime", ETATransfer);
		updateDocToStoreTransferDb(doctransfer);

		String transferNumber = doctransfer.getString("TransferNumber");
		logger.info("Transfer Number is -------"+transferNumber);
		
		
		
		login.loginInMRA(getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));
		
		homescreen.clickOnReceiving();
		receivingPage.clickOnPurchaseOrder();
		
		purchaseOrder.scrollInHomePage();
		purchaseOrder.scrollInPODetailPage(purchaseOrderNumber);
		purchaseOrder.scrollInPrintTicketPage();
		
		
		
		homescreen.clickOnMenuBar();
		homescreen.clickOnStoreTransferOnSideMenuBar();
		sendnReceivetransfer.clickOnReceiveStoreTransfer();
		
		receiveStoreTransfer.scrollInReceiveTransferHomePage();
		receiveStoreTransfer.scrollInReceiveTransferDetailPage(transferNumber);
			
		
	}
	
	
	
	
}
