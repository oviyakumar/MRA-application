package com.pdt.purchaseOrderTest;


import static com.util.BaseUtil.getDateIncementDay;


import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.PurchaseOrderPage;
import com.pdt.Pom.ReceivingPage;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "Purchase Order HomePage")
@Description("Serach for  new and partially Received Purchase Orders")
public class SRA129_1360_ValidatePurchaseOrderDetailInHomePage extends BaseTest {
	final static Logger logger = Logger.getLogger(SRA129_1360_ValidatePurchaseOrderDetailInHomePage.class.getName());
	
	
    public void SRA1360_ValidatePurchaseOrderDetailInHomePage(){
		
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		PurchaseOrderPage purchaseOrder=new PurchaseOrderPage();
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		SoftAssert softassert= new SoftAssert();
		
		try{
			Document doc = createDocFromFile("POwithSingleSku.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm");
            String EtaDate = getDateIncementDay("yyyy-MM-dd hh:mm", 30);
            Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			logger.info("date after icrement is" + doc.get("ETADateTime"));
			
			updateDocInPOCollection(doc);

			String storeNumber = doc.getString("DestinationStoreNumber");
			//String purchaseOrderNumber = doc.getString("PurchaseOrderNumber");
			
			

           login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			
			homescreen.clickOnReceiving();
			receivingPage.clickOnPurchaseOrder();
			String purchaseOrderNumber=validateFromMongoDB.getValidPONumberWithMultipleSku(storeNumber);
			logger.info("PO is Number " + purchaseOrderNumber);
			purchaseOrder.validatePOHeading(softassert);
			validateFromMongoDB.validatePurchaseOrderInHomePage(purchaseOrderNumber,softassert,storeNumber);
			softassert.assertAll();
			
			
		} catch (IOException | ParseException e) {
			
			e.printStackTrace();
		}
		
		
	}
    
    @SuppressWarnings("unchecked")
	public void SRA1360_ValidatePurchaseOrderDetailInHomePageForPartiallyReceivedPO(){
    	
    	LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		PurchaseOrderPage purchaseOrder=new PurchaseOrderPage();
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		SoftAssert softassert= new SoftAssert();
		
		try{
			Document doc = createDocFromFile("PO135.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm");
            String EtaDate = getDateIncementDay("yyyy-MM-dd hh:mm", 10);
            Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			logger.info("date after icrement is" + doc.get("ETADateTime"));
			int shippedQuantity= ((List<Document>)doc.get("SKUs")).get(0).getInteger("ShippedQuantity");
			logger.info("shippedQty is "+shippedQuantity);
			((List<Document>) doc.get("SKUs")).get(0).put("ReceivedQuantity", 3);
			
			updateDocInPOCollection(doc);

			String storeNumber = doc.getString("DestinationStoreNumber");
			String purchaseOrderNumber = doc.getString("PurchaseOrderNumber");
			logger.info("PO is Number " + purchaseOrderNumber);
			

           login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			
			homescreen.clickOnReceiving();
			receivingPage.clickOnPurchaseOrder();
			purchaseOrder.validatePOHeading(softassert);
			validateFromMongoDB.validatePurchaseOrderInHomePage(purchaseOrderNumber,softassert,storeNumber);
			softassert.assertAll();
			
		} catch (IOException | ParseException e) {
			
			e.printStackTrace();
		}
		
    }

}
