package com.pdt.purchaseOrderTest;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.PurchaseOrderPage;
import com.pdt.Pom.ReceivingPage;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Listeners(BaseListener.class)
@Test(description = "Purchase Order DetailPage")
@Stories("View the Details of PurchaseOrder in PO Detail Page")
@Description("Purchase Order DetailPage")
@Features("regression")
public class SRA130_1361_ViewDetailsOfPurchaseOrderInPODetailPage extends BaseTest {
	
	final static Logger logger = Logger.getLogger("SRA130_1361");
	
	public void SRA1361_ViewDetailOfPurchaseOrderForMultipleSku(){
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		
		try{
			Document doc = createDocFromFile("PO130.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateIncementDay("yyyy-MM-dd", 6);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			updateDocInPOCollection(doc);

			String storeNumber = doc.getString("DestinationStoreNumber");
			//String purchaseOrderNumber = doc.getString("PurchaseOrderNumber");
			

			
			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			
			homescreen.clickOnReceiving();
			receivingPage.clickOnPurchaseOrder();
			String purchaseOrderNumber=validateFromMongoDB.getValidPONumberWithMultipleSku(storeNumber);
			logger.info("PO is Number " + purchaseOrderNumber);
			purchaseOrderPage.validationInPODetailPageforMultipeSku(purchaseOrderNumber,storeNumber);
		} 
		catch (IOException | ParseException e) {
			
			e.printStackTrace();
		}
		

	}
}
