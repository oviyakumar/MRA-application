package com.pdt.purchaseOrderTest;

import static com.util.BaseUtil.getDateDecreaseDay;
import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;


import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.PurchaseOrderPage;
import com.pdt.Pom.ReceivingPage;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "Purchase Order HomePage")
@Description("View snapshot of all new and partially received Purchase Orders")
public class SRA128_1359_View_SnapshotOf_PurchaseOrder extends BaseTest {
	final static Logger logger = Logger.getLogger(SRA128_1359_View_SnapshotOf_PurchaseOrder.class.getName());
	
	
	public void SRA1359_View_SnapshotOf_Expected_PurchaseOrder(){
		
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		
		
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		
		try{
			Document doc = createDocFromFile("PO313.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
            Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			logger.info("date after icrement is" + doc.get("ETADateTime"));
			
			updateDocInPOCollection(doc);

			String storeNumber = doc.getString("DestinationStoreNumber");
			String purchaseOrderNumber = doc.getString("PurchaseOrderNumber");
			logger.info("PO is Number " + purchaseOrderNumber);
			
			Document doc135 = createDocFromFile("PO135.json");
            SimpleDateFormat format578 = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate135 = getDateDecreaseDay("yyyy-MM-dd", 30);
			Date ExpectedArrival135 = format578.parse(EtaDate135);
			doc135.put("ETADateTime", ExpectedArrival135);
			logger.info("date after decrement is" + doc135.get("ETADateTime"));
			logger.info("PO is Number " + doc135.getString("PurchaseOrderNumber"));
			
			
			updateDocInPOCollection(doc135);

			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			
			homescreen.clickOnReceiving();
			receivingPage.clickOnPurchaseOrder();
			
			validateFromMongoDB.validateExpectedPurchaseOrder(storeNumber);
			
			
		} catch (IOException | ParseException e) {
			
			e.printStackTrace();
		}
		
		
		
	}
	
//	public void SRA1359_ValidatePurchaseOrderETALessThan30Days(){
//		LoginPage login = new LoginPage();
//		HomePage homescreen = new HomePage();
//		ReceivingPage receivingPage = new ReceivingPage();
//		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();
//		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
//		try{
//			
//			Document doc = createDocFromFile("PO135.json");
//            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
//			String EtaDate = getDateDecreaseDay("yyyy-MM-dd", 31);
//			Date ExpectedArrival = format.parse(EtaDate);
//			doc.put("ETADateTime", ExpectedArrival);
//			logger.info("date after decrement is" + doc.get("ETADateTime"));
//			updateDocInPOCollection(doc);
//			
//			String storeNumber = doc.getString("DestinationStoreNumber");
//			String purchaseOrderNumber = doc.getString("PurchaseOrderNumber");
//			logger.info("PO is Number " + purchaseOrderNumber);
//			
//			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
//					this.getProperty("valid_password9792"));
//			
//			homescreen.clickOnReceiving();
//			receivingPage.clickOnPurchaseOrder();
//			purchaseOrderPage.validatePurchaseOrderNotFound(purchaseOrderNumber);
//			validateFromMongoDB.validateOldPurchaseOrderForETALessThan30(storeNumber);
//			
//		
//		}
//          catch (IOException | ParseException e) {
//			
//			e.printStackTrace();
//		}
//		
//		
//	}
//	
//	public void SRA1359_ValidatePurchaseOrderETAGreaterThan30Days(){
//		
//		LoginPage login = new LoginPage();
//		HomePage homescreen = new HomePage();
//		ReceivingPage receivingPage = new ReceivingPage();
//		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();
//		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
//		try{
//			
//			Document doc = createDocFromFile("PO135.json");
//            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
//			String EtaDate = getDateIncementDay("yyyy-MM-dd", 31);
//			Date ExpectedArrival = format.parse(EtaDate);
//			doc.put("ETADateTime", ExpectedArrival);
//			logger.info("date after increment is" + doc.get("ETADateTime"));
//			updateDocInPOCollection(doc);
//			
//			String storeNumber = doc.getString("DestinationStoreNumber");
//			String purchaseOrderNumber = doc.getString("PurchaseOrderNumber");
//			logger.info("PO is Number " + purchaseOrderNumber);
//			
//			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
//					this.getProperty("valid_password9792"));
//			
//			homescreen.clickOnReceiving();
//			receivingPage.clickOnPurchaseOrder();
//			purchaseOrderPage.validatePurchaseOrderNotFound(purchaseOrderNumber);
//			validateFromMongoDB.validateFuturePurchaseOrderForETAGreaterThan30(storeNumber);
//			
//		
//		}
//          catch (IOException | ParseException e) {
//			
//			e.printStackTrace();
//		}
//		
//		
//		
//	}
//	
//	@SuppressWarnings("unchecked")
//	public void SRA1359_ValidationForPendingQtyZeroNotDisplayed(){
//		LoginPage login = new LoginPage();
//		HomePage homescreen = new HomePage();
//		ReceivingPage receivingPage = new ReceivingPage();
//		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();
//		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
//		try{
//			Document doc = createDocFromFile("POwithSingleSku.json");
//			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
//            String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
//            Date ExpectedArrival = format.parse(EtaDate);
//			doc.put("ETADateTime", ExpectedArrival);
//			logger.info("date after icrement is" + doc.get("ETADateTime"));
//			int shippedQuantity= ((List<Document>)doc.get("SKUs")).get(0).getInteger("ShippedQuantity");
//			logger.info("shippedQty is "+shippedQuantity);
//			((List<Document>) doc.get("SKUs")).get(0).put("ReceivedQuantity", shippedQuantity);
//			
//			updateDocInPOCollection(doc);
//
//			String storeNumber = doc.getString("DestinationStoreNumber");
//			String purchaseOrderNumber = doc.getString("PurchaseOrderNumber");
//			logger.info("PO is Number " + purchaseOrderNumber);
//			
//			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
//					this.getProperty("valid_password9792"));
//			
//			homescreen.clickOnReceiving();
//			receivingPage.clickOnPurchaseOrder();
//			purchaseOrderPage.validatePurchaseOrderNotFound(purchaseOrderNumber);
//			validateFromMongoDB.validationForPendingQtyZeroInPO(storeNumber);
//		}
//		
//          catch (IOException | ParseException e) {
//			
//			e.printStackTrace();
//		}
//		
//	}
//	
//
}
