package com.util.DataBase;

import static com.util.AndroidDriverConfig.getProperty;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoDBManager {
	MongoClient client = null;
	MongoDatabase database = null;
	MongoCollection<Document> collection = null;
	MongoCollection<Document> fsFilesCollection = null;
	MongoCollection<Document> storeToStoreTransfer = null;
	MongoCollection<Document> purchaseOrder = null;
	MongoCollection<Document> plu = null;
	MongoCollection<Document> instoredamages = null;
	MongoCollection<Document> orphancollection = null;
	private static MongoDBManager mongoDBManager = null;

	private MongoDBManager() {

		Integer port = Integer.parseInt(getProperty("dbport"));
		client = new MongoClient(getProperty("mongoDBServerName"), port);
		database = client.getDatabase(getProperty("dbName"));

//		MongoClientURI uri = new MongoClientURI(
//				"mongodb://superuser:B35jQdVH@srarck-vdwn003.wsgcdev.local/?authSource=admin&authMechanism=SCRAM-SHA-1");
//		client = new MongoClient(uri);
//		database = client.getDatabase(getProperty("dbName"));
		
		collection = database.getCollection(getProperty("DcShipment"));
		fsFilesCollection = database.getCollection(getProperty("FSFilesCollection"));
		storeToStoreTransfer = database.getCollection(getProperty("storeToStoreTransferDB"));
		purchaseOrder = database.getCollection(getProperty("purchaseOrder"));
		plu = database.getCollection(getProperty("plu"));
		instoredamages = database.getCollection(getProperty("instoredamages"));
		orphancollection = database.getCollection(getProperty("OrphanCarton"));
	}

	public static MongoCollection<Document> getCollection() {
		if (mongoDBManager == null)
			mongoDBManager = new MongoDBManager();
		return mongoDBManager.collection;
	}

	public static MongoCollection<Document> getFsFilesCollection() {
		if (mongoDBManager == null)
			mongoDBManager = new MongoDBManager();
		return mongoDBManager.fsFilesCollection;
	}

	public static MongoCollection<Document> getStoreToStoreTransferCollection() {
		if (mongoDBManager == null)
			mongoDBManager = new MongoDBManager();
		return mongoDBManager.storeToStoreTransfer;
	}

	public static MongoCollection<Document> getPurchaseOrderCollection() {
		if (mongoDBManager == null)
			mongoDBManager = new MongoDBManager();
		return mongoDBManager.purchaseOrder;
	}

	public static MongoCollection<Document> getPLUCollection() {
		if (mongoDBManager == null)
			mongoDBManager = new MongoDBManager();
		return mongoDBManager.plu;
	}

	public static MongoCollection<Document> getInStoreDamageCollection() {
		if (mongoDBManager == null)
			mongoDBManager = new MongoDBManager();
		return mongoDBManager.instoredamages;
	}
	public static MongoCollection<Document> getOrphanCartonCollection() {
		if (mongoDBManager == null)
			mongoDBManager = new MongoDBManager();
		return mongoDBManager.orphancollection;
	}

//	
	public static void closeDBConnection() {

		if (mongoDBManager == null) {
			System.out.println("No DB connection");
		}

		else {
			mongoDBManager.client.close();
			mongoDBManager = null;
//		if(mongoDBManager != null && mongoDBManager.client != null ) {
//			mongoDBManager.client.close();
//			mongoDBManager=null;
//
		}
	}

}
