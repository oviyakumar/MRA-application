package com.util.DataBase;

import static com.util.AndroidDriverConfig.getProperty;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import org.apache.log4j.Logger;

public class OracleDBConnection {
	final static Logger logger = Logger.getLogger(OracleDBConnection.class.getName());
	
	public HashMap<String, String> getSkuPriceFromOracleDB(String skuNumber, String storeNumber)
			throws ClassNotFoundException, SQLException {
		logger.info("Getting Sku Price and Description from Oracle DB");	

		String dbUrl = "jdbc:oracle:thin:@" + getProperty("oracleDBHostname") + ":" + getProperty("oracleDBport") + ":"
				+ getProperty("oracleDBName");

		// Query to Execute
		String query = "select * from item_loc where item=? and loc=? ";

		// Load oracle jdbc driver
		Class.forName("oracle.jdbc.driver.OracleDriver");

		// Create Connection to DB
		Connection con = DriverManager.getConnection(dbUrl, getProperty("oracleDBusername"),
				getProperty("oracleDBPassword"));

		// Create Statement Object
		PreparedStatement prepStmt = con.prepareStatement(query);
		prepStmt.setString(1, skuNumber);
		prepStmt.setString(2, storeNumber);

		// Execute the SQL Query. Store results in ResultSet
		ResultSet rs = prepStmt.executeQuery();
		HashMap<String, String>  skuMap=new HashMap<String,String>();
		
		while (rs.next()) {
			
			String sku = rs.getString("ITEM");
			String store = rs.getString("LOC");
			String price = String.valueOf(rs.getFloat("SELLING_UNIT_RETAIL"));
			String description=rs.getString("LOCAL_SHORT_DESC");
			logger.info("sku   store    price");
			logger.info(sku + "  " + store + "  " + price);
			
			skuMap.put("skuNumber", sku);
			skuMap.put("skuStore", store);
			skuMap.put("skuprice", price);
			skuMap.put("skuDescShort", description);
			
		}
		// closing DB Connection
		rs.close();
		prepStmt.close();
		con.close();
		
		
		return skuMap;
	}

}
