package com.util;

import static com.util.AndroidDriverConfig.getProperty;

import java.io.File;
import java.net.URL;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class WebDriverConfig {
	
	public static WebDriver  webDriver=null;
	
	private static final Logger logger = Logger.getLogger(WebDriverConfig.class.getName());
	public static final String Download_File_Path = getProperty("hockeyAppDownloadPath");
	public static final String Chrome_Driver_Path=getProperty("chromeDriverPath");
	
	
	public WebDriverConfig(){
		
		HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
		chromePrefs.put("profile.default_content_settings.popups", 0);
		chromePrefs.put("download.default_directory", Download_File_Path);
		
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", chromePrefs);
		options.addArguments("--start-maximized");
		options.setAcceptInsecureCerts(true);
		options.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.ACCEPT);
		
		 String driverPath=getFilePath(Chrome_Driver_Path);
	     System.setProperty("webdriver.chrome.driver",driverPath);
	     webDriver = new ChromeDriver(options);
	}
	
	
	public  WebDriver getWebDriver(){		
		return webDriver;
	}
	
	public String getFilePath(String fileName){
		fileName = "/webdriver/" + fileName;
		URL url = getClass().getResource(fileName);
		File file = new File(url.getPath());
		String filePath = file.getAbsolutePath();
		logger.info("filePath "+filePath);
		return filePath;
	}
	
		

}
