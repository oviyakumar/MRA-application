package com.util;

import static java.lang.System.getProperties;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AutomationName;
import io.appium.java_client.remote.MobileCapabilityType;

public class AndroidDriverConfig {
	private static final Logger logger = Logger.getLogger(AndroidDriverConfig.class.getName());

	public static AndroidDriver<MobileElement> driver;
	private static Properties property;
	public static final String PROPERTY_FILE_NAME = "/config/androidRepo.properties";

	private static final String PATH_TO_ENV_PROPERTIES = PROPERTY_FILE_NAME.toLowerCase();
	private static final Properties ENV_PROPERTIES = getProperties();
	
	//private AppiumDriverLocalService service;
	//private AppiumServiceBuilder builder;

	private static Properties properties = new Properties();

	static {

		try (final InputStream loadPropertiesStream = AndroidDriverConfig.class.getClass()
				.getResourceAsStream(PATH_TO_ENV_PROPERTIES)) {
			properties.load(loadPropertiesStream);
			properties.putAll(ENV_PROPERTIES);
			logger.info("Loaded properties file [" + PATH_TO_ENV_PROPERTIES + "]");

		} catch (IOException e) {
			throw new RuntimeException("Can't load config resources [" + PATH_TO_ENV_PROPERTIES + "]", e);

		} catch (NullPointerException e) {
			throw new RuntimeException("Config resources is [null]", e);
		}
	}

	public void setAndroidDriver() throws IOException {
		DesiredCapabilities capabilities = new DesiredCapabilities();

		capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.ANDROID_UIAUTOMATOR2);
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Honeywell");
		capabilities.setCapability(MobileCapabilityType.APP, getProperty("apk_file_location"));
	    capabilities.setCapability("avd", "Honeywell");
		
		

		driver = new AndroidDriver<MobileElement>(new URL(getProperty("appium_server_url")), capabilities);
		//driver = new AndroidDriver<MobileElement>(capabilities);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	public void quitDriver() {
		driver.quit();
	}

	public static synchronized String getProperty(final String propKey) {

		if (properties.containsKey(propKey)) {
			logger.debug(
					"TID [" + Thread.currentThread().getId() + "] " + "Was loaded property (key) [" + propKey + "]");
		} else {
			logger.debug("Property (key) [" + propKey + "] was NOT found.");
		}

		return properties.getProperty(propKey);
	}

	public static synchronized void setProperty(final String propKey, final String propValue) {

		logger.info("Update property [" + propKey + "]");
		properties.put(propKey, propValue);
	}

	public static AndroidDriver<MobileElement> getAndroidDriver() {
		return driver;
	}
	
	public void clearData(){
		driver.resetApp();
		logger.info("Clear Data Method is invoked");
	}

}
