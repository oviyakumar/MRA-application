package com.pdt.Pom;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.web.template.AndroidBasePage;

import ru.yandex.qatools.allure.annotations.Step;

public final class LoginPage extends AndroidBasePage {

	protected By mainMenu = By.xpath("//android.widget.ImageButton[@content-desc='Open']");
	protected By storeNumber = By.id("com.si:id/txtLogin_StoreNo");

	private By associateId = By.id("com.si:id/txtLogin_UserName");
	private By password = By.id("com.si:id/txtLogin_Password");
	private By loginButton = By.id("com.si:id/btnLogin_Login");
	private By errorMessage = By.id("com.si:id/lblLogin_ErrorMsg");
	private By storeLabel = By.id("com.si:id/lblLogin_StoreNo");
	protected By receivingButton = By.id("com.si:id/btn_Home_Receiving");

	public Object pdtClickStoreNumber;
	final static Logger logger = Logger.getLogger(LoginPage.class.getName());

	@Step("Login to the application")
	public void loginInMRA(String sNumber, String uName, String pword) {
		if (isDisplayedWithoutWait(storeLabel)) {
			elementClick(storeLabel);
			clearTextField(storeNumber);

		}
		setText(storeNumber, sNumber);
		setText(associateId, uName);
		setText(password, pword);
		elementClick(loginButton);
		fluentWait(receivingButton);
		logger.info("Logged in Store is " + sNumber);
		logger.info("Logged in Associate is " + uName);

	}

	@Step("Login to the application")
	public void loginWithRegisteredStore(String uName, String pword) {

		setText(associateId, uName);
		setText(password, pword);
		elementClick(loginButton);
		fluentWait(receivingButton);
	}

	@Step("Login to the application")
	public void login_With_Incorrect_Credentials(String sNumber, String uName, String pword) {
		setText(storeNumber, sNumber);
		setText(associateId, uName);
		setText(password, pword);
		elementClick(loginButton);
		fluentWait(errorMessage);
	}

	public boolean verifyErrorMessage() {
		return isDisplayed(errorMessage);

	}

	public boolean isLoginScreen() {
		return isDisplayed(storeNumber);
	}

	public String getStoreNumber() {
		return getText(storeLabel);
	}

	public void clearForm() {
		if (isDisplayedWithoutWait(storeLabel)) {
			elementClick(storeLabel);
			clearTextField(storeNumber);
		} else {
			clearTextField(storeNumber);
		}
		clearTextField(associateId);
		clearTextField(password);
	}

	public String captureErrorMessage() {
		fluentWait(errorMessage);
		return getText(errorMessage);
	}

}
