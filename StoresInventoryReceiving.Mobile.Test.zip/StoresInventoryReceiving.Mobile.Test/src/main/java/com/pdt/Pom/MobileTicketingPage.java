package com.pdt.Pom;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;

import java.time.Duration;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.web.template.AndroidBasePage;

import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import ru.yandex.qatools.allure.annotations.Step;

public class MobileTicketingPage extends AndroidBasePage {
	final static Logger logger = Logger.getLogger(MobileTicketingPage.class.getName());
	
	protected By skuPriceTextBox=By.id("com.si:id/txtTicketing_EditSKUDetails_SKUPrice");
	protected By printQtyTextBox=By.id("com.si:id/txtTicketing_EditSKUDetails_PrintQTY");
	protected By cancelButtonOnSkuEdit = By.id("com.si:id/btnTicketing_EditSKUDetails_Cancel");
	protected By skuNoOnSkuEditScreen = By.id("com.si:id/txtTicketing_EditSKUDetails_SKUNumber");
	protected By skuDescOnSkuEditScreen = By.id("com.si:id/txtTicketing_EditSKUDetails_SKUDesc");
	protected By editSkuImage = By.id("com.si:id/Ticketing_img_SKUDescDetails_Edit");
	protected By noItemsAvailableMsgForInvalidSku = By.id("com.si:id/Ticketing_SKUSearchResult");
	protected By okButtonOnPrinterMsg = By.id("android:id/button1");
	protected By noPrinterConnectionErrorMsg = By.id("android:id/message");
	protected By withOutPriceLabel = By.id("com.si:id/Ticketing_btnWithOutPrice");
	protected By withPriceLabel = By.id("com.si:id/Ticketing_btnWithPrice");
	protected By printTicketLabel = By.id("com.si:id/Ticketing_lblPopUp_Message");
	protected By printerImage = By.id("com.si:id/Ticketing_Print");
	protected By skuPrintQtyInSkuDetail = By.id("com.si:id/Ticketing_SKUDescDetails_PrintQuantity");
	protected By skuPriceInSkuDetail = By.id("com.si:id/Ticketing_SKUDescDetails_SKUPrice");
	protected By skuDescInSkuDetail = By.id("com.si:id/Ticketing_SKUDescDetails_SKUDescription");
	protected By searchBoxItemLookUp = By.id("com.si:id/Ticketing_SKUSearch");
	protected By searchButtonOnItemLookUp = By.id("com.si:id/Ticketing_ImagebtnSearch");
	protected By skuNumberInSkuDetail = By.id("com.si:id/Ticketing_SKUDescDetails_SKUNumber");
	protected By saveButtonOnSkuEdit=By.id("com.si:id/btnTicketing_EditSKUDetails_Save");
	protected By editErrorMessage=By.id("com.si:id/Ticketing_SKUDetails_ErrorMessage");
	protected By itemLookUpHeading=By.id("com.si:id/Ticketing_LookUpSKU_Header");
	protected By toolBarHeading=By.id("com.si:id/txtToolbarTitle");
	protected By goBackOnLookUpHome=By.id("com.si:id/Ticketing_SKUDescDetails_btnGoBack");
	protected By receivingButton = By.id("com.si:id/btn_Home_Receiving");
	protected By itemLookUp=By.id("com.si:id/btn_Home_PriceLookup");
	protected By auditing=By.id("com.si:id/btn_Home_Audit");
	protected By clearImage=By.id("com.si:id/Ticketing_ImageClearText");
	
	protected By cartonNumberInTicketing=By.id("com.si:id/Ticketing_CartonDetails_CartonNumber");
	protected By cartonSkuQuantity=By.id("com.si:id/Ticketing_CartonDetails_NoofSKUs");
	protected By skuTotalQuantity=By.id("com.si:id/Ticketing_CartonDetails_TotalSKUQTY");
	
	protected By skuLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']");
	protected By skuDescLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='SKU Description']");
	protected By skuPriceLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='SKU Price']");
	protected By skuPrintQtyLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='Print QTY']");

	
	protected By cartonLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='Carton #']");
	protected By skuCountLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='No of SKUs']");
	protected By skuShippedQuantityLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='Total SKU QTY']");
	
	public String getSkuNumber(){
		return getText(skuNumberInSkuDetail);
	}
	
	public String getCartonNumber(){
		return getText(cartonNumberInTicketing);
	}
	
	public void validateSkuLabel(){
		boolean isSkuLabelDisplayed = isDisplayed(skuLabel);
		Assert.assertTrue(isSkuLabelDisplayed);
		
		boolean isSkuDescLabelDisplayed = isDisplayed(skuDescLabel);
		Assert.assertTrue(isSkuDescLabelDisplayed);
		
		boolean isSkuPriceLabelDisplayed = isDisplayed(skuPriceLabel);
		Assert.assertTrue(isSkuPriceLabelDisplayed);
		
		boolean isSkuPrintQtyLabelDisplayed = isDisplayed(skuPrintQtyLabel);
		Assert.assertTrue(isSkuPrintQtyLabelDisplayed);
	}

	public void validateSkuPriceAndDesc(String skuNumber,SoftAssert assertion,String dbPrice,String dbDescription) {
		enterSku(skuNumber);

		String skuNumberDisplayed=getSkuNumber();
		assertion.assertEquals(skuNumberDisplayed, skuNumber);

		String skuDesc = getSkuDescription();
		assertion.assertEquals(skuDesc,dbDescription);

		String skuPrice = getSkuPriceInLookUpScreen().replaceAll(",", "");
		Float price=Float.valueOf(skuPrice);
		assertion.assertEquals(String.valueOf(price),dbPrice);
		
		boolean isSkuPriceDisplayed = isDisplayed(skuPriceInSkuDetail);
		assertion.assertTrue(isSkuPriceDisplayed);
		
		String printQty=getPrintQTY();
		assertion.assertEquals(printQty, "1");
		
		logger.info("Sku Details are Displayed");

		boolean isPrinterImageDisplayed = isPrinterDisplayed();
		assertion.assertTrue(isPrinterImageDisplayed);

		clickOnPrinterImage();
		logger.info("Validating Print Label");
		
		boolean isLabelDisplayed = isPrintTicketLabelDisplayed();
		assertion.assertTrue(isLabelDisplayed);

		boolean isWithPriceLabelDisplayed = isWithPriceLabelDisplayed();
		assertion.assertTrue(isWithPriceLabelDisplayed);

		boolean isWithOutPriceLabelDisplayed = isWithOutPriceLabelDisplayed();
		assertion.assertTrue(isWithOutPriceLabelDisplayed);

		clickOnWithPriceLabel();
		boolean noPrinterConnectionMsg = isNoPrinterConnectionMsgDisplayed();
		assertion.assertTrue(noPrinterConnectionMsg);
		

		clickOnOkButton();

		clickOnPrinterImage();
		clickOnWithOutPriceLabel();

		boolean noPrinterConnectionMsgForWithoutPrice = isNoPrinterConnectionMsgDisplayed();
		assertion.assertTrue(noPrinterConnectionMsgForWithoutPrice);

		clickOnOkButton();
		
		validateSkuLabel();

	}

	public void clickOnOkButton() {
		logger.info("Clicking on OK Button");
		elementClick(okButtonOnPrinterMsg);
	}

	public boolean isNoPrinterConnectionMsgDisplayed() {

		return isDisplayed(noPrinterConnectionErrorMsg);
	}

	public void clickOnWithPriceLabel() {
		logger.info("Clicking on Print with Price Button");
		elementClick(withPriceLabel);

	}

	public boolean isWithOutPriceLabelDisplayed() {
		return isDisplayed(withOutPriceLabel);
	}

	public void clickOnWithOutPriceLabel() {
		logger.info("Clicking on Print without Price Button");
		elementClick(withOutPriceLabel);
	}

	public boolean isWithPriceLabelDisplayed() {

		return isDisplayed(withPriceLabel);
	}

	public boolean isPrintTicketLabelDisplayed() {
		return isDisplayed(printTicketLabel);

	}

	public boolean isPrinterDisplayed() {
		return isDisplayed(printerImage);

	}

	public void clickOnPrinterImage() {
		logger.info("Clicking on Print Image");
		elementClick(printerImage);
	}

	public String getSkuDescription() {
		return getText(skuDescInSkuDetail);
	}

	public void enterSku(String skuNumber) {
		setSkuInLookUpSku(skuNumber);
		clickOnSearchImage();
		fluentWait(skuNumberInSkuDetail);
	}
	
	public void enterCartonNumber(String cartonNumber) {
		setCartonInLookUpSku(cartonNumber);
		clickOnSearchImage();
		fluentWait(cartonNumberInTicketing);
	}

	public void setSkuInLookUpSku(String skuNumber) {
		logger.info("Entering Sku Number");
		clearTextField(searchBoxItemLookUp);
		setText(searchBoxItemLookUp, skuNumber);

	}
	
	public void setCartonInLookUpSku(String cartonNumber) {
		logger.info("Entering Carton Number");
		clearTextField(searchBoxItemLookUp);
		setText(searchBoxItemLookUp, cartonNumber);

	}

	public void clickOnSearchImage() {
		elementClick(searchButtonOnItemLookUp);
	}

	public boolean isCorrectSkuNoDisplayed() {
		return isDisplayed(skuNumberInSkuDetail);
	}

	public String getSkuPriceInLookUpScreen() {
		return getText(skuPriceInSkuDetail);
	}

	public String getPrintQTY() {
		return getText(skuPrintQtyInSkuDetail);
	}

	public void validateErrorMsgForInvalidSku(String skuNumber) {
		
		setSkuInLookUpSku(skuNumber);
		clickOnSearchImage();
		fluentWait(noItemsAvailableMsgForInvalidSku);
		
		String errorMessage=getText(noItemsAvailableMsgForInvalidSku);
		Assert.assertEquals(errorMessage, "No items available matching this number.");
		logger.info("Error Message is Displayed for Invalid Sku");

	}

	public boolean isNoItemAvailableMsgDisplayed() {
		return isDisplayed(noItemsAvailableMsgForInvalidSku);
	}

	public void validateLookUpSkuTestBarDisplayed(SoftAssert softAssert) {
		boolean isSearchBarDisplayed=isDisplayed(searchBoxItemLookUp);
		softAssert.assertTrue(isSearchBarDisplayed);
		logger.info("Search Bar is Displayed in ItemLookUp HomeScreen");
	}
	
	public void  IsItemLookUpHeadingDisplayed(){
		String itemLookUPHeading= getText(itemLookUpHeading).substring(0, 17);
		Assert.assertEquals(itemLookUPHeading, "Lookup SKU/Carton");
		logger.info("Heading Displayed in ItemLookUp HomeScreen is "+itemLookUPHeading);
	}
	
	public void  IsTicketingHeadingDisplayed(SoftAssert softAssert){
		String ticketingHeading= getText(toolBarHeading);
		softAssert.assertEquals(ticketingHeading, "TICKETING");
		logger.info("Heading Displayed in Ticketing HomeScreen is "+ticketingHeading);
	}
	
	public void clickGoBackOnLookUpHome(){
		logger.info("Clicking on GoBack Button");
		elementClick(goBackOnLookUpHome);
	}
	
	public void validateGoBackBtnInLookUpHomeScreen(SoftAssert softAssert){
		clickGoBackOnLookUpHome();
		String homePageHeading=getText(toolBarHeading);
		softAssert.assertEquals(homePageHeading, "HOME");
		logger.info("Heading Displayed in HomeScreen is "+homePageHeading);
		
		boolean isReceivingBtnDisplayed=isDisplayed(receivingButton);
		softAssert.assertTrue(isReceivingBtnDisplayed);
		
		boolean isLookUpBtnDisplayed=isDisplayed(itemLookUp);
		softAssert.assertTrue(isLookUpBtnDisplayed);
		
		boolean isAuditingBtnDisplayed=isDisplayed(auditing);
		softAssert.assertTrue(isAuditingBtnDisplayed);
		
		logger.info("Receving,ItemLookUp and Auditing Button is Displayed in HomeScreen");
		
	}

	public void validateSkuDescInEditSkuScreen(String skuNumber) {
		SoftAssert softAssert = new SoftAssert();
		enterSku(skuNumber);
		String skuDescHomeScreen=getSkuDescription();
		
		WebElement skuNo = driver.findElement(By.id("com.si:id/Ticketing_SKUDescDetails_SKUDescription"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnEditImage();
		
		logger.info("Validate Sku Details");	
		String skuNumberOnEditScreen = getSkuNoOnInTicketing();
		softAssert.assertEquals(skuNumberOnEditScreen, skuNumber);

		String skuDescOnEditScreen = getSkuDesc();
		softAssert.assertEquals(skuDescOnEditScreen, skuDescHomeScreen);
		
		boolean isSkuPriceLabelDisplayed = isDisplayed(skuPriceLabel);
		softAssert.assertTrue(isSkuPriceLabelDisplayed);
		
		boolean isSkuPrintQtyLabelDisplayed = isDisplayed(skuPrintQtyLabel);
		softAssert.assertTrue(isSkuPrintQtyLabelDisplayed);
		
		softAssert.assertAll();
		elementClick(cancelButtonOnSkuEdit);

	}

	public void clickOnEditImage() {
		logger.info("Clicking on Edit Image");	
		elementClick(editSkuImage);
	}

	public String getSkuNoOnInTicketing() {
		return getText(skuNoOnSkuEditScreen).substring(5);
	}

	public String getSkuDesc() {
		return getText(skuDescOnSkuEditScreen);
	}
	
	public void clickOnSaveButton(){
		elementClick(saveButtonOnSkuEdit);
	}
	
	public void clickOnCancelButton(){
		elementClick(cancelButtonOnSkuEdit);
	}
	
	public String getErrorMessage(){
		return getText(editErrorMessage);
	}

	public void EditSkuPriceAndQuantity() {
		WebElement skuNo = driver.findElement(By.id("com.si:id/Ticketing_SKUDescDetails_SKUDescription"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnEditImage();
		
	}
	
	public void setSkuPrice(String skuPrice) {
		logger.info("Changing SKU Price");
		clearTextField(skuPriceInSkuDetail);
		setText(skuPriceInSkuDetail, skuPrice);
	    elementClick(itemLookUpHeading);
	}
	
	public void setSkuPrintQuantity(String skuPrintQty) {
		logger.info("Changing SKU Quantity");
		clearTextField(skuPrintQtyInSkuDetail);
		setText(skuPrintQtyInSkuDetail, skuPrintQty);
		elementClick(itemLookUpHeading);
	}
	
	public void clickNextButton() {

		TouchAction touchAction = new TouchAction(driver);
		touchAction.tap(PointOption.point(700, 1200)).perform();

}
	@Step("Edit Valid Price")
	public void validateEditSkuPriceForValidPrice(String skuNumber,String price){
		enterSku(skuNumber);
		//EditSkuPriceAndQuantity();
		editSkuPrice(price);
		
		String priceOnLookUpScreen=getSkuPriceInLookUpScreen();
		Assert.assertEquals(priceOnLookUpScreen, price);
		logger.info("Price on LookupScreen After Edit is "+priceOnLookUpScreen);
	}
	
	@Step("Edit Price less than 0.97")
	public void editSkuPriceLessThanMinimum(String skuNumber,String price){
		clickOnClearImage();
		enterSku(skuNumber);
		//String priceOnLookUpScreen=getSkuPriceInLookUpScreen();
		//EditSkuPriceAndQuantity();
		editSkuPrice(price);
		clickOnWithPriceLabel();
		
		String errorMessage=getErrorMessage();
		Assert.assertEquals(errorMessage, "Please enter valid price.");
		//clickOnCancelButton();
		
//		String priceOnLookUpScreenAfterCancel=getSkuPriceInLookUpScreen();
//		assertEquals(priceOnLookUpScreen, priceOnLookUpScreenAfterCancel);
	}
	
	@Step("Validate Decimal Conversion for Edited price ")
	public void verifyDecimalConversion(String skuNumber,String price){
		clickOnClearImage();
		enterSku(skuNumber);
		//EditSkuPriceAndQuantity();
		//setSkuPrice(price);
		//clickOnSaveButton();
		editSkuPrice(price);
		
		String priceOnLookUpScreen=getSkuPriceInLookUpScreen();
		assertEquals(priceOnLookUpScreen, "9.00");
		logger.info("Price on LookupScreen After DecimalConversion is "+priceOnLookUpScreen);
	}
	
	@Step("Verify Able to Print Ticket After Editing")
	public void verifyAbleToPrintAfterEdit(String skuNumber, String price){
		logger.info("Editing SKU Price");
		clickOnClearImage();
		validateEditSkuPriceForValidPrice(skuNumber, price);

		boolean isWithPriceLabelDisplayed = isWithPriceLabelDisplayed();
		Assert.assertTrue(isWithPriceLabelDisplayed);

		boolean isWithOutPriceLabelDisplayed = isWithOutPriceLabelDisplayed();
		Assert.assertTrue(isWithOutPriceLabelDisplayed);
		
		clickOnWithPriceLabel();
		boolean noPrinterConnectionMsg = isNoPrinterConnectionMsgDisplayed();
		Assert.assertTrue(noPrinterConnectionMsg);
		
		clickOnOkButton();

		clickOnWithOutPriceLabel();
		boolean noPrinterConnectionMsgForWithoutPrice = isNoPrinterConnectionMsgDisplayed();
		Assert.assertTrue(noPrinterConnectionMsgForWithoutPrice);

		clickOnOkButton();
		
		logger.info("Able to Print Edited Sku Price and Quantity");
	}
	

	@Step("Edit Valid SKU Quantity")
	public void ValidateSkuPrintQuantity(String skuNumber,String printQty){
		enterSku(skuNumber);
		//EditSkuPriceAndQuantity();
		setSkuPrintQuantity(printQty);
		//clickOnSaveButton();
		
		String printQtyOnLookUpScreen=getPrintQTY();
		assertEquals(printQtyOnLookUpScreen, printQty);
		logger.info("PrintQty on LookupScreen After Edit is "+printQtyOnLookUpScreen);
	}
	
	@Step("Verify Not able to Edit Print Quantity to 0")
	public void VerifyNotAbleToEditPrintQuantityZero(String skuNumber,String printQty){
		clickOnClearImage();
		enterSku(skuNumber);
		//String printQtyOnLookUpScreen=getPrintQTY();
		//EditSkuPriceAndQuantity();
		setSkuPrintQuantity(printQty);
		//clickOnSaveButton();
		
		clickOnWithPriceLabel();
		String errorMessage=getErrorMessage();
		Assert.assertEquals(errorMessage, "Please enter valid print quantity.");
		//clickOnCancelButton();
		
		logger.info("Error Message displayed is : "+errorMessage);
//		String printQtyOnLookUpScreenAfterCancel=getPrintQTY();
//		assertEquals(printQtyOnLookUpScreenAfterCancel, printQtyOnLookUpScreen);
		
	}
	
	@Step("Verify Not able to Edit Print Quantity Above 99")
	public void VerifyNotAbleToEditPrintQuantityAbove99(String skuNumber,String printQty){
		clickOnClearImage();
		enterSku(skuNumber);
		//EditSkuPriceAndQuantity();
		setSkuPrintQuantity(printQty);
		//clickOnSaveButton();
		
		String printQtyOnLookUpScreen=getPrintQTY();
		assertEquals(printQtyOnLookUpScreen, "10");
		logger.info("PrintQty given is :"+printQty);
		logger.info("PrintQty on LookupScreen After Edit is :"+printQtyOnLookUpScreen);
	}
	
	public void validateSearchExitInTicketingHomePage(String skuNumber) throws InterruptedException{
    	
		    setSkuInLookUpSku(skuNumber);
			
		   boolean keyboardBefore=driver.isKeyboardShown();
			logger.info("Keyboard Displayed flag before search Exit in Ticketing :"+keyboardBefore);
			
			Thread.sleep(1000);
			TouchAction touchAction = new TouchAction(driver);
			touchAction.tap(PointOption.point(650, 190)).perform();
			
			boolean keyboardAfter=driver.isKeyboardShown();
			logger.info("Keyboard Displayed flag after search Exit in Ticketing:"+keyboardAfter);
			assertFalse(keyboardAfter);
		
	    }
	
	public void validateSkuPriceAndDescInTicketingPage(String skuNumber,String dbPrice,String dbDescription) {
		enterSku(skuNumber);
		
		logger.info("Validating SKU Details In Lookup Screen");

		String skuNumberDisplayed=getSkuNumber();
		Assert.assertEquals(skuNumberDisplayed, skuNumber);

		String skuDesc = getSkuDescription();
		Assert.assertEquals(skuDesc,dbDescription);

		String skuPrice = getSkuPriceInLookUpScreen().replaceAll(",", "");
		Float price=Float.valueOf(skuPrice);
		Assert.assertEquals(String.valueOf(price),dbPrice);
		
		boolean isSkuPriceDisplayed = isDisplayed(skuPriceInSkuDetail);
		Assert.assertTrue(isSkuPriceDisplayed);
		
		String printQty=getPrintQTY();
		Assert.assertEquals(printQty, "1");
		
		logger.info("Sku Details are Displayed");

		validateSkuLabel();

	}
	
	public void validatePrintButtonInTicketingPageForSKU(String skuNumber) {
		enterSku(skuNumber);
		validatePrintButtonInTicketingPage();
		
	}
	
	@Step("Edit Valid Price")
	public void editSkuPrice(String price){
		setSkuPrice(price);
	}
	
	public void clickOnClearImage(){
		logger.info("Clicking on Clear Image");
		elementClick(clearImage);
	}
	
	public String getCartonSkuQuantity() {
		return getText(cartonSkuQuantity);
	}
	
	public String getSkuTotalQuantity() {
		return getText(skuTotalQuantity);
	}
	
	public void validateCartonDetailsInTicketingPage(String cartonNumber,String SkuQuantityDB, String totalSkuQuantityDB) {
		enterCartonNumber(cartonNumber);
		
		logger.info("Validating Carton Details In Lookup Screen");

		String cartonNumberDisplayed=getCartonNumber();
		Assert.assertEquals(cartonNumberDisplayed, cartonNumber);

		String skuQuantity = getCartonSkuQuantity();
		logger.info("Total SKU Count In Lookup Screen "+skuQuantity);
		Assert.assertEquals(skuQuantity,SkuQuantityDB);
		
		String skuTotalQuantity = getSkuTotalQuantity();
		logger.info("Total Shipped Quantity in Lookup Screen "+skuTotalQuantity);
		Assert.assertEquals(skuTotalQuantity,totalSkuQuantityDB);

		logger.info("Carton Details are Displayed");

		validateCartonLabel();

	}
	
	public void validateCartonLabel(){
		boolean isCartonLabelDisplayed = isDisplayed(cartonLabel);
		Assert.assertTrue(isCartonLabelDisplayed);
		
		boolean isSkuCountLabelDisplayed = isDisplayed(skuCountLabel);
		Assert.assertTrue(isSkuCountLabelDisplayed);
		
		boolean isSkuQantityLabelDisplayed = isDisplayed(skuShippedQuantityLabel);
		Assert.assertTrue(isSkuQantityLabelDisplayed);
	}
	
	   @Step("Invalid Carton Number Search in ItemLookUp and Ticketing")
       public void validateErrorMsgForInvalidCarton(String cartonNumber) {
		
    	setCartonInLookUpSku(cartonNumber);
   		clickOnSearchImage();
		fluentWait(noItemsAvailableMsgForInvalidSku);
		
		String errorMessage=getText(noItemsAvailableMsgForInvalidSku);
		Assert.assertEquals(errorMessage, "No items available matching this number.");
		logger.info("Error Message is Displayed for Invalid Carton");
		
		logger.info("Checking whether Goback is displayed");
		boolean isGobackDisplayed = isDisplayed(goBackOnLookUpHome);
		Assert.assertTrue(isGobackDisplayed);

	}
	   @Step("Search valid carton Number in ItemLookUp and Ticketing")
	   public void searchValidCartonNumber(String cartonNumber){
		   logger.info("Search for valid carton number after invalid search");
		   clickOnClearImage();
		   enterCartonNumber(cartonNumber);
		   
		   logger.info("Validating Carton Details In Lookup Screen");
			String cartonNumberDisplayed=getCartonNumber();
			Assert.assertEquals(cartonNumberDisplayed, cartonNumber);
	   }
	   
	   public void validatePrintButtonInTicketingPageForCarton(String cartonNumber) {
		   enterCartonNumber(cartonNumber);
			validatePrintButtonInTicketingPage();		
		}
	   
	   public void validatePrintButtonInTicketingPage() {
			
			logger.info("Validating Print Button in LookUp Screen");

			boolean isWithPriceLabelDisplayed = isWithPriceLabelDisplayed();
			Assert.assertTrue(isWithPriceLabelDisplayed);

			boolean isWithOutPriceLabelDisplayed = isWithOutPriceLabelDisplayed();
			Assert.assertTrue(isWithOutPriceLabelDisplayed);
			
			clickOnWithPriceLabel();
			boolean noPrinterConnectionMsg = isNoPrinterConnectionMsgDisplayed();
			Assert.assertTrue(noPrinterConnectionMsg);
			
			clickOnOkButton();

			clickOnWithOutPriceLabel();
			boolean noPrinterConnectionMsgForWithoutPrice = isNoPrinterConnectionMsgDisplayed();
			Assert.assertTrue(noPrinterConnectionMsgForWithoutPrice);

			clickOnOkButton();
			
		}
	   
	   @Step("Validate Edit icon is not displayed for SKU")
	   public void validateEditIconIsDisabledForSKU(){
				WebElement skuNo = driver.findElement(By.id("com.si:id/Ticketing_SKUDescDetails_SKUDescription"));
				new TouchAction(driver)
						.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
								.withDuration(Duration.ofMillis(500)))
						.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
						.release().perform();
	
				boolean editImageNotDisplayed = isDisplayedWithoutWait(editSkuImage);
				assertFalse(editImageNotDisplayed);
				logger.info("Edit icon is not displayed as expected");
				
			}
	   
	   
	   
	   @Step("Validate Edit icon is not displayed for Carton")
	   public void validateEditIconIsDisabledForCarton(){
				WebElement skuNo = driver.findElement(By.id("com.si:id/Ticketing_CartonDetails_NoofSKUs"));
				new TouchAction(driver)
						.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
								.withDuration(Duration.ofMillis(500)))
						.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
						.release().perform();
	
				boolean editImageNotDisplayed = isDisplayedWithoutWait(editSkuImage);
				assertFalse(editImageNotDisplayed);
				logger.info("Edit icon is not displayed as expected");
				
			}

	   public void validateAbleToSearchCaseSensitiveCartonNumber(String cartonNumber,String SkuQuantityDB, String totalSkuQuantityDB) {
		   
		   String carton=cartonNumber.substring(0,13).concat(cartonNumber.substring(13).toLowerCase());
		   logger.info("Carton number is "+carton);
		   clickOnClearImage();
		   enterCartonNumber(carton);
			
			logger.info("Validating Carton Details In Lookup Screen");

			String cartonNumberDisplayed=getCartonNumber();
			Assert.assertEquals(cartonNumberDisplayed, cartonNumber);

			String skuQuantity = getCartonSkuQuantity();
			logger.info("Total SKU Count In Lookup Screen "+skuQuantity);
			Assert.assertEquals(skuQuantity,SkuQuantityDB);;
			
			String skuTotalQuantity = getSkuTotalQuantity();
			logger.info("Total Shipped Quantity in Lookup Screen "+skuTotalQuantity);
			Assert.assertEquals(skuTotalQuantity,totalSkuQuantityDB);

			logger.info("Carton Details are Displayed");

		}
	
}
