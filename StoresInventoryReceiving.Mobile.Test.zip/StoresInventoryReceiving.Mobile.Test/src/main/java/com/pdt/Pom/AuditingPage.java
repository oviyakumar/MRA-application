package com.pdt.Pom;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.asserts.SoftAssert;

import com.web.template.AndroidBasePage;

import ru.yandex.qatools.allure.annotations.Step;

public class AuditingPage extends AndroidBasePage {
	final static Logger logger = Logger.getLogger(AuditingInTransitDamagesScanPage.class.getName());
	SoftAssert softAssert=new SoftAssert();
	
	protected By auditingTitle= By.id("com.si:id/txtToolbarTitle");
	protected By inTransitDamages= By.id("com.si:id/imgAudit_Home_ITD");
	protected By inStoreDamages=By.id("com.si:id/imgAudit_Home_ISD");
	protected By misPicks=By.id("com.si:id/imgAudit_Home_MAD");
	protected By inTransitDamagesHeader= By.id("com.si:id/lblAuditITD_Home_Header");
	protected By inStoreDamagesHeader=By.id("com.si:id/lblAuditISD_Home_Header");
	protected By misPicksHeader=By.xpath("//android.widget.TextView[normalize-space(@text)='Mispicks']");
	
	protected By gobackButtonInTransitDamages=By.id("com.si:id/btnAuditITD_Home_Back");
	protected By gobackButtonInstoreDamages=By.id("com.si:id/btnAuditISD_Home_Back");
	protected By gobackButtonMispicks=By.id("com.si:id/btnAuditMAD_Home_Back");
	
	public void clickInTransitDamages() {
		logger.info("Clicking on InTransitDamages Button");
		elementClick(inTransitDamages);
	}
	
	public void clickInStoreDamages() {
		elementClick(inStoreDamages);
		
	}

	public void clickMispicks() {
		logger.info("Clicking on Mispick Button");
		elementClick(misPicks);
	}
	public void clickGoBackInTransitDamages() {
		elementClick(gobackButtonInTransitDamages);
	}
	public void clickGoBackInStoreDamages() {
		elementClick(gobackButtonInstoreDamages);
	}
	
	
	public boolean isInTransitDamagesBtnExist() {
		return isDisplayed(inTransitDamages);
		
	}
	
	public boolean isStoreDamagesDisplayed() {
		return isDisplayed(inStoreDamages);
	}
	public boolean isMispicksDisplayed() {
		return isDisplayed(misPicks);
	}
	public boolean isAuditingTitleDisplayed() {
		return isDisplayed(auditingTitle);
	}
	@Step("To capture the Heading In In-Transit Damages Screen")
	public String captureInTransitDamagesHeader() {
		fluentWait(inTransitDamagesHeader);
		return getText(inTransitDamagesHeader);
		
	}
	@Step("To capture the Heading In In-Store Damages Screen")
	public String captureInStoreDamagesHeader() {
		fluentWait(inStoreDamagesHeader);
		return getText(inStoreDamagesHeader);
		
	}
	@Step("To capture the Heading In Mispicks Screen")
	public String captureMispicksHeader() {
		fluentWait(misPicksHeader);
		return getText(misPicksHeader);
		
	}
	
	@Step("To capture the Auditing Heading ")
	public String captureAuditingHeader() {
		fluentWait(auditingTitle);
		return getText(auditingTitle);
		
	}
	
	
	public void navigateToInTransitDamagesPage(SoftAssert localassert) {
		isInTransitDamagesBtnExist();
		clickInTransitDamages();
		isAuditingTitleDisplayed();
		String InTransitHeader=captureInTransitDamagesHeader();
		localassert.assertEquals("In Transit Damages", InTransitHeader);
		logger.info(InTransitHeader +" Heading Displayed in In-Transit Damages home screen");
		clickGoBackInTransitDamages();
	}

	public void navigateToInStoreDamagesPage(SoftAssert localassert) {
		isStoreDamagesDisplayed();
		clickInStoreDamages();
		isAuditingTitleDisplayed();
		String InStoreHeader=captureInStoreDamagesHeader();
		localassert.assertEquals("In Store Damages", InStoreHeader);
		logger.info(InStoreHeader +" Heading Displayed in In-Store Damages home screen");
		clickGoBackInStoreDamages();
	}

	public void navigateToMispicksPage(SoftAssert localassert) {
		isMispicksDisplayed();
		clickMispicks();
		isAuditingTitleDisplayed();
		String MispicksHeader=captureMispicksHeader();
		localassert.assertEquals("Mispicks", MispicksHeader);
		logger.info(MispicksHeader +" Heading Displayed in mispicks home screen");
	}
}
