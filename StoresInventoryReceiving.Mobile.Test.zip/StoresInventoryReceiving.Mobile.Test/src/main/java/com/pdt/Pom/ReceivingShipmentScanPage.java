package com.pdt.Pom;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.text.ParseException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.util.DataBase.MongoDBManager;
import com.util.DataBase.MongoDBQueryStore;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.AndroidBasePage;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import ru.yandex.qatools.allure.annotations.Step;

public class ReceivingShipmentScanPage extends AndroidBasePage {
	final static Logger logger = Logger.getLogger(ReceivingShipmentScanPage.class.getName());
	//protected By visualSetUpSpecialHandling = By
			//.xpath("//android.widget.TextView[normalize-space(@text)='Visual Set Up']");
	protected By dcShipmentHeading=By.id("com.si:id/txtToolbarTitle");
	protected By displayedDateInShipmentHomePage=By.id("com.si:id/lblDCShip_ScanCarton_Date");
	protected By qtyHeadingInShipmentHomePage=By.id("com.si:id/lblDCShip_ScanCarton_PendingCount");
	protected By shortageLabelInShipmentSummery = By.xpath("//android.widget.TextView[@text='Shortage']");
	protected By visualSetUpSpecialHandling = By.id("android:id/message");
	protected By addButton = By.id("com.si:id/btnDCShip_ScanCarton_Add");
	protected By scanImageInCartonPage = By.id("com.si:id/imgDCShipOrp_CartonDetails_Home");
	protected By scanSkusMessageInCartonPage = By.id("com.si:id/lblDCShipOrp_CartonDetails_ScanMsg");
	protected By searchBarInInput = By.id("com.si:id/search_bar");
	protected By cartonInputButton = By.id("com.si:id/search_src_text");
	protected By enterButton = By.id("com.si:id/CartonManualScan");

	protected By addButtonOnBottom = By.id("com.si:id/btnDCShip_AddCarton_Add");

	protected By reEnterLast4Digits = By.id("com.si:id/txtPopUpTemplateNum");

	protected By enterButtonAfter4Digit = By.id("com.si:id/btnPopUpEnter");
	protected By searchBarAddSkuPage=By.id("com.si:id/search_src_text");
	protected By searchButtonAddSkuPage=By.id("com.si:id/search_button");
	protected By scannedCarton = By.id("com.si:id/liDCShip_ScanCarton_CartonNo");
	protected By cartonSearchResult = By.id("com.si:id/lblDCShip_AddCarton_CartonNo");
	protected By goBackButton = By.id("com.si:id/btnDCShip_AddCarton_Back");
	protected By goBackButton1 = By.xpath("//android.widget.TextView[normalize-space(@text)='Go Back']");
	protected By navigationButton = By.id("android:id/navigationBarBackground");
	protected By invalidCartonMsg = By.id("com.si:id/lblDCShip_AddCarton_CartonNo");
	protected By cartonNumberDoesNotMatchMsg = By.id("com.si:id/lblPopUpErrorMsg");
	protected By closeButtonSearchBar = By.id("com.si:id/search_close_btn");
	protected By specialHandlingMessage1 = By
			.xpath("//android.widget.TextView[normalize-space(@text)='Direct to Floor']");
	protected By okButtonOnSpecialHandlingMessage = By.xpath("//android.widget.Button[@text='OK']");
	protected By cancelButtonOnCartonMismatchMesgBox = By.id("com.si:id/btnPopUpCancel");
	protected By skuNumberInCarton = By.id("com.si:id/liDCShip_CartonDetails_SKUNo");
	protected By skuNumberList=By.id("com.si:id/liDCShipOrp_SKUDetails_SKUNo");
	protected By enterDamagedQty = By.id("com.si:id/imgDCShip_CartonDetails_Edit");
	protected By editDamagedQty = By.id("com.si:id/txtDCShip_EditSKU_SKUQty");
	protected By submitDamagedSkuQty = By.id("com.si:id/btnDCShip_EditSKU_Save");
	protected By cancelDamagedSkuQty = By.id("com.si:id/btnCancel");
	protected By cancelBtnBelowDamagedSKUQTY = By.id("com.si:id/btnDCShip_EditSKU_Cancel");
	protected By finalDamagedSkuQty = By.id("com.si:id/liDCShip_CartonDetails_DamSKUQty");
	protected By errorMsgOnExtraDamagedQty = By.id("com.si:id/lblDCShip_EditSKU_ErrorMsg");
	protected By goToShipmentSummery = By.id("com.si:id/btnDCShip_ScanCarton_ShipSummary");
	protected By goBackButtonInDetail=By.id("com.si:id/btnDCShipOrp_CartonDetails_Back");
	protected By valueOfShortage = By.id("com.si:id/txtVariance");
	protected By submitSummery = By.id("com.si:id/btnSubmit");
	protected By submitScannedCarton = By.id("com.si:id/btnDCShip_ShipSummary_Submit");
	protected By goBackButtonBelowShipmentSummery = By.id("com.si:id/btnDCShip_CartonDetails_Back");
	protected By goBackButtonCartonDetailPage = By.id("com.si:id/btnDCShip_CartonDetails_Back");
	protected By OkButtonScannedCartonSubmittedSuccessfully = By.id("android:id/button1");
	protected By cartonNumberOnDetailCarton = By.id("com.si:id/lblDCShip_CartonDetails_Header");
	protected By cartonNumberOnSkuListPage=By.id("com.si:id/lblDCShipOrp_CartonDetails_Header");
	protected By skuNumberOnSkuListPage=By.id("com.si:id/liDCShipOrp_SKUDetails_SKUNo");
	protected By skuNumberOnDetailPage = By.id("com.si:id/liDCShip_CartonDetails_SKUNo");
	protected By skuDescription = By.id("com.si:id/liDCShip_CartonDetails_SKUDesc");
	protected By skuQTY = By.id("com.si:id/liDCShip_CartonDetails_RecSKUQty");
	protected By damagedSKUQty = By.id("com.si:id/liDCShip_CartonDetails_SplHandling");
	protected By specialHanding = By.id("com.si:id/txtSplHandling");
	protected By imgIsScannedandNotOffline = By.id("com.si:id/imgIsScannedAndNotOffline");
	protected By pendingCartonCount = By.id("com.si:id/lblDCShip_ScanCarton_PendingCount");

	protected By expectedQtyInShipmentSummery = By.id("com.si:id/lblDCShip_ShipSummary_ExpQty");
	protected By scannedCartonsToBeSumitted = By.id("com.si:id/lblDCShip_ShipSummary_ToSubmitQty");
	protected By driverSignature = By.id("com.si:id/btnDCShip_ShipSummary_Signature");
	protected By continueScanningButton = By.id("com.si:id/btnDCShip_ShipSummary_Continue");
	protected By goToShipmentHomeButton = By.id("com.si:id/btnDCShip_ShipSummary_ShipHome");
	protected By receivedCartonOnShipmentSummery = By.id("com.si:id/lblDCShip_ShipSummary_RecQty");
	protected By valueOfShortageCarton = By.id("com.si:id/lblDCShip_ShipSummary_ShortageQty");
	protected By validSkuEntered = By.id("com.si:id/txtScannedCartonItem");
	protected By scannedCartonSubmittedMessage = By.id("android:id/message");
	protected By okButtonOnCartonSubmittedSuccessfully = By.id("android:id/button1");
	protected By firstscannedCarton = By.id("com.si:id/liDCShip_ScanCarton_CartonNo");

	protected By saveBtnOnDriverSign = By.id("com.si:id/btnDCShip_Signature_Save");
	protected By cancelButtonOnDriverSignature = By.id("com.si:id/btnDCShip_Signature_Cancel");
	protected By damagedCartonOnReceving = By.id("com.si:id/liDCShip_ScanCarton_CartonNo");

	protected By damagedSkuQtyValue = By.id("com.si:id/liDCShip_CartonDetails_DamSKUQty");
	protected By cancelBtnOnDamagedSkuScreen = By.id("com.si:id/btnDCShip_EditSKU_Cancel");
	protected By damagedCartonMessage=By.id("com.si:id/lblTemplate_MarkDamaged_Message");
	protected By damagedCartonYes=By.id("com.si:id/btnTemplate_MarkDamaged_Yes");
	protected By damagedCartonNo=By.id("com.si:id/btnTemplate_MarkDamaged_No");
	
	protected By skuLabel = By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']");
	protected By skuDescLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='SKU Description']");
	protected By skuQtyLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='SKU QTY']");
	protected By damagedSkuQtyLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='Damaged SKU QTY']");
	protected By specialHandlingLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='Special Handling']");

	protected By addButtonForAddingSKus=By.id("com.si:id/btnDCShipOrp_CartonDetails_Add");
	protected By skuNumberAddSkuPage=By.id("com.si:id/lblAuditMAD_AddSKU_SKUNo");
	protected By  skuDescriptionAddSkuPage=By.id("com.si:id/lblAuditMAD_AddSKU_SKUDesc");
	protected By  addButtonAddSkuPage=By.id("com.si:id/btnAuditMAD_AddSKU_Add");
    protected By  skuNumberInDetailPage=By.id("com.si:id/liAuditITDOrp_SKUDetails_SKUNo");
	protected By  qtyInDetailPage=By.id("com.si:id/liAuditITDOrp_SKUDetails_SKUQty");
	
	protected By cartonNumberCartonDetailPage=By.id("com.si:id/lblAuditITD_CartonDetails_CartonNo");
	protected By skuNummberCartonDetailPage=By.id("com.si:id/liDCShip_CartonDetails_SKUNo");
	protected By skuDescCartonDetailPage=By.id("com.si:id/liDCShip_CartonDetails_SKUDesc");
	protected By skuQtyCartonDetailPage=By.id("com.si:id/liDCShip_CartonDetails_ShipSKUQty");
	protected By receivedQtyCartonDetailPage=By.id("com.si:id/liDCShip_CartonDetails_RecSKUQty");
	protected By specialHandling=By.id("com.si:id/liAuditITD_CartonDetails_SplHandling");
	protected By goBackCartonDetailPage=By.id("com.si:id/btnDCShip_CartonDetails_Back");
	protected By goBackAddSkuPage=By.id("com.si:id/btnDCShipOrp_CartonDetails_Back");
	protected By skuReceivedQty=By.id("com.si:id/liAuditITD_CartonDetails_RecQty");
	protected By goBackInManualSkuAddPage=By.id("com.si:id/btnAuditMAD_AddSKU_Back");
	
	ReceivingShipmentPage receivingShipmentpage = new ReceivingShipmentPage();

	public void clickOnCancelBtnOnDamagedSkuQtyPage() {
		elementClick(cancelBtnBelowDamagedSKUQTY);

	}
	public void clickOnGoBackInManualSkuAddPage() {
		elementClick(goBackInManualSkuAddPage);

	}

	public void validateDriverSignatureWhenCancelled(String cartonNumber) {
		clickAddButton();
		enterCartonNumber(cartonNumber);
		clickSearchButton();
		clickOnAddButtonOnBottom();
		reEnter4CartonDigits(cartonNumber);
		elementClick(enterButtonAfter4Digit);
		clickOnShipmentSummery();
		clickOnDriverSignature();
		WebElement signatureBox = driver.findElement(By.id("com.si:id/background_image"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(signatureBox))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(signatureBox.getRect().getX() - 10,
						signatureBox.getRect().getY()))
				.release().perform();
		cancelBtnOnDriverSignature();

		boolean continueScanBtnDisplayed = continueScanButtonDisplayed();
		Assert.assertTrue(continueScanBtnDisplayed);

	}

	public void cancelBtnOnDriverSignature() {
		elementClick(cancelButtonOnDriverSignature);
	}

	public void clickOnSaveButtonAfterDriverSign() {
		elementClick(saveBtnOnDriverSign);
	}

	public void clickOnDriverSignature() {
		elementClick(driverSignature);

	}
	 @Step("To click on add button to manually add akus")
	public void clickOnAddButtonForAddingSkus() {
		elementClick(addButtonForAddingSKus);

	}
	public void validateDriverSignature(String cartonNumber) throws InterruptedException {

		clickAddButton();
		enterCartonNumber(cartonNumber);
		clickSearchButton();
		clickOnAddButtonOnBottom();
		reEnter4CartonDigits(cartonNumber);
		elementClick(enterButtonAfter4Digit);
		clickOnShipmentSummery();
		clickOnDriverSignature();

		WebElement signatureBox = driver.findElement(By.id("com.si:id/background_image"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(signatureBox))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(signatureBox.getRect().getX() - 10,
						signatureBox.getRect().getY()))
				.release().perform();
		clickOnSaveButtonAfterDriverSign();
		clickOnSubmitShipmentSummery();

		clickOnOKButtonOnCartonSubmittedSuccessfully();
		globalWait();

	}

	public String firstscannedCartonValue() {
		return driver.findElements(firstscannedCarton).get(0).getText();

	}

	public void initiateShipmentToViewScannedCartonsInShipmentSummery(String cartonNumber) {
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();

		receivingShipment.clickOnScanButton();
		clickAddButton();
		enterCartonNumber(cartonNumber);
		clickSearchButton();
		clickOnAddButtonOnBottom();
		reEnter4CartonDigits(cartonNumber);
		elementClick(enterButtonAfter4Digit);
		clickOnShipmentSummery();
		String scannedCartonValueInShipmentSummery = countOfScannedCartonsToBeSubmitted();
		Assert.assertEquals(scannedCartonValueInShipmentSummery, "1");
		boolean continueScanningLabelDisplayed = continueScanButtonDisplayed();
		Assert.assertTrue(continueScanningLabelDisplayed);

	}

	public void validatePartialShipmentExistInShipmentSummery(String shipmentNumber) {
		clickOnShipmentSummery();
		boolean continueScanningLabelDisplayed = continueScanButtonDisplayed();
		Assert.assertTrue(continueScanningLabelDisplayed);
		System.out.println(continueScanningLabelDisplayed);

		clickOnSubmitShipmentSummery();
		clickOnOKButtonOnCartonSubmittedSuccessfully();
		clickOnGoToShipmentHome();
		receivingShipmentpage.searchForShipmentNumberWhenPartiallyScanned(shipmentNumber);

	}

	public void clickOnGoToShipmentHome() {
		elementClick(goToShipmentHomeButton);
	}
 
	public void clickOnOKButtonOnCartonSubmittedSuccessfully() {
		logger.info("Clicking on OK Button");
		elementClick(okButtonOnCartonSubmittedSuccessfully);
	}

	public void validateShipmentNotVisibleInShipmentSummery(SoftAssert assertion) {
		clickOnShipmentSummery();

		clickOnSubmitShipmentSummery();
		boolean SubmittedMessageDisplayed = isSubmittedMessageDisplayed();
		assertion.assertTrue(SubmittedMessageDisplayed);

		elementClick(okButtonOnCartonSubmittedSuccessfully);
		clickOnGoToShipmentHome();
		receivingShipmentpage.searchForShipmentNumberWhenAlreadyScanned("1111026601104", assertion);

	}

	public boolean isSubmittedMessageDisplayed() {

		return isDisplayed(scannedCartonSubmittedMessage);

	}

	public String countOfShortageCarton() {
		return getText(valueOfShortageCarton);
	}

	public void clickOnContinueScanning() {
		elementClick(continueScanningButton);
	}

	public String valueInReceivedCarton() {
		return getText(receivedCartonOnShipmentSummery);
	}

	public boolean isDriverSignatureButtonDisplayed() {
		return isDisplayed(driverSignature);
	}

	public boolean continueScanButtonDisplayed() {
		return isDisplayed(continueScanningButton);
	}

	public boolean goToShipmentHomeButtonDisplayed() {
		return isDisplayed(goToShipmentHomeButton);
	}

	public String countOfScannedCartonsToBeSubmitted() {
		return getText(scannedCartonsToBeSumitted);
	}

	public String countOfReceivedCartonAfterSubmitScanned() {
		return getText(receivedCartonOnShipmentSummery);
	}

	public String countOfExpectedCartonsInShipmentSummery() {
		return getText(expectedQtyInShipmentSummery);
	}

	public String countOfPendingCartons() {
		return getText(pendingCartonCount);

	}

	public boolean validateCartonIsSubmitted() {
		return isDisplayed(imgIsScannedandNotOffline);
	}

	public boolean validateValidDamageSkuEntered() {
		return isDisplayed(validSkuEntered);
	}

	public String getSKUDescription() {
		return getText(skuDescription);
	}

	public String getSKUQty() {
		return getText(skuQTY);
	}

	public String getDamagedSkuQty() {
		return getText(damagedSKUQty);
	}

	public String getSpecialHandlingDesc() {
		return getText(damagedSKUQty);
	}

	public String getSkuNumberOnCartonDetailScreen() {
		return getText(skuNumberOnDetailPage);
	}

	public String getCartonNumberOnCartonDetailScreen() {
		return getText(cartonNumberOnDetailCarton);
	}
	
	public String getCartonNumberOnSkuListPage() {
		return getText(cartonNumberOnSkuListPage);
	}
	
	public ArrayList<MobileElement> getSkuNumberOnSkuListPage() {
		return (ArrayList<MobileElement>) getListText(skuNumberOnSkuListPage);
	}

	public void recivingCartonToValidateCartonDetail(String CartonNumber) {
		clickAddButton();
		enterCartonNumber(CartonNumber);
		clickSearchButton();
		clickOnAddButtonOnBottom();
		reEnter4CartonDigits(CartonNumber);
		elementClick(enterButtonAfter4Digit);
		clickOnScannedCarton();

	}

	public boolean isSpecialHandlingEnabled() {
		return isEnabled(specialHanding);
	}

	public void clickOnOkButtonOnCartonSucceefullySubmitted() {
		elementClick(OkButtonScannedCartonSubmittedSuccessfully);
	}

	public void clickOnGoBackButton() {
		elementClick(goBackButtonBelowShipmentSummery);
	}

	public void submitScannedCarton() {
		elementClick(goToShipmentSummery);
		fluentWait(submitScannedCarton, 20, 2);
		elementClick(submitScannedCarton);
		clickOnOkButtonOnCartonSucceefullySubmitted();

	}

	public void clickOnSubmitShipmentSummery() {
		elementClick(submitScannedCarton);
	}

//	public void clickOnShipmentSummery() {
//		elementClick(submitSummery);
//	}

	public void valueInShortageOfCartonInShipmentSummery() {
		getText(valueOfShortage);
	}

	public void clickOnShipmentSummery() {
		elementClick(goToShipmentSummery);
		fluentWait(submitScannedCarton, 20, 2);
	}

	public String validatingErrorMessage() {
		return getText(errorMsgOnExtraDamagedQty);
	}

	public String damagedSkuQtyOnDetailPage() {
		return getText(finalDamagedSkuQty);
	}

	public void clickOnDamagedQtyEditButton() {
		elementClick(enterDamagedQty);
	}

	public void setDamagedSkuQty(String DamagedQty) {
		setText(editDamagedQty, DamagedQty);
	}

	public void clickOnSaveButtonOnDamagedQty() {
		elementClick(submitDamagedSkuQty);
	}
	
	public void clickOnGoBackButtonOnCarton(){
		elementClick(goBackButtonInDetail);
	}

	public void markCartonAsDamaged(String CartonNumber, String DamagedQuantity, SoftAssert assertion) {

		ReceivingShipmentPage receivingShipmentPage = new ReceivingShipmentPage();

		receivingShipmentPage.clickOnScanButton();
		clickAddButton();
		enterCartonNumber(CartonNumber);
		clickSearchButton();
		clickOnAddButtonOnBottom();
		reEnter4CartonDigits(CartonNumber);
		elementClick(enterButtonAfter4Digit);
		clickOnScannedCarton();
		boolean isSkuDetailDisplayed = cartonlevelDetailDisplayed();
		assertion.assertTrue(isSkuDetailDisplayed);
		
		clickSkuNumber();
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();

		clickOnDamagedQtyEditButton();
		setDamagedSkuQty(DamagedQuantity);
		clickOnSaveButtonOnDamagedQty();
		logger.info("Carton Marked as Damage in Dc Shipment is "+CartonNumber);
		
	}

	public void clickOnCancelBtn() {
		elementClick(cancelBtnOnDamagedSkuScreen);

	}

	public void clickOnDamagedCartonDetail() {
		elementClick(damagedCartonOnReceving);
	}

	public void clickOnScannedCarton() {
		elementClick(scannedCarton);
	}

	public boolean cartonlevelDetailDisplayed() {
		return isDisplayed(skuNumberList);
	}
	
	public void clickSkuNumber(){
		elementClick(skuNumberList);
	}

	public void clickCancelButtonOnMsgBox() {
		elementClick(cancelButtonOnCartonMismatchMesgBox);
	}

	public String cartonNumberDoesNotMatchMessage() {

		return getText(cartonNumberDoesNotMatchMsg);
	}

	public boolean isSpecialHandlingMessageDisplayed() {
		return isDisplayed(specialHandlingMessage1);
	}

	public void clickOkButtonOnSpecialHandlingMessageBox() {
		elementClick(okButtonOnSpecialHandlingMessage);
	}

	public void initiateShipmentToValidateUnsavedScenario(String cartonNumber) throws ParseException {

		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		receivingShipment.clickOnScanButton();
		clickAddButton();
		enterCartonNumber(cartonNumber);
		clickSearchButton();
		clickOnAddButtonOnBottom();
		reEnter4CartonDigits(cartonNumber);
		elementClick(enterButtonAfter4Digit);
	}

	public void initiateShipmentToAddCartonAsReceived(String cartonNumber) throws ParseException {

		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		receivingShipment.clickOnScanButton();
		clickAddButton();
		enterCartonNumber(cartonNumber);

		clickSearchButton();
		clickOnAddButtonOnBottom();
		reEnter4CartonDigits(cartonNumber);
		elementClick(enterButtonAfter4Digit);
	}

	public void validatingInvalidCartonMsg(String cartonNumber) throws ParseException {

		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		receivingShipment.clickOnScanButton();
		clickAddButton();
		enterCartonNumber(cartonNumber);
		clickSearchButton();
	}
	public void validatingReturnToDriverMsg(String cartonNumber) throws ParseException {

		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		receivingShipment.clickOnScanButton();
		clickAddButton();
		enterCartonNumber(cartonNumber);
		clickSearchButton();
	}


	public void initiateShipmentToValidateSpecialHandlingCarton(String StoreNumber,String cartonNumber) throws ParseException {

		clickAddButton();
		enterCartonNumber(cartonNumber);
		clickSearchButton();
		clickOnAddButtonOnBottom();
		reEnter4CartonDigits(cartonNumber);
		elementClick(enterButtonAfter4Digit);

	}

	public void initiateShipmentWithINCorrectDigits(String cartonNumber) throws ParseException {
		SoftAssert assertion=new SoftAssert();
		clickAddButton();

		enterCartonNumber(cartonNumber);
		clickSearchButton();
		clickOnAddButtonOnBottom();
		reEnter4CartonDigitsIncorrectly("16R");

		String cartonNumberMismatchMessage = cartonNumberDoesNotMatchMessage();
		assertion.assertEquals(cartonNumberMismatchMessage, "Incorrect Entry. Please enter again");
		clickCancelButtonOnMsgBox();
		assertion.assertAll();

	}

	public boolean IsScannedCartonDisplayed() {
		return isDisplayed(scannedCarton);
	}

	public String invalidCartonNumberMsg() {
		return getText(invalidCartonMsg);
	}

	public void validatingDuplicateCartonNumber(String cartonNumber) {

//		ReceivingShipmentPage receivingShipmentPage = new ReceivingShipmentPage();
//		receivingShipmentPage.clickOnScanButton();

		clickAddButton();
		enterCartonNumber(cartonNumber);
		clickSearchButton();
		elementClick(cartonSearchResult);

		String duplicateCartonMsg = duplicateCartonMessage();
		Assert.assertEquals(duplicateCartonMsg, "Carton# "+cartonNumber+" already scanned. Navigate to Auditing -> Mispicks to add more SKUs");
        logger.info("Message displayed is "+duplicateCartonMsg);
        
		boolean addButtonValue = addButtonOnBottomIsDisabled();
		Assert.assertFalse(addButtonValue);

		elementClick(goBackButton);

	}



	public String duplicateCartonMessage() {
		return getText(cartonSearchResult);

	}

	public boolean addButtonOnBottomIsDisabled() {
		return driver.findElement(addButtonOnBottom).isEnabled();
	}

//	private String getCartonNumber(String storeNumber) throws ParseException {
//
//		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
//		// BasePage basePage = new BasePage();
//		MongoCollection<Document> collection = MongoDBManager.getCollection();
//
//		BasicDBObject inTransitQuery = mongoDB.queryForCartonNumberforInTransitShipment(collection, storeNumber);
//		long shipmentCount = collection.count(inTransitQuery);
//		if (shipmentCount > 0) {
//			for (Document doc : collection.find(inTransitQuery)) {
//				if ((doc.get("Cartons") != null)) {
//					List<Document> cartons = (List<Document>) doc.get("Cartons");
//					for (Document carton : cartons) {
//						if (carton.get("IsScanned", false) == false)
//							return carton.getString("CartonNumber");
//					}
//				}
//
//			}
//		}
//
//		return null;
//	}

	public String getduplicateCartonNumber(String storeNumber) {
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		// BasePage basePage = new BasePage();
		MongoCollection<Document> collection = MongoDBManager.getCollection();

		BasicDBObject NoOfCarton = mongoDB.queryForDuplicateCartonNumberFromTransitShipment(collection, storeNumber);
		long shipmentCount = collection.count(NoOfCarton);
		if (shipmentCount > 0) {
			for (Document doc : collection.find(NoOfCarton).limit(1)) {
				if ((doc.get("Cartons") != null)) {
					List<Document> cartons = (List<Document>) doc.get("Cartons");
					for (Document carton : cartons) {
						if (carton.get("IsScanned", false) == true)
							return carton.getString("CartonNumber");
					}
				}

			}
		}

		return null;
	}

	public void clickOnEnterButton() {
		elementClick(enterButton);
	}

	public void clickAddButton() {
		logger.info("Clicking on Add Button");
		elementClick(addButton);
	}

	public void enterCartonNumber(String cartonNumber) {
		logger.info("Entering Carton Number");
		elementClick(searchBarInInput);
		setText(cartonInputButton, cartonNumber);

	}

	
	public void clickSearchButton() {
		logger.info("Clicking on Search icon");
		TouchAction touchAction=new TouchAction(driver);
		touchAction.tap(PointOption.point(700, 1200)).perform();
		//pressEnter();
	}

	public void clickOnAddButtonOnBottom() {
		fluentWaitForElementToBeEnabled(addButtonOnBottom, 20, 2);
		elementClick(addButtonOnBottom);

	}

	public void reEnter4CartonDigits(String cartonNumber) {
		setText(reEnterLast4Digits, cartonNumber.substring(cartonNumber.length() - 4, cartonNumber.length()));

	}

	public void reEnter4DigitsToValidateInGlobalSearch(String cartonNumber) {
		
		setText(reEnterLast4Digits, cartonNumber.substring(cartonNumber.length() - 4, cartonNumber.length()));
	}

	public String getSpecialHandlingText() {
		return getText(visualSetUpSpecialHandling).substring(0, 13);

	}

	public void reEnter4CartonDigitsIncorrectly(String cartonNumber) {

		setText(reEnterLast4Digits, "16R");
		elementClick(enterButtonAfter4Digit);
		fluentWait(cancelButtonOnCartonMismatchMesgBox, 20, 3);

	}

	public void clickOnEnterButtonAfter4Digit() {
		elementClick(enterButtonAfter4Digit);
		fluentWait(addButton, 20, 3);

	}

	public void clickOnEnterButtonAfterFourDigits() {
		elementClick(enterButtonAfter4Digit);
	}

	public void initiateShipment(String cartonNumber) {
		
		clickAddButton();
		enterCartonNumber(cartonNumber);
		clickSearchButton();
		clickOnAddButtonOnBottom();
		reEnter4CartonDigits(cartonNumber);
		elementClick(enterButtonAfter4Digit);
	}

	public String getDamagedSKUQty() {
		return getText(damagedSkuQtyValue);

	}

	public void addCartonAsReceived(String cartonNumber) throws ParseException {
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		receivingShipment.clickOnScanButton();
		clickAddButton();
		enterCartonNumber(cartonNumber);
		clickSearchButton();
		clickOnAddButtonOnBottom();
		reEnter4CartonDigits(cartonNumber);
		//elementClick(enterButtonAfter4Digit);
		clickEnterButton();
		clickEnterButton();
		clickOnShipmentSummery();
		clickOnSubmitShipmentSummery();
		clickOnOKButtonOnCartonSubmittedSuccessfully();
		logger.info("cartons successfully scanned and marked as received");
	}

	public void addCartonAsScanned(String cartonNumber) throws ParseException {

		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		receivingShipment.clickOnScanButton();
		clickAddButton();
		enterCartonNumber(cartonNumber);
		clickSearchButton();
		clickOnAddButtonOnBottom();
		reEnter4CartonDigits(cartonNumber);
		clickEnterButton();
		clickEnterButton();
		//elementClick(enterButtonAfter4Digit);
	}

	public void clickEnterButton() {
		TouchAction touchAction=new TouchAction(driver);
		touchAction.tap(PointOption.point(700, 1200)).perform();
		//pressEnter();
	}
	public void submitCartonAsReceived() throws ParseException {
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		receivingShipment.clickOnScanButton();
		clickOnShipmentSummery();
		clickOnSubmitShipmentSummery();
		clickOnOKButtonOnCartonSubmittedSuccessfully();
		logger.info("cartons successfully scanned and marked as received");
	}

    public void submitDamagedCarton(){
    	clickOnGoBackButtonOnCarton();
		clickOnShipmentSummery();
		clickOnSubmitShipmentSummery();
		clickOnOkButtonOnCartonSucceefullySubmitted();
	
     }

	public boolean isShortageLabelDisplayed() {
		return isDisplayed(shortageLabelInShipmentSummery);
		
	}

	public void validatingInvalidCartonMsgForInvalidETA(String cartonNumber) {
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		receivingShipment.clickOnScanButton();
		clickAddButton();
		enterCartonNumber(cartonNumber);
		clickSearchButton();
		
		
	}
	
	 @Step("Validated Edited Damaged Quantity In DC Shipment")
	 public void SRA1482_ValidateDamagedQuantityInReceiving(String damagedQty,String cartonNumber,SoftAssert localAssert){
		
		ReceivingShipmentPage receivingShipmentPage = new ReceivingShipmentPage();

		receivingShipmentPage.clickOnScanButton();
		elementClick(By.xpath("//android.widget.TextView[normalize-space(@text)='Carton #"+cartonNumber+"']"));
		clickSkuNumber();
		String damagedQtyInReceiving=getDamagedSKUQty();
		localAssert.assertEquals(damagedQtyInReceiving, damagedQty);
		logger.info("Damaged SKU Qty in DC shipment is "+damagedQtyInReceiving);
		
	}
	 
	 public void swipeCartonForDamage(String cartonNumber,SoftAssert localAssert){
		 
		 
		 WebElement cartonNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='Carton #"+cartonNumber+"']"));
			new TouchAction(driver)
					.longPress(new LongPressOptions().withElement(ElementOption.element(cartonNo))
							.withDuration(Duration.ofMillis(500)))
					.moveTo(new PointOption<>().withCoordinates(cartonNo.getRect().getX() - 10, cartonNo.getRect().getY()))
					.release().perform();
			String damageSwipeMsg=getText(damagedCartonMessage);
			localAssert.assertEquals(damageSwipeMsg, "Mark Item as Damaged?");
			elementClick(damagedCartonNo);
			elementClick(By.xpath("//android.widget.TextView[normalize-space(@text)='Carton #"+cartonNumber+"']"));
			clickSkuNumber();
			String qty = damagedSkuQtyOnDetailPage();
			localAssert.assertEquals("0", qty);
			logger.info("Damaged Quantity after selecting No is "+qty);
			
	 }

	public void validateSkuDetailsOfScannedCarton(String cartonNumber, SoftAssert assertion,String storeNumber) throws ParseException {
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		
		String cartonNumberInSkuListPage=getCartonNumberOnSkuListPage().substring(8);
        assertion.assertEquals(cartonNumberInSkuListPage, cartonNumber);
        
        clickSkuNumber();
        
		String cartonNumberInDetailPage=getCartonNumberOnCartonDetailScreen().substring(8);
		assertion.assertEquals(cartonNumberInDetailPage, cartonNumber);
		
		logger.info("To validate the sku labels displayed in the sku detail page");
		validateSkuLabel(assertion);
		
		//Validation in DB
		validateFromMongoDB.getSkuDetailsForScannedCartonSingleSku(cartonNumber,assertion, storeNumber);
		
		clickOnGoBackButtonInDetailPage();
		clickOnGoBackButtonOnCarton();
	   
		String displayedToolBarHeading=captureReceivingHeading();
		assertion.assertEquals(displayedToolBarHeading, "DC SHIPMENT");
		logger.info(displayedToolBarHeading +" Heading is Displayed in the Receiving Home Page");
		
	}
	

	public void clickOnGoBackButtonInDetailPage() {
		elementClick(goBackButtonCartonDetailPage);
		
	}

	public String captureReceivingHeading() {
		return getText(dcShipmentHeading);
	}
	
	
	public void validateSkuLabel(SoftAssert assertion){
		boolean isCartonLabelDisplayed = isDisplayed(cartonNumberOnDetailCarton);
		assertion.assertTrue(isCartonLabelDisplayed);
		
		boolean isSkuLabelDisplayed = isDisplayed(skuLabel);
		assertion.assertTrue(isSkuLabelDisplayed);
		
		boolean isSkuDescLabelDisplayed = isDisplayed(skuDescLabel);
		assertion.assertTrue(isSkuDescLabelDisplayed);
		
		boolean isSkuQtyLabelDisplayed = isDisplayed(skuQtyLabel);
		assertion.assertTrue(isSkuQtyLabelDisplayed);
		
		boolean isDamagedSkuQtyLabelDisplayed = isDisplayed(damagedSkuQtyLabel);
		assertion.assertTrue(isDamagedSkuQtyLabelDisplayed);
		
		boolean isSpecialHandlingLabelDisplayed = isDisplayed(specialHandlingLabel);
		assertion.assertTrue(isSpecialHandlingLabelDisplayed);
		logger.info("All the sku labels are displayed in the sku detail page");
		
	}

	public void validateSkuDetailsOfScannedCartonWithMultipleSku(String cartonNumber, SoftAssert assertion,String storeNumber) throws ParseException {
        ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		
        String cartonNumberInSkuListPage=getCartonNumberOnSkuListPage().substring(8);
        assertion.assertEquals(cartonNumberInSkuListPage, cartonNumber);
        
		
        validateFromMongoDB.getSkuDetailsForScannedCartonMultipleSku(cartonNumber, assertion, storeNumber);
		
        clickOnGoBackButtonOnCarton();
	   
		String displayedToolBarHeading=captureReceivingHeading();
		assertion.assertEquals(displayedToolBarHeading, "DC SHIPMENT");
		logger.info(displayedToolBarHeading +" Heading is Displayed in the Receiving Home Page");
		
	}
	public ArrayList<MobileElement> getSkuNumberListOnCartonDetailPage() {
		return (ArrayList<MobileElement>) getListText(skuNumberOnDetailPage);
	}
	public ArrayList<MobileElement> getSkuQtyListOnCartonDetailPage() {
		return (ArrayList<MobileElement>) getListText(skuQTY);
	}
	public ArrayList<MobileElement> getSkuDescriptionListOnCartonDetailPage() {
		return (ArrayList<MobileElement>) getListText(skuDescription);
	}
	public ArrayList<MobileElement> getDamagedSkuQtyListOnCartonDetailPage() {
		return (ArrayList<MobileElement>) getListText(finalDamagedSkuQty);
	}
	
 public void swipeCartonForDamageYes(String cartonNumber){
		 WebElement cartonNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='Carton #"+cartonNumber+"']"));
			new TouchAction(driver)
					.longPress(new LongPressOptions().withElement(ElementOption.element(cartonNo))
							.withDuration(Duration.ofMillis(500)))
					.moveTo(new PointOption<>().withCoordinates(cartonNo.getRect().getX() - 10, cartonNo.getRect().getY()))
					.release().perform();
			elementClick(damagedCartonYes);
			
	 }
	
	 public void scrollInCartonDetailPage(){
		    
			clickOnScannedCarton();

			MobileElement element=driver.findElementByClassName("android.support.v7.widget.RecyclerView");
			
			String isScrollable=element.getAttribute("scrollable");
	        logger.info("Scrollable flag In Carton DetailPage is :"+isScrollable);
	        assertEquals(isScrollable, "true");
	        
	        List<MobileElement>  skuNumberListOnCartonDetailPage = getSkuNumberListOnCartonDetailPage();
	        boolean isScrolled= scrollDownByElement(skuNumberListOnCartonDetailPage);
	        assertTrue(isScrolled);
	        
	        clickOnGoBackButtonInDetailPage();
	        
		}
	 
	 public String pageSource(){ 
	 String element=driver.getPageSource();
     return element;
	 }

	public void scanAndSubmitOrphanCartonWithoutSkus(String cartonNumber) {
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		
		receivingShipment.clickOnScanButton();
		clickAddButton();
        enterCartonNumber(cartonNumber);
		clickSearchButton();
		clickOnAddButtonOnBottom();
		reEnter4CartonDigits(cartonNumber);
		clickEnterButton();
		clickEnterButton();
	//	elementClick(enterButtonAfter4Digit);
		String orphanCartonNumber=firstscannedCartonValue().substring(8);
	    Assert.assertEquals(orphanCartonNumber, cartonNumber);
		clickOnScannedCarton();
		isDisplayed(cartonNumberOnSkuListPage);
		isDisplayed(scanImageInCartonPage);
		String defaultMessage=captureDefaultMessage();
		Assert.assertEquals(defaultMessage, "Start Scanning to receive missing SKUs");
		clickOnGoBackButtonOnCarton();
		clickOnShipmentSummery();
		clickOnSubmitShipmentSummery();
		clickOnOkButtonOnCartonSucceefullySubmitted();
		validateFromMongoDB.validateDetailsOfCreatedOrphanCarton(cartonNumber);
	}

	private String captureDefaultMessage() {
		return getText(scanSkusMessageInCartonPage);
	}

	public void scanAndSubmitOrphanCartonWithSkus(String orphanCartonNumber,String skuNumber) {
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		AuditingInTransitDamagesScanPage inTransitDamagePage = new AuditingInTransitDamagesScanPage();
		receivingShipment.clickOnScanButton();
		clickAddButton();
        enterCartonNumber(orphanCartonNumber);
		clickSearchButton();
		clickOnAddButtonOnBottom();
		reEnter4CartonDigits(orphanCartonNumber);
		clickEnterButton();
		clickEnterButton();
	//	elementClick(enterButtonAfter4Digit);
		String CartonNumber=firstscannedCartonValue().substring(8);
	    Assert.assertEquals(CartonNumber, orphanCartonNumber);
		clickOnScannedCarton();
		isDisplayed(cartonNumberOnSkuListPage);
		isDisplayed(scanImageInCartonPage);
		String defaultMessage=captureDefaultMessage();
		Assert.assertEquals(defaultMessage, "Start Scanning to receive missing SKUs");
		clickOnAddButtonForAddingSkus();
		logger.info("To validate error message while adding invalid sku");
		validateErrorMessageWhileAddingInValidSkuToCarton("222");
		logger.info("To add a valid sku to an orphan carton");
		validateAddingValidSkuToOrphanCarton(skuNumber);
		logger.info("To validate error message while adding an duplicate sku");
		validateErrorMessageWhileAddingDuplicateSkuToCarton(skuNumber);
		clickOnShipmentSummery();
		clickOnSubmitShipmentSummery();
		clickOnOKButtonOnCartonSubmittedSuccessfully();
		validateFromMongoDB.validateDetailsOfCreatedOrphanCarton(orphanCartonNumber);
			}
	public void enterSkuNumber(String skuNumber)  {
		elementClick(searchButtonAddSkuPage);
		setText(searchBarAddSkuPage, skuNumber);
		clickSearchButton();

	}
	public String getSkuNumberFromAddSkuPage() { 
		return getText(skuNumberAddSkuPage);
		
	}
	public void clickOnCloseButtonInSearchBar() {
		elementClick(closeButtonSearchBar);
	}
	public String getSkuDescriptionFromAddSkuPage() { 
		return getText(skuDescriptionAddSkuPage);
		
	}
	public String getSKUNumberCartonDetailPage() {
		return getText(skuNummberCartonDetailPage);
	}
	
	public String getSKUDescCartonDetailPage() {
		return getText(skuDescCartonDetailPage);
	}

	public void clickAddIconInAddSkuPage() {
		elementClick(addButtonAddSkuPage);
	}
	public String getSkuDescriptionCartonDetailPage() { 
		return getText(skuDescCartonDetailPage);
		
	}
	public String getSkuQtyCartonDetailPage() { 
		return getText(skuQtyCartonDetailPage);
		
	}
	public String getReceivedSkuQtyCartonDetailPage() { 
		return getText(receivedQtyCartonDetailPage);
	}
	public void clickOnGoBackCartonDetailPage(){
		elementClick(goBackCartonDetailPage);
	}
	
	public void clickOnGoBackInAddSku(){
		elementClick(goBackAddSkuPage);
	}
	public void clickSkuNumberFromAddSkuPage() {
		elementClick(skuNumberAddSkuPage);
	}

	// Method to Validate error message while Adding invalid sku to scanned cartons
		public void validateErrorMessageWhileAddingDuplicateSkuToCarton (String skuNumber) {
			clickOnAddButtonForAddingSkus();
			enterSkuNumber(skuNumber);
			logger.info("Sku Number added " + skuNumber);
			String errorMessageForDuplicateSku=getSkuNumberFromAddSkuPage();
			Assert.assertEquals(errorMessageForDuplicateSku, "Duplicate SKU number. Please try again");
			logger.info(errorMessageForDuplicateSku + " message displayed");
			clickSkuNumberFromAddSkuPage();
			clickOnGoBackInManualSkuAddPage();
		    clickOnGoBackInAddSku();
		}
		@Step("Method to Validate Adding valid extra sku to Orphan cartons")
		public void validateAddingValidSkuToOrphanCarton(String skuNumber) {
			clickOnCloseButtonInSearchBar();
			setText(searchBarAddSkuPage, skuNumber);
			clickSearchButton();
			logger.info("Sku Number added " + skuNumber);
			String skuNumberInAddSkuPage=getSkuNumberFromAddSkuPage();
			String skuDescriptionInAddSkuPage=getSkuDescriptionFromAddSkuPage();
			clickAddIconInAddSkuPage();
			clickSkuNumber();
			String skuNumberInCartonDetailPage=getSKUNumberCartonDetailPage();
			String skuDescriptionInCartonDetailPage=getSkuDescriptionCartonDetailPage();
			Assert.assertEquals(skuNumberInAddSkuPage, skuNumberInCartonDetailPage);
			Assert.assertEquals(skuDescriptionInAddSkuPage, skuDescriptionInCartonDetailPage);
			String skuQtyInCartonDetailPage=getSkuQtyCartonDetailPage();
			String receivedskuQtyInCartonDetailPage=getReceivedSkuQtyCartonDetailPage();
			Assert.assertEquals(skuQtyInCartonDetailPage, "0");
			Assert.assertEquals(receivedskuQtyInCartonDetailPage, "1");
			clickOnGoBackCartonDetailPage();

		}
		@Step("Method to Validate error message while Adding invalid sku to orphan cartons")
		public void validateErrorMessageWhileAddingInValidSkuToCarton (String skuNumber) {
					enterSkuNumber(skuNumber);
					logger.info("Sku Number added " + skuNumber);
					String errorMessageForInvalidSku=getSkuNumberFromAddSkuPage();
					Assert.assertEquals(errorMessageForInvalidSku, "SKU Number not found");
					logger.info(errorMessageForInvalidSku + " message displayed");
				}
		
		
		public void validateExpectedCartonQuantity(int qty) throws ParseException{
			
			String countOfPendingCartons = countOfPendingCartons();
			Assert.assertEquals(countOfPendingCartons, "QTY: " + qty);
		}
		
		public void validateExpectedCartonDetails(String cartonNumber,String skuNumber, int qty){
			recivingCartonToValidateCartonDetail(cartonNumber.substring(8));
			clickSkuNumber();
			String cartonNumberInDetailPage = getCartonNumberOnCartonDetailScreen();
			Assert.assertEquals(cartonNumberInDetailPage,cartonNumber);
			String skuNumberInDetailPage = getSkuNumberOnCartonDetailScreen();
			Assert.assertEquals(skuNumberInDetailPage,skuNumber );
			clickOnGoBackButton();
			clickOnGoBackButtonOnCarton();
			
			String countOfPendingCartons = countOfPendingCartons();
			Assert.assertEquals(countOfPendingCartons, "QTY: " + (qty - 1));
		}
		
		public void validateCartonDetailsInShipmentSummaryPage(int qty, String scannedCartonCount,String cartonCountAfterSubmit){
			
            clickOnShipmentSummery();
			
			boolean shortageLabel=isShortageLabelDisplayed();
			Assert.assertTrue(shortageLabel);
			
			String expectedCartons = countOfExpectedCartonsInShipmentSummery();
			Assert.assertEquals(expectedCartons, String.valueOf(qty));

			String scannedCartonsToBeSubmitted = countOfScannedCartonsToBeSubmitted();
			Assert.assertEquals(scannedCartonsToBeSubmitted, scannedCartonCount);

			boolean isContinueScanButtonDisplayed = continueScanButtonDisplayed();
			Assert.assertTrue(isContinueScanButtonDisplayed);

			boolean isGoToShipmentHomeButtonDisplayed = goToShipmentHomeButtonDisplayed();
			Assert.assertTrue(isGoToShipmentHomeButtonDisplayed);

			boolean isDriverSignatureButtonDisplayed = isDriverSignatureButtonDisplayed();
			Assert.assertTrue(isDriverSignatureButtonDisplayed);

			String NoOfreceivedCarton = valueInReceivedCarton();

			clickOnSubmitShipmentSummery();
			clickOnOkButtonOnCartonSucceefullySubmitted();
			
			// Validations after the carton is submitted

						String countOfScannedCartons = countOfScannedCartonsToBeSubmitted();
						String NoOfReceivedCartonAfterSubmit = countOfReceivedCartonAfterSubmitScanned();
						int NoOfShortageCartonAfterSubmit = Integer.parseInt(countOfShortageCarton());

						int finalShortageValue = Integer.parseInt(expectedCartons)
								- Integer.parseInt(NoOfReceivedCartonAfterSubmit);
						Assert.assertEquals(NoOfShortageCartonAfterSubmit, finalShortageValue);
						
						logger.info("value of Received Carton After Submit "+  NoOfReceivedCartonAfterSubmit );
						logger.info("value of shortage Carton After Submit "+  NoOfShortageCartonAfterSubmit );
						Assert.assertEquals(countOfScannedCartons, cartonCountAfterSubmit);

						Assert.assertEquals(Integer.parseInt(NoOfReceivedCartonAfterSubmit),
								Integer.parseInt(NoOfreceivedCarton) + 1);
						

			
		}
		
		@Step("Validate whether able to scan 200 carton or more in continues Scanning")
		public void ValidateBulkCartonScanning(String cartonNumber) {
			
			clickAddButton();
			enterCartonNumber(cartonNumber);
			clickSearchButton();
			clickOnAddButtonOnBottom();
			reEnter4CartonDigits(cartonNumber);
			elementClick(enterButtonAfter4Digit);
			elementClick(enterButtonAfter4Digit);
			fluentWait(goToShipmentSummery);
			
			boolean isScannedCartonDisplayed=isDisplayed(By.xpath("//android.widget.TextView[normalize-space(@text)='Carton #"+cartonNumber+"']"));
			Assert.assertTrue(isScannedCartonDisplayed);
			
			logger.info("Added Carton Number is Displayed");
		
		}
		
		@Step("Submit all the Received Carton ")
		public void submitAllReceivedCarton() {
			clickOnShipmentSummery();
			clickOnSubmitShipmentSummery();
			clickOnOKButtonOnCartonSubmittedSuccessfully();
			clickOnContinueScanning();
			logger.info("cartons successfully scanned and marked as received");
		}
	
		
}
