package com.pdt.Pom;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.text.ParseException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.util.BaseUtil;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.AndroidBasePage;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;

import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import ru.yandex.qatools.allure.annotations.Step;

public class ReceivingTransferPage extends AndroidBasePage {
	final static Logger logger = Logger.getLogger(ReceivingTransferPage.class.getName());
	SoftAssert softassert = new SoftAssert();
	protected By specialHandlingReprice = By.id("com.si:id/liST_SKUDescDetails_SplHandling");
	 
	protected By recdExceedsPopUp = By.id("com.si:id/lblSKUQtyMessage");
	protected By yesButtonOnRecdExceeds = By.id("com.si:id/btnPopUpYes");
	protected By specificSkuQtyDetail = By.id("com.si:id/liST_SKUDetails_SKUQty");
	protected By totalPendingSkuQty = By.id("com.si:id/lblST_SKUDetails_PndngSKUQty");
	protected By transferNumberTransferDetailPage = By.id("com.si:id/lblST_SKUDetails_TransferNo");
	protected By addButtonOnBottom = By.id("com.si:id/btnST_AddSKU_Add");
	protected By searchButtonOnSkuTransfer = By.id("com.si:id/search_button");
	protected By plusSignOnBottom = By.id("com.si:id/btnST_SKUDetails_Add");
	protected By specialHandlingInSkuDetails = By.id("com.si:id/liST_SKUDescDetails_SplHandling");
	protected By continueScanning = By.id("com.si:id/btnST_TransferSummary_ContinueScan");
	protected By okButtonOnSubmitReceiveTransfer = By.id("android:id/button1");
	protected By submitTransferSummery = By.id("com.si:id/btnST_TransferSummary_Submit");
	protected By transferSummery = By.id("com.si:id/btnST_SKUDetails_TransferSummary");
	protected By backButtonOnReceiveTransfer = By.id("com.si:id/btnST_SKUDescDetails_Back");
	protected By recdTransferIdOnReceiveHome = By.id("com.si:id/listST_TransferList_TransferNo");
	protected By skuNoAfterReceiveTransfer = By.id("com.si:id/liST_SKUDetails_SKUNo");
	protected By skuNumberOnTransferSummery = By.id("com.si:id/liST_SKUDescDetails_SKUNo");
	protected By searchBar = By.id("com.si:id/search_bar");
	protected By searchBarTextBox = By.id("com.si:id/search_src_text");
	protected By idToclickOnNewTransferIdInReceivingHome = By.id("com.si:id/liST_TransferList_PndngSKUQty");
	protected By editButtonToEditSku = By.id("com.si:id/imgST_SKUDescDetails_Edit");
	protected By inputBtnToEnterSkuQty = By.id("com.si:id/txtST_EditSKU_SKUQty");
	protected By saveButtonOnSkuEditScreen = By.id("com.si:id/btnST_EditSKU_Save");
	protected By recdSkuValueAfterEdit = By.id("com.si:id/liST_SKUDescDetails_RecSKUQty");
	protected By skuQtySkuDetailPage = By.id("com.si:id/liST_SKUDescDetails_SKUQty");
	protected By specificskuNumberList = By
			.xpath("//android.widget.TextView[@resource-id='com.si:id/liST_SKUDetails_SKUNo']");
	protected By specificSkuQty = By
			.xpath("//android.widget.TextView[@resource-id='com.si:id/liST_SKUDetails_SKUQty']");
	protected By specificSkuReceivedQty = By.id("com.si:id/txtST_SKUDetails_RecQty");
	protected By duplicateInvalidSkuNumberMessage = By.id("com.si:id/lblST_AddSKU_SKUResult");
	protected By goBackButtonOnAddSku = By.id("com.si:id/btnST_AddSKU_Back");
	protected By goBackButtonOnSkuDetailPage = By.id("com.si:id/btnST_SKUDetails_Back");
	protected By goBackButtonOnGlobalSearch = By.id("com.si:id/btnGSST_SKUDetails_Back");
	protected By receiveStoreTransferHeading = By.id("com.si:id/lblST_TransferList_Header");
	protected By transferNumberTransferHomePage = By.id("com.si:id/listST_TransferList_TransferNo");
	protected By totalskuQtyHomePage = By.id("com.si:id/liST_TransferList_PndngSKUQty");
	protected By fromStoreNumberHomePage = By.id("com.si:id/liST_TransferList_FromStore");
	protected By ETAOnHomePage = By.id("com.si:id/liST_TransferList_ETADate");
	protected By cancelButtonOnSkuEditScreen = By.id("com.si:id/btnST_EditSKU_Cancel");
	protected By alertmessageSkuEditScreen = By.id("com.si:id/lblSKUQtyMessage");
	protected By alertPopupYesSkuEditScreen = By.id("com.si:id/btnPopUpYes");
	protected By alertPopupNoSkuEditScreen = By.id("com.si:id/btnPopUpNo");
	protected By skuDescriptionSkuDetailPage = By.id("com.si:id/liST_SKUDescDetails_SKUDesc");
	protected By backButtonOnSkuDescription = By.id("com.si:id/btnST_SKUDescDetails_Back");
	protected By transferNumberInSkuDetailPage=By.id("com.si:id/lblST_SKUDescDetails_TransferNo");

	// Ids On Transfer summary page.
	protected By transferSummaryHeading = By
			.xpath("//android.widget.TextView[normalize-space(@text)='Transfer Summary']");
	protected By transferNumberTransferSummaryPage = By.id("com.si:id/lblST_TransferSummary_TransferNo");
	protected By expectedSkusTransferSummaryPage = By.id("com.si:id/lblST_TransferSummary_ExpSKUQty");
	protected By receivedSkusTransferSummaryPage = By.id("com.si:id/lblST_TransferSummary_RecSKUQty");
	protected By shortageSkusTransferSummaryPage = By.id("com.si:id/lblST_TransferSummary_Shortage");
	protected By scannedSkusTransferSummaryPage = By.id("com.si:id/lblST_TransferSummary_offlineSKUs");
	protected By continueScanningTransferSummaryPage = By.id("com.si:id/btnST_TransferSummary_ContinueScan");
	protected By transferHomeTransferSummaryPage = By.id("com.si:id/btnST_TransferSummary_TransferHome");
	protected By successmessageTransferSummaryPage = By.id("android:id/message");
	protected By backButtonInTransferHomePage=By.id("com.si:id/btnST_TransferList_Back");
	protected By pageTitleId=By.id("com.si:id/txtToolbarTitle");
	

	protected By skuLabel = By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']");
	protected By skuDescLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='SKU Description']");
	protected By skuQtyLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='SKU QTY']");
	protected By receivedSkuQtyLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='Received SKU QTY']");
	protected By specialHandlingLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='Special Handling']");
	
	protected By storeLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='STORE']");
	protected By pendingskuQtyLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='PNDG SKU QTY']");
	protected By etaLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='ETA']");

	// used for SRA 149 by ruthra

	HomePage homeScreen = new HomePage();
	GlobalSearchPage globalSearch = new GlobalSearchPage();
	SendAndReceiveTransferPage sendReceiveTransfer = new SendAndReceiveTransferPage();
	ValidateFromMongoDB mongoDB= new ValidateFromMongoDB();

	@Step("Validates SkuDetails in ReceiveTransferDetailPage ")
	public void validationInReceiveTransferDetailforMultipeSku(String transferNumberCreated,SoftAssert softassert,String storeNumber) throws ParseException {
		
		boolean isTransferDisplayed = searchForReceiveTransfer(transferNumberCreated);
		Assert.assertTrue(isTransferDisplayed);

		clickOnTransferNumber();
		// validating Transfer Number in TransferDetailPage
		String transferNumberTransferDetailPage = getTransferNumberOnTransferDetailPage().substring(10);
		String transferNumberSendStoreSubstring = transferNumberCreated
				.substring(transferNumberCreated.lastIndexOf(transferNumberTransferDetailPage));
		softassert.assertEquals(transferNumberSendStoreSubstring, transferNumberTransferDetailPage);

		// validating pending QTY Label in TransferDetailPage
		String totalPendingSkuQtyLabel = getTotalPendingSkuQtyOnTransferDetailPage().substring(0,8);
		softassert.assertEquals(totalPendingSkuQtyLabel, "PNDG QTY");
		logger.info("TotalPending Sku Quantity Label " + totalPendingSkuQtyLabel);
		
      // validating pending Sku QTY
		String totalPendingSkuQtyNumber = getTotalPendingSkuQtyOnTransferDetailPage().substring(9);

		List<MobileElement> skuQtyListOnTransferDetailPage = getSkuQtyListOnTransferDetailPage();
		List<MobileElement> skuReceivedQtyListOnTransferDetailPage =getSkuReceivedQtyListOnTransferDetailPage();
		
		int specificSkuPendingQtySum = 0;
		int specificSkuReceivedQtySum = 0;
		for (int j = 0; j < skuQtyListOnTransferDetailPage.size(); j++)
		{
			String specificSkuPendingQty = skuQtyListOnTransferDetailPage.get(j).getText().substring(1);
			int i = Integer.parseInt(specificSkuPendingQty);
			specificSkuPendingQtySum = specificSkuPendingQtySum + i;
			
			String specificSkuReceivedQty = skuReceivedQtyListOnTransferDetailPage.get(j).getText();
			int k = Integer.parseInt(specificSkuReceivedQty);
			specificSkuReceivedQtySum = specificSkuReceivedQtySum + k;
		}
		int totalSpecificSkuPendingQty=specificSkuPendingQtySum-specificSkuReceivedQtySum;
		softassert.assertEquals(String.valueOf(totalSpecificSkuPendingQty), totalPendingSkuQtyNumber);
		
		// Validation in DB
		mongoDB.validateReceiveTransferInDetailPage(transferNumberCreated, totalPendingSkuQtyNumber, softassert,storeNumber);

		// Validating GobackButton Navigate to TransferHome page
		clickGoBackButtonOnSkuDetailPage();
		String receiveStoreTransferHeading = getTextOnReceiveTransferHomePage();
		softassert.assertEquals(receiveStoreTransferHeading, "Receive Store Transfers");
		logger.info("Heading In ReceiveTransfer HomePage " + receiveStoreTransferHeading);
		
	}

	// used for SRA149 by ruthra
	public void validationInReceiveTransferDetailforSingleSku(String transferNumberCreated,String storeNumber) throws ParseException {
		SoftAssert softassert = new SoftAssert();
		
		boolean isTransferDisplayed = searchForReceiveTransfer(transferNumberCreated);
		Assert.assertTrue(isTransferDisplayed);

		clickOnTransferNumber();
		// validating Transfer Number and Label in TransferDetailPage
		String transferNumLabel = getTransferNumberOnTransferDetailPage().substring(0, 5);
		softassert.assertEquals(transferNumLabel, "Trans");

		String transferNumberTransferDetailPage = getTransferNumberOnTransferDetailPage().substring(7);
		String transferNumberSendStoreSubstring = transferNumberCreated
				.substring(transferNumberCreated.lastIndexOf(transferNumberTransferDetailPage));
		logger.info("Transfer Number in Transfer Detail Page " + transferNumberTransferDetailPage);
		softassert.assertEquals(transferNumberSendStoreSubstring, transferNumberTransferDetailPage);

		// validating pending QTY Label in TransferDetailPage
		String totalPendingSkuQtyLabel = getTotalPendingSkuQtyOnTransferDetailPage().substring(0,8);
		softassert.assertEquals(totalPendingSkuQtyLabel, "PNDG QTY");

		String totalPendingSkuQtyNumber = getTotalPendingSkuQtyOnTransferDetailPage().substring(9);

//		String specificSkuQtyLabel = getSpecificSkuQtyOnTransferDetailPage().substring(0, 3);
//		softassert.assertEquals(specificSkuQtyLabel, "QTY");

		// Validation in DB
		mongoDB.validateReceiveTransferInDetailPage(transferNumberCreated, totalPendingSkuQtyNumber, softassert, storeNumber);

		// Validating GobackButton Navigate to TransferHome page
		clickGoBackButtonOnSkuDetailPage();
		String receiveStoreTransferHeading = getTextOnReceiveTransferHomePage();
		softassert.assertEquals(receiveStoreTransferHeading, "Receive Store Transfers");
		logger.info("Heading In ReceiveTransfer HomePage " + receiveStoreTransferHeading);
				
		softassert.assertAll();
	}

	public String getSkuNumberOnTransferDetailPage() {
		return getText(skuNoAfterReceiveTransfer);
	}

	public String getSpecificSkuQtyOnTransferDetailPage() {
		return getText(specificSkuQtyDetail);
	}
	
	public String getSpecificSkuReceivedQtyOnTransferDetailPage() {
		return getText(specificSkuReceivedQty);
	}

	public String getTotalPendingSkuQtyOnTransferDetailPage() {
		return getText(totalPendingSkuQty);
	}

	public String getTransferNumberOnTransferDetailPage() {
		return getText(transferNumberTransferDetailPage);
	}

	public void clickOnContinueScanning() {
		elementClick(continueScanning);
	}
	
	public void clickOnReceivedSkuQuantity() {
		elementClick(specificSkuReceivedQty);
	}

	// used for SRA149 by ruthra
	public void clickGoBackButtonOnSkuDetailPage() {
		elementClick(goBackButtonOnSkuDetailPage);
	}

	// used for SRA149 by ruthra
	public String getTextOnReceiveTransferHomePage() {
		return getText(receiveStoreTransferHeading);
	}
	
	public void sendTextToEditReceivedSkuQty(String skuQty) {
		clearTextField(specificSkuReceivedQty);
		setText(specificSkuReceivedQty, skuQty);
		clickSearchButton();

	}

	public boolean searchForReceiveTransfer(String receiveTransferNumber) {

		elementClick(searchBar);
		setText(searchBarTextBox, receiveTransferNumber);
		clickSearchButton();
		fluentWait(recdTransferIdOnReceiveHome);
		return isDisplayed(recdTransferIdOnReceiveHome);

	}

	// used for SRA149 by ruthra
	public void clickOnTransferNumber() {
		elementClick(recdTransferIdOnReceiveHome);
	}

	public void validateReceiveTransferSkuCanBeEdited(String newTransferNo, String skuNumber,String receivedQty) {

		enterTransferNumberInReceiveHome(newTransferNo);
		clickOnReceiveTransferNumber();

		clickOnSkuNoAfterReceiveTransfer();
		String skuNumberToReceive = getSkuNumber();
		softassert.assertEquals(skuNumberToReceive, skuNumber);
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		sendTextToEditSkuQty(receivedQty);
		clickOnSave();
		String actualSkuValue = getRecdSkuValue();

		softassert.assertEquals(actualSkuValue, receivedQty);
		
		softassert.assertAll();

	}
	
	public void validateAbleToEditReceivedQtyUpTo99(String receivedQty) {

		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		elementClick(inputBtnToEnterSkuQty);
		sendTextToEditSkuQty(receivedQty);
		clickOnSave();
		String alertMessage = captureAlertMessage();
		logger.info("Captured alert message------> " + alertMessage);
		assertEquals(alertMessage, "Received SKU QTY exceeds 10. Do you wish to continue?");
		clickOnAlertMessageYes();
		String skuQtyAfterEditing = getRecdSkuValue();
		assertEquals(skuQtyAfterEditing, receivedQty);
		logger.info("Received SKU QTY is---- " + skuQtyAfterEditing);
	}
	
	public void validateNotAbletoEditReceivedQtyAbove99(String receivedQty) {
		logger.info("Received SKU QTY is---- " + receivedQty);
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		// elementClick(inputBtnToEnterSkuQty);
		sendTextToEditSkuQty(receivedQty);
		int sizeOfReceivedQty = getText(inputBtnToEnterSkuQty).length();
		logger.info("Length of received SKU QTY entered------> " + sizeOfReceivedQty);
		assertEquals(2, sizeOfReceivedQty);
		clickOnSave();
		clickOnAlertMessageYes();
	}
	
	public void validateSkuQuantityNotChangedWhenClickOnCancel(String receivedQty) {

		String SkuQtyonSkuDetailPageBeforeEdit = getRecdSkuValue();
		logger.info("Sku qty before editing received qty is------" + SkuQtyonSkuDetailPageBeforeEdit);
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		sendTextToEditSkuQty(receivedQty);
		logger.info("Received SKU QTY is---- " + receivedQty);
		clickOnCancelButton();
		String SkuQtyAfterEditing = getRecdSkuValue();
		logger.info("Sku qty After cancelling received qty edit is------" + SkuQtyAfterEditing);
		Assert.assertEquals(SkuQtyAfterEditing, SkuQtyonSkuDetailPageBeforeEdit);
	}


	public String getRecdSkuValue() {
		return getText(recdSkuValueAfterEdit);
	}

	public void clickOnSave() {
		elementClick(saveButtonOnSkuEditScreen);
	}

	public void sendTextToEditSkuQty(String skuQty) {
		setText(inputBtnToEnterSkuQty, skuQty);
		clickSearchButton();

	}

	public void clickOnSKuEditButton() {
		elementClick(editButtonToEditSku);
	}

	public void clickOnReceiveTransferNumber() {
		elementClick(idToclickOnNewTransferIdInReceivingHome);
	}

	public String sendTextInReceiveTransferHome(String newTransferNo) {
		return newTransferNo.substring(10);
	}

	public void enterTransferNumberInReceiveHome(String newTransferNo) {
		elementClick(searchBar);
		setText(searchBarTextBox, newTransferNo);
		clickSearchButton();
	}

	public void clickSearchButtonForReceiveTransferHomePage() {

		TouchAction touchAction = new TouchAction(driver);
		touchAction.tap(PointOption.point(720, 1280)).perform();

	}

	public void clickSearchButton() {

		TouchAction touchAction = new TouchAction(driver);

		touchAction.tap(PointOption.point(700, 1200)).perform();

	}

	public String getSkuNumber() {
		return getText(skuNumberOnTransferSummery);
	}

	public void clickOnFirstReceiveOnReceiveTransferHome() {

		driver.findElements(recdTransferIdOnReceiveHome).get(0).click();
	}

	public void clickOnSkuNoAfterReceiveTransfer() {
		elementClick(skuNoAfterReceiveTransfer);

	}

	public void clickOnSpecificSKu() {
		driver.findElements(By.id("com.si:id/liST_SKUDetails_SKUNo")).get(1).click();

	}

	public void clickOnBackButton() {
		elementClick(backButtonOnReceiveTransfer);
	}

	public void clickOnTransferSummery() {
		elementClick(transferSummery);
	}

	public void clickOnSubmitTransferSummery() {
		elementClick(submitTransferSummery);
	}

	public void clickOnOkButtonAfterSubmittingSku() {
		elementClick(okButtonOnSubmitReceiveTransfer);
	}

	public String specialHandlingDetail() {
		return getText(specialHandlingInSkuDetails);
	}

	public void submitReceivedTransfer(String newTransferNo) {

		enterTransferNumberInReceiveHome(newTransferNo);
		clickOnFirstReceiveOnReceiveTransferHome();
		clickOnSkuNoAfterReceiveTransfer();

		WebElement skuNo = driver.findElement(By.id("com.si:id/liST_SKUDescDetails_SKUNo"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();

		elementClick(editButtonToEditSku);
		sendTextToEditSkuQty("4");
		clickOnSave();
		clickOnBackButton();
		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		clickOnOkButtonAfterSubmittingSku();
		clickOnContinueScanning();
		clickOnSkuNoAfterReceiveTransfer();

		String specialHandlingLabel = specialHandlingDetail();
		softassert.assertEquals(specialHandlingLabel, "Re-Price");
		softassert.assertAll();

	}

	public void validateTheReceivingTransfer(String newTransferNo) {

		enterTransferNumberInReceiveHome(newTransferNo);
		clickOnFirstReceiveOnReceiveTransferHome();
		clickOnSkuNoAfterReceiveTransfer();

		WebElement skuNo = driver.findElement(By.id("com.si:id/liST_SKUDescDetails_SKUNo"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();

		elementClick(editButtonToEditSku);
		sendTextToEditSkuQty("4");
		clickOnSave();
		clickOnBackButton();
		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		clickOnOkButtonAfterSubmittingSku();
		clickOnContinueScanning();
		clickOnSkuNoAfterReceiveTransfer();

		String receivedSkuQty = getReceivedSkuQty();
		Assert.assertEquals(receivedSkuQty, "1");

	}

	public String getReceivedSkuQty() {
		return getText(recdSkuValueAfterEdit);
	}

	public void clickOnPlusSign() {
		fluentWait(plusSignOnBottom, 20, 2);
		elementClick(plusSignOnBottom);

	}

	public void enterSkuNumber(String skuNumber) {
		// fluentWait(searchButtonOnSkuTransfer);
		elementClick(searchButtonOnSkuTransfer);
		setText(searchBarTextBox, skuNumber);

	}

	public void clickAddButtonOnBottom() {
		fluentWaitForElementToBeEnabled(addButtonOnBottom, 20, 2);
		elementClick(addButtonOnBottom);

	}

	// used for SRA154 by ruthra
	public void validatationInReceiveStoreTransferforValidSkuNumber(String newTransferNo, String sku,String storeNumber) throws Exception {
		SoftAssert softassert= new SoftAssert();
		enterTransferNumberInReceiveHome(newTransferNo);
		clickOnTransferNumber();

		String totalPendingQtyBeforeAddingSku = getTotalPendingSkuQtyOnTransferDetailPage().substring(9);

		clickOnPlusSign();
		enterSkuNumber(sku);
		clickSearchButton();
		clickAddButtonOnBottom();

		// validating SKU Number on TransferDetailPage
		ArrayList<MobileElement> skuNumberListOnTransferDetailPage = getSkuNumberListOnTransferDetailPage();

		int index = -1;
		for (int i = 0; i < skuNumberListOnTransferDetailPage.size(); i++) {
			String skuValuetmp = skuNumberListOnTransferDetailPage.get(i).getText().substring(5);
			if (skuValuetmp.equals(sku)) {
				index = i;
				logger.info("Index of SKU ------ " + index);
			}
		}

		String skuNumberOnTransferDetailPage = skuNumberListOnTransferDetailPage.get(index).getText().substring(5);
		Assert.assertEquals(skuNumberOnTransferDetailPage, sku);

		// validating Received Sku QTY
		
		List<MobileElement> skuReceivedQtyListOnTransferDetailPage =getSkuReceivedQtyListOnTransferDetailPage();
		String skuReceviedQty = skuReceivedQtyListOnTransferDetailPage.get(index).getText();
		softassert.assertEquals(skuReceviedQty, "1");

		// validating pending Sku QTY
		List<MobileElement> skuQtyListOnTransferDetailPage = getSkuQtyListOnTransferDetailPage();
		String skuPendingQty = skuQtyListOnTransferDetailPage.get(index).getText().substring(1);
		softassert.assertEquals(skuPendingQty, "0");
		// validating totalpending Sku QTY
		String totalPendingQtyAfterAddingSku = getTotalPendingSkuQtyOnTransferDetailPage().substring(9);
		softassert.assertEquals(totalPendingQtyBeforeAddingSku, totalPendingQtyAfterAddingSku);

		skuNumberListOnTransferDetailPage.get(index).click();
		String skuNumberToReceive = getSkuNumber();
		Assert.assertEquals(skuNumberToReceive, sku);

		String skuQty = getText(skuQtySkuDetailPage);
		softassert.assertEquals(skuQty, "0");

		String receivedSkuQty = getText(recdSkuValueAfterEdit);
		softassert.assertEquals(receivedSkuQty, "1");

		String specialHandling = getText(specialHandlingInSkuDetails);
		softassert.assertEquals(specialHandling, "None");

		String receivedSkuQtyAfterEdit = validateTransferCanBeEditedAfterAddingSku("4");
		softassert.assertEquals(receivedSkuQtyAfterEdit, "4");
		elementClick(backButtonOnReceiveTransfer);
		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		clickOnOkButtonAfterSubmittingSku();
		clickOnContinueScanning();
		mongoDB.validateReceiveTransferInDetailPage(newTransferNo, totalPendingQtyAfterAddingSku, softassert,storeNumber);
		
		softassert.assertAll();

	}

	public void validateReceivedTransferCannotBeEditedInGlobalSearch(String transferNumber) {

		globalSearch.clickOnGlobalSearch();
		globalSearch.searchForTransferID(transferNumber);
		globalSearch.validateNotAbleToEditReceivedSKU();
		
	}

	public boolean skuEditBoxIsDisabled() {
		return isDisplayedWithoutWait(editButtonToEditSku);
	}

	public void submitTheStoreTransferInReceiving(String transferNo,String receivedQty) {
		enterTransferNumberInReceiveHome(transferNo);
		clickOnFirstReceiveOnReceiveTransferHome();
		clickOnSkuNoAfterReceiveTransfer();

		WebElement skuNo = driver.findElement(By.id("com.si:id/liST_SKUDescDetails_SKUNo"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();

		elementClick(editButtonToEditSku);
		sendTextToEditSkuQty(receivedQty);
		clickOnSave();
		clickOnBackButton();
		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		clickOnOkButtonAfterSubmittingSku();
		clickOnContinueScanning();
		

	}

	// used for SRA149 & 154 by ruthra
	public ArrayList<MobileElement> getSkuNumberListOnTransferDetailPage() {
		return (ArrayList<MobileElement>) getListText(specificskuNumberList);
	}

	// used for SRA149 & 154 by ruthra
	public List<MobileElement> getSkuQtyListOnTransferDetailPage() {
		return getListText(specificSkuQty);
	}
	
	public List<MobileElement> getSkuReceivedQtyListOnTransferDetailPage() {
		return getListText(specificSkuReceivedQty);
	}

	// used for SRA154 by ruthra
	public String validateTransferCanBeEditedAfterAddingSku(String editValue) {
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		sendTextToEditSkuQty(editValue);
		clickOnSave();
		String actualSkuValue = getRecdSkuValue();
		return actualSkuValue;
	}

	// used for SRA154 by ruthra
	public void validatationInReceiveStoreTransferforInvalidSkuNumber(String inValidSkuNumber)
			throws InterruptedException {
		
		SoftAssert softassert= new SoftAssert();
		clickOnPlusSign();
		enterSkuNumber(inValidSkuNumber);
		clickSearchButton();
		elementClick(duplicateInvalidSkuNumberMessage);
		String invalidSkuNumberMessage = getText(duplicateInvalidSkuNumberMessage);
		logger.info("Invalid SKU: " + inValidSkuNumber);
		logger.info("Invalid SKU Message ------- " + invalidSkuNumberMessage);
		softassert.assertEquals("SKU Number not found", invalidSkuNumberMessage);
		softassert.assertFalse(isEnabled(addButtonOnBottom));
		softassert.assertAll();
		elementClick(goBackButtonOnAddSku);
	}

	public void validatationInReceiveStoreTransferforDuplicateSkuNumber(String skuNumber) throws Exception {
		SoftAssert softassert= new SoftAssert();
		clickOnPlusSign();
		enterSkuNumber(skuNumber);
		clickSearchButton();
		elementClick(duplicateInvalidSkuNumberMessage);
		String duplicateSkuNumberMessage = getText(duplicateInvalidSkuNumberMessage);
		logger.info("Duplicate SKU: " + skuNumber);
		logger.info("Duplicate SKU Message ------- " + duplicateSkuNumberMessage);
		softassert.assertEquals("Duplicate SKU number. Please try again", duplicateSkuNumberMessage);
		softassert.assertFalse(isEnabled(addButtonOnBottom));
		softassert.assertAll();
		elementClick(goBackButtonOnAddSku);
	}

	// created By ovi --> Methods to get details from Transfer Home page
	public String getSkuQtyOntransferHome() {
		return getText(totalskuQtyHomePage);
	}

	public String getSourceStoreNumberOnTransferHome() {
		return getText(fromStoreNumberHomePage).substring(3);
	}
	public String getStoreConceptOnTransferHome() {
		return getText(fromStoreNumberHomePage).substring(0, 2);
	}

	public String getETAOnTransferHome() {
		return getText(ETAOnHomePage);
	}

	public String getTransferNoOnTransferHome() {
		return getText(transferNumberTransferHomePage);
	}

	// Created by OVi for SRA-1244/935
	public void validateAlertMessageWhenReceivingSkuQtyGreaterThan10(String transferNumber, String receivedQty) {
		logger.info("Received SKU QTY is---- " + receivedQty);
		searchForReceiveTransfer(transferNumber);
		clickOnTransferNumber();
		clickOnSkuNoAfterReceiveTransfer();
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		sendTextToEditSkuQty(receivedQty);
		clickOnSave();
		String alertmessage = captureAlertMessage();
		logger.info("Alert Message is displayed as---- " + alertmessage);
		Assert.assertEquals(alertmessage, "Received SKU QTY exceeds 10. Do you wish to continue?");
		clickOnAlertMessageYes();
		String SkuQtyAfterEditing = getRecdSkuValue();
		Assert.assertEquals(SkuQtyAfterEditing, receivedQty);
	}

	public void validateNoAlertMessageWhenReceivingSkuQtyLesserThan10(String receivedQty) {
		logger.info("Received SKU QTY is---- " + receivedQty);
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		sendTextToEditSkuQty(receivedQty);
		clickOnSave();
		assertFalse(isDisplayedWithoutWait(alertmessageSkuEditScreen));
		logger.info("Alert Message is not displayed when received qty is less than 10");
	}

	public void validateSkuQtyNotChangedWhenClickingOnNoButtonInAlertMessage(String receivedQty) {
		String SkuQtyonSkuDetailPage = getRecdSkuValue();
		logger.info("Sku qty before editing received qty is------" + SkuQtyonSkuDetailPage);
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		sendTextToEditSkuQty(receivedQty);
		logger.info("Received SKU QTY is---- " + receivedQty);
		clickOnSave();
		String alertmessage = captureAlertMessage();
		Assert.assertEquals(alertmessage, "Received SKU QTY exceeds 10. Do you wish to continue?");
		clickOnAlertMessageNo();
		clickOnCancelButton();
		String SkuQtyAfterEditing = getRecdSkuValue();
		logger.info("Sku qty After cancelling received qty edit is------" + SkuQtyAfterEditing);
		Assert.assertEquals(SkuQtyAfterEditing, SkuQtyonSkuDetailPage);
	}

	public String captureAlertMessage() {
		return getText(alertmessageSkuEditScreen);

	}

	public void clickOnAlertMessageYes() {
		elementClick(alertPopupYesSkuEditScreen);
	}

	public void clickOnAlertMessageNo() {
		elementClick(alertPopupNoSkuEditScreen);
	}

	public void clickOnCancelButton() {
		elementClick(cancelButtonOnSkuEditScreen);
	}

	@Step("Verify transfer number is not displayed")
	public void verifyTransferNumberIsNotDisplayed() {
		assertFalse(isDisplayedWithoutWait(recdTransferIdOnReceiveHome));
		logger.info("Given transfer number is not searchable in summary table as expecetd");
	}

	public void searchForReceiveTransferFromDB(String sendStoreTtransferNumber) {

		elementClick(searchBar);
		clearTextField(searchBarTextBox);
		setText(searchBarTextBox, sendStoreTtransferNumber);
		clickSearchButton();
	}

	public void validatingSkuDetailInReceiveTransfer(String transferNumberCreated, String skuNumberCreated,
			String skuQty,String storeNumber) throws Exception {
		SoftAssert softassert = new SoftAssert();
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		searchForReceiveTransfer(transferNumberCreated);
		clickOnTransferNumber();
		ArrayList<MobileElement> skuNumberListOnTransferDetailPage = getSkuNumberListOnTransferDetailPage();

		int index = -1;
		for (int i = 0; i < skuNumberListOnTransferDetailPage.size(); i++) {
			String skuValuetmp = skuNumberListOnTransferDetailPage.get(i).getText().substring(5);
			if (skuValuetmp.equals(skuNumberCreated)) {
				index = i;
				logger.info("Index of SKU ------ " + index);
			}
		}
		skuNumberListOnTransferDetailPage.get(index).click();
		
		String TransferNumber = getTransferNumberOnSkuDetailPage().substring(10);
		softassert.assertEquals(TransferNumber, transferNumberCreated);
		
		logger.info("To validate the sku labels displayed in the sku detail page");
		validateSkuLabel(softassert);

		/*String skuNumberToReceive = getSkuNumber();
		softassert.assertEquals(skuNumberToReceive, skuNumberCreated);

		String skuShippedQty = getText(skuQtySkuDetailPage);
		logger.info("skuShippedQty is " + skuShippedQty);
		softassert.assertEquals(skuShippedQty, skuQty);

		String receivedSkuQty = getText(recdSkuValueAfterEdit);
		softassert.assertEquals(receivedSkuQty, "0");

		String specialHandling = getText(specialHandlingInSkuDetails);
		logger.info("specialHandling is " + specialHandling);
		softassert.assertEquals(specialHandling, "None");*/

		// call DB validation
		validateFromMongoDB.ValidationForSkuDetailInReceiveTransfer(transferNumberCreated, skuNumberCreated,softassert,storeNumber);
		softassert.assertAll();

	}

	private String getTransferNumberOnSkuDetailPage() {
		return getText(transferNumberInSkuDetailPage);
	}

	private void validateSkuLabel(SoftAssert softassert2) {
		boolean isTransferLabelDisplayed = isDisplayed(transferNumberInSkuDetailPage);
		softassert.assertTrue(isTransferLabelDisplayed);
		
		boolean isSkuLabelDisplayed = isDisplayed(skuLabel);
		softassert.assertTrue(isSkuLabelDisplayed);
		
		boolean isSkuDescLabelDisplayed = isDisplayed(skuDescLabel);
		softassert.assertTrue(isSkuDescLabelDisplayed);
		
		boolean isSkuQtyLabelDisplayed = isDisplayed(skuQtyLabel);
		softassert.assertTrue(isSkuQtyLabelDisplayed);
		
		boolean isReceivedSkuQtyLabelDisplayed = isDisplayed(receivedSkuQtyLabel);
		softassert.assertTrue(isReceivedSkuQtyLabelDisplayed);
		
		boolean isSpecialHandlingLabelDisplayed = isDisplayed(specialHandlingLabel);
		softassert.assertTrue(isSpecialHandlingLabelDisplayed);
		logger.info("All the sku labels are displayed in the sku detail page");
	}

	public String getSkuShippedQtySkuDetailPage() {
		return getText(skuQtySkuDetailPage);
	}

	public String getSkuReceivedQtySkuDetailPage() {
		return getText(recdSkuValueAfterEdit);
	}

	public String getSpecialHandlingSkuDetailPage() {
		return getText(specialHandlingInSkuDetails);
	}

	public String getSkuDescSkuDetailPage() {
		return getText(skuDescriptionSkuDetailPage);
	}

	public void clickGoBackOnSkuDetailPage() {
		elementClick(backButtonOnSkuDescription);
	}

	public void validatePartiallyReceivedTransfer(String transferNumberCreated, String skuNumberCreated,
			String shippedQty, String skuQtyReceived) {
		searchForReceiveTransfer(transferNumberCreated);
		clickOnTransferNumber();
		clickOnSkuNoAfterReceiveTransfer();
		/*
		 * editSkuQty(skuQtyReceived); clickOnSkuNoAfterReceiveTransfer();
		 */

		String skuNumberToReceive = getSkuNumber();
		softassert.assertEquals(skuNumberToReceive, skuNumberCreated);

		String skuShippedQty = getText(skuQtySkuDetailPage);
		logger.info("skuShippedQty is " + skuShippedQty);
		softassert.assertEquals(skuShippedQty, shippedQty);

		String receivedSkuQty = getText(recdSkuValueAfterEdit);
		logger.info("SKU Received quantity is " + receivedSkuQty);
		softassert.assertEquals(receivedSkuQty, skuQtyReceived);

		String specialHandling = getText(specialHandlingInSkuDetails);
		logger.info("specialHandling is " + specialHandling);
		softassert.assertEquals(specialHandling, "None");
		softassert.assertAll();

	}

	public void validateReceiveTransferGreaterThanShippedQty(String transferNumberCreated, String skuNumberCreated,
			String shippedQty, String skuQtyReceived) {
		searchForReceiveTransfer(transferNumberCreated);
		clickOnTransferNumber();
		clickOnSkuNoAfterReceiveTransfer();
		editSkuQty(skuQtyReceived);
		clickOnSkuNoAfterReceiveTransfer();

		String skuNumberToReceive = getSkuNumber();
		softassert.assertEquals(skuNumberToReceive, skuNumberCreated);

		String skuShippedQty = getText(skuQtySkuDetailPage);
		logger.info("skuShippedQty is " + skuShippedQty);
		softassert.assertEquals(skuShippedQty, shippedQty);

		String receivedSkuQty = getText(recdSkuValueAfterEdit);
		logger.info("SKU Received quantity is " + receivedSkuQty);
		softassert.assertEquals(receivedSkuQty, skuQtyReceived);

		String specialHandling = getText(specialHandlingInSkuDetails);
		logger.info("specialHandling is " + specialHandling);
		softassert.assertEquals(specialHandling, "None");
		softassert.assertAll();

	}

	public void validateCompletelyReceivedTransfer(String transferNumberCreated, String skuNumberCreated,
			String shippedQty, String skuQtyReceived) {
        SoftAssert softassert = new SoftAssert();
		searchForReceiveTransfer(transferNumberCreated);
		clickOnTransferNumber();
		ArrayList<MobileElement> skuNumberListOnTransferDetailPage = getSkuNumberListOnTransferDetailPage();

		int index = -1;
		for (int i = 0; i < skuNumberListOnTransferDetailPage.size(); i++) {
			String skuValuetmp = skuNumberListOnTransferDetailPage.get(i).getText().substring(5);
			if (skuValuetmp.equals(skuNumberCreated)) {
				index = i;
				logger.info("Index of SKU ------ " + index);
			}
		}
		skuNumberListOnTransferDetailPage.get(index).click();

		String skuNumberToReceive = getSkuNumber();
		softassert.assertEquals(skuNumberToReceive, skuNumberCreated);

		String skuShippedQty = getText(skuQtySkuDetailPage);
		logger.info("skuShippedQty is " + skuShippedQty);
		softassert.assertEquals(skuShippedQty, shippedQty);

		String receivedSkuQty = getText(recdSkuValueAfterEdit);
		logger.info("SKU Received quantity is " + receivedSkuQty);
		softassert.assertEquals(receivedSkuQty, skuQtyReceived);

		String specialHandling = getText(specialHandlingInSkuDetails);
		logger.info("specialHandling is " + specialHandling);
		softassert.assertEquals(specialHandling, "None");
		softassert.assertAll();

	}

	public void editSkuQty(String skuQtyReceived) {
		WebElement skuNo = driver.findElement(By.id("com.si:id/liST_SKUDescDetails_SKUNo"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		elementClick(editButtonToEditSku);
		sendTextToEditSkuQty(skuQtyReceived);
		clickOnSave();
		clickOnBackButton();
		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		clickOnOkButtonAfterSubmittingSku();
		clickOnContinueScanning();
	}

	public void clickOnFirstSkuNumberInReceiving() {
		driver.findElements(By.id("com.si:id/liST_SKUDetails_SKUNo")).get(0).click();

	}

	public void partiallySubmittingTheTransfer(String transferNumber, String skuQtyReceived) throws InterruptedException {
		enterTransferNumberInReceiveHome(transferNumber);
		clickOnReceiveTransferNumber();
		clickOnFirstSkuNumberInReceiving();
		WebElement skuNo = driver.findElement(By.id("com.si:id/liST_SKUDescDetails_SKUNo"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		elementClick(editButtonToEditSku);
		sendTextToEditSkuQty(skuQtyReceived);
		clickOnSave();
		clickOnBackButton();
		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		clickOnOkButtonAfterSubmittingSku();
		
		
		globalSearch.clickOnGlobalSearch();
		globalSearch.searchForTransferID(transferNumber);
		globalSearch.validateSkuCannotBeEdited();

	}

	public void clickOnGoBackInGlobalSearch() {
		elementClick(goBackButtonOnGlobalSearch);
	}

	public void validatecompletelyReceivingSkuInGlobalSearch(String transferNumber, String skuQtyRecd,String storeNumber)
			throws Exception {
		enterTransferNumberInReceiveHome(transferNumber);
		clickOnFirstReceiveOnReceiveTransferHome();

		List<MobileElement> skus = driver.findElements(By.id("com.si:id/liST_SKUDetails_SKUNo"));

		skus.get(0).click();
		WebElement skuNo = driver.findElement(By.id("com.si:id/liST_SKUDescDetails_SKUNo"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();

		elementClick(editButtonToEditSku);
		sendTextToEditSkuQty(skuQtyRecd);
		clickOnSave();

		clickOnBackButton();

		skus = driver.findElements(By.id("com.si:id/liST_SKUDetails_SKUNo"));

		skus.get(1).click();
		skuNo = driver.findElement(By.id("com.si:id/liST_SKUDescDetails_SKUNo"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();

		elementClick(editButtonToEditSku);
		sendTextToEditSkuQty("99");

		clickOnSave();
		boolean isDisplayedPopUp = IsDisplayedRecdExceedsPopUp();
		softassert.assertTrue(isDisplayedPopUp);
		softassert.assertAll();

		clickOnYesReceivedQtyExceeds();

		clickOnBackButton();

		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		clickOnOkButtonAfterSubmittingSku();
		globalSearch.clickOnGlobalSearch();
		globalSearch.searchForTransferID(transferNumber);
		globalSearch.validateRecdSkuNotEdited();
		globalSearch.validateReceivedTransferDateInDB(transferNumber, storeNumber);

	}

	private boolean IsDisplayedRecdExceedsPopUp() {
		return isDisplayed(recdExceedsPopUp);

	}

	private void clickOnYesReceivedQtyExceeds() {
		elementClick(yesButtonOnRecdExceeds);

	}

	public void validateCountOfPendingQuantityAfterScanning(String transferNumberCreated, String skuQtyReceived,String storeNumber) throws ParseException {
		SoftAssert softassert=new SoftAssert();
		searchForReceiveTransfer(transferNumberCreated);
		clickOnTransferNumber();
		int totalPendingQtyBeforeScan = Integer.parseInt(getTotalPendingSkuQtyOnTransferDetailPage().substring(9));
		int receviedQtyBeforeScan = Integer.parseInt(getSpecificSkuReceivedQtyOnTransferDetailPage());
		logger.info("Pending QTY Before Scanning is " + totalPendingQtyBeforeScan);
		logger.info("Received QTY Before Scanning is " + receviedQtyBeforeScan);
		clickOnSkuNoAfterReceiveTransfer();
		String skuNumber=getText(skuNumberOnTransferSummery);
		WebElement skuNo = driver.findElement(By.id("com.si:id/liST_SKUDescDetails_SKUNo"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		elementClick(editButtonToEditSku);
		sendTextToEditSkuQty(skuQtyReceived);
		clickOnSave();
		clickOnBackButton();

		String totalPendingQtyAfterScan = getTotalPendingSkuQtyOnTransferDetailPage().substring(9);
		softassert.assertEquals(totalPendingQtyAfterScan, String.valueOf(totalPendingQtyBeforeScan - 1));

		String receviedQtyAfterScan = getSpecificSkuReceivedQtyOnTransferDetailPage();
		softassert.assertEquals(receviedQtyAfterScan, String.valueOf(receviedQtyBeforeScan + 1));

		logger.info("Pending QTY After Scanning is " + totalPendingQtyAfterScan);
		logger.info("Received QTY After Scanning is " + receviedQtyAfterScan);

		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		clickOnOkButtonAfterSubmittingSku();
		clickOnContinueScanning();
		
		String skuScannedTime =BaseUtil.getTodayDate("MM/dd/yyyy HH:mm");
		logger.info("Current ScannedTime is "+skuScannedTime);
		mongoDB.ValidateReceivedQTYAndScannedTimeInTransferInDB(transferNumberCreated, skuNumber,skuScannedTime,skuQtyReceived, softassert, storeNumber);
		
		softassert.assertAll();

	}

	public void editCountOfPendingQuantitywithoutsubmit(String transferNumberCreated, String skuQtyReceived) {

		searchForReceiveTransfer(transferNumberCreated);
		clickOnTransferNumber();
		clickOnSkuNoAfterReceiveTransfer();
		WebElement skuNo = driver.findElement(By.id("com.si:id/liST_SKUDescDetails_SKUNo"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		elementClick(editButtonToEditSku);
		sendTextToEditSkuQty(skuQtyReceived);
		clickOnSave();
		clickOnBackButton();
	}

	public void validateCountOfPendingQuantityAfterLogout(String transferNumberCreated,
			String totalPendingQtyBeforeLogout, String receviedQtyBeforeLogout) {
		SoftAssert softassert=new SoftAssert();

		searchForReceiveTransfer(transferNumberCreated);
		clickOnTransferNumber();
		

		String totalPendingQtyAfterLogout = getTotalPendingSkuQtyOnTransferDetailPage().substring(9);
		String receviedQtyAfterLogout = getSpecificSkuReceivedQtyOnTransferDetailPage();
		logger.info("Pending QTY After Logout is " + totalPendingQtyAfterLogout);
		logger.info("Received QTY After Logout is " + receviedQtyAfterLogout);

		softassert.assertEquals(totalPendingQtyBeforeLogout, totalPendingQtyAfterLogout);
		softassert.assertEquals(receviedQtyBeforeLogout, receviedQtyAfterLogout);

		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		clickOnOkButtonAfterSubmittingSku();
		clickOnContinueScanning();
		softassert.assertAll();
	}

//Created By ovi for SRA-1248/155
	public String getTransferNumberOnTransferSummaryPage() {
		return getText(transferNumberTransferSummaryPage);
	}

	public String getExpectedSkusOnTransferSummaryPage() {
		return getText(expectedSkusTransferSummaryPage);
	}

	public String getReceivedSkusOnTransferSummaryPage() {
		return getText(receivedSkusTransferSummaryPage);
	}

	public String getShortageOnTransferSummaryPage() {
		return getText(shortageSkusTransferSummaryPage);
	}

	public String getScannedSkusToBeSubmittedOnTransferSummaryPage() {
		return getText(scannedSkusTransferSummaryPage);
	}

	// Method to validate transfer summary page before scanning skus
	public void validateTransferSummaryBeforeScanningSkus(String transferNumberCreated, String totalSkuQtySent,String storeNumber)
			throws ParseException {
		logger.info("To Validate the Transfer summary page Before scanning Skus");

		boolean isTransferDisplayed = searchForReceiveTransfer(transferNumberCreated);
		softassert.assertTrue(isTransferDisplayed);
		clickOnTransferNumber();
		clickOnTransferSummery();
		String TransferNumber = getTransferNumberOnTransferSummaryPage().substring(10);
		softassert.assertEquals(TransferNumber, transferNumberCreated);
		logger.info("Fetched Transfer Number From UI is-----" + TransferNumber);

		// Validating buttons in transfer summary page
		boolean submitButtonNotfound = isDisplayedWithoutWait(submitTransferSummery);
		softassert.assertFalse(submitButtonNotfound);
		boolean isContinueScanButtonDisplayed = continueScanButtonDisplayed();
		softassert.assertTrue(isContinueScanButtonDisplayed);
		boolean isTransferHomeButtonDisplayed = goToTransferHomeButtonDisplayed();
		softassert.assertTrue(isTransferHomeButtonDisplayed);

		// Validating Expected, received, scanned and shortage skus in transfer summary
		// page
		int shortageSkuQty = new ValidateFromMongoDB().getPendingSkuQuantity(transferNumberCreated,storeNumber);

		String expectedSkuBeforeSubmitting = getExpectedSkusOnTransferSummaryPage();
		softassert.assertEquals(expectedSkuBeforeSubmitting, totalSkuQtySent);

		String receivedSkuBeforeSubmitting = getReceivedSkusOnTransferSummaryPage();
		softassert.assertEquals(receivedSkuBeforeSubmitting, "0");

		String shortageBeforeSubmitting = getShortageOnTransferSummaryPage();
		softassert.assertEquals(shortageBeforeSubmitting, String.valueOf(shortageSkuQty));

		String scannedSkuBeforeSubmitting = getScannedSkusToBeSubmittedOnTransferSummaryPage();
		softassert.assertEquals(scannedSkuBeforeSubmitting, "0");
		softassert.assertAll();
	}

	public boolean continueScanButtonDisplayed() {
		return isDisplayed(continueScanningTransferSummaryPage);
	}

	public boolean goToTransferHomeButtonDisplayed() {
		return isDisplayed(transferHomeTransferSummaryPage);
	}

	public boolean submitButtonDisplayed() {
		return isDisplayed(submitTransferSummery);
	}

	// Method to validate transfer summary page after scanning skus
	public void validateTransferSummaryAfterScanningSkus(String transferNumberCreated, String totalSkuQtySent,
			String receivedQty,String storeNumber) throws ParseException {

		logger.info("To Validate the Transfer summary page after scanning Skus");
		boolean isTransferDisplayed = searchForReceiveTransfer(transferNumberCreated);
		softassert.assertTrue(isTransferDisplayed);
		clickOnTransferNumber();
		clickOnSkuNoAfterReceiveTransfer();
		WebElement skuNo = driver.findElement(By.id("com.si:id/liST_SKUDescDetails_SKUNo"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();

		elementClick(editButtonToEditSku);
		sendTextToEditSkuQty(receivedQty);
		logger.info("Received qty edited is " + receivedQty);
		clickOnSave();
		clickOnBackButton();
		clickOnTransferSummery();

		String TransferNumber = getTransferNumberOnTransferSummaryPage().substring(10);
		softassert.assertEquals(TransferNumber, transferNumberCreated);
		logger.info("Fetched Transfer Number From UI is-----" + TransferNumber);

		// Validating buttons in transfer summary page
		boolean isSubmitButtonDisplayed = submitButtonDisplayed();
		softassert.assertTrue(isSubmitButtonDisplayed);
		boolean isContinueScanButtonDisplayed = continueScanButtonDisplayed();
		softassert.assertTrue(isContinueScanButtonDisplayed);
		boolean isTransferHomeButtonDisplayed = goToTransferHomeButtonDisplayed();
		softassert.assertTrue(isTransferHomeButtonDisplayed);

		// Validating Expected, received, scanned and shortage skus in transfer summary
		// page
		int shortageSkuQty = new ValidateFromMongoDB().getPendingSkuQuantity(transferNumberCreated,storeNumber);
		String expectedSkuBeforeSubmitting = getExpectedSkusOnTransferSummaryPage();
		softassert.assertEquals(expectedSkuBeforeSubmitting, totalSkuQtySent);

		String receivedSkuBeforeSubmitting = getReceivedSkusOnTransferSummaryPage();
		softassert.assertEquals(receivedSkuBeforeSubmitting, "0");

		String shortageBeforeSubmitting = getShortageOnTransferSummaryPage();
		softassert.assertEquals(shortageBeforeSubmitting, String.valueOf(shortageSkuQty));

		String scannedSkuBeforeSubmitting = getScannedSkusToBeSubmittedOnTransferSummaryPage();
		softassert.assertEquals(scannedSkuBeforeSubmitting, "1");
		softassert.assertAll();
	}

	public String captureSubmittedMessage() {
		return getText(successmessageTransferSummaryPage);

	}

	public void validateTransferSummaryAfterSubmittingSkus(String transferNumberCreated, String totalSkuQtySent,
			String receivedQty,String storeNumber) throws ParseException {

		logger.info("To Validate the Transfer summary page after submitting Skus");
		boolean isTransferDisplayed = searchForReceiveTransfer(transferNumberCreated);
		softassert.assertTrue(isTransferDisplayed);
		clickOnTransferNumber();
		clickOnSkuNoAfterReceiveTransfer();
		String skuNumber=getText(skuNumberOnTransferSummery);
		
		WebElement skuNo = driver.findElement(By.id("com.si:id/liST_SKUDescDetails_SKUNo"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();

		elementClick(editButtonToEditSku);

		// Completely receive sku qty.....
		sendTextToEditSkuQty(receivedQty);
		logger.info("Received qty edited is " + receivedQty);
		clickOnSave();
		clickOnBackButton();
		clickOnTransferSummery();

		String TransferNumber = getTransferNumberOnTransferSummaryPage().substring(10);
		softassert.assertEquals(TransferNumber, transferNumberCreated);

		// Validating buttons in transfer summary page
		boolean isSubmitButtonDisplayed = submitButtonDisplayed();
		softassert.assertTrue(isSubmitButtonDisplayed);
		boolean isContinueScanButtonDisplayed = continueScanButtonDisplayed();
		softassert.assertTrue(isContinueScanButtonDisplayed);
		boolean isTransferHomeButtonDisplayed = goToTransferHomeButtonDisplayed();
		softassert.assertTrue(isTransferHomeButtonDisplayed);

		// Validating Success message on Submitting the skus scanned
		clickOnSubmitTransferSummery();
		
		String skuScannedTime =BaseUtil.getTodayDate("MM/dd/yyyy HH:mm");
		logger.info("Current ScannedTime is "+skuScannedTime);
		
		String SuccessMessage = captureSubmittedMessage();
		logger.info(SuccessMessage);
		softassert.assertEquals(SuccessMessage, "Scanned SKUs Submitted Successfully");
		clickOnOkButtonAfterSubmittingSku();

		// Validating Expected, received, scanned and shortage skus in transfer summary
		// page
		int shortageSkuQty = new ValidateFromMongoDB().getPendingSkuQuantity(transferNumberCreated,storeNumber);

		String expectedSkuAfterSubmitting = getExpectedSkusOnTransferSummaryPage();
		softassert.assertEquals(expectedSkuAfterSubmitting, totalSkuQtySent);

		String receivedSkuAfterSubmitting = getReceivedSkusOnTransferSummaryPage();
		softassert.assertEquals(receivedSkuAfterSubmitting, receivedQty);

		String shortageAfterSubmitting = getShortageOnTransferSummaryPage();
		softassert.assertEquals(shortageAfterSubmitting, String.valueOf(shortageSkuQty));

		String scannedSkuAfterSubmitting = getScannedSkusToBeSubmittedOnTransferSummaryPage();
		softassert.assertEquals(scannedSkuAfterSubmitting, "0");
		
		
		mongoDB.ValidateReceivedQTYAndScannedTimeInTransferInDB(transferNumberCreated, skuNumber,skuScannedTime,receivedQty, softassert,storeNumber);
		
		softassert.assertAll();

	}

	public void validateSpecialHandlingMsgOnSKu(String newTransferNo) {
		SoftAssert assertion=new SoftAssert();
		enterTransferNumberInReceiveHome(newTransferNo);
		clickOnFirstReceiveOnReceiveTransferHome();
		clickOnSpecific0SKu();
		String specialHandlingValue = getTextOfSpecialHandling();
		assertion.assertEquals(specialHandlingValue, "Re-Price");
		assertion.assertAll();

	}

	public void clickOnSpecific0SKu() {
		driver.findElements(By.id("com.si:id/liST_SKUDetails_SKUNo")).get(0).click();
		
		
	}

	public String getTextOfSpecialHandling() {
		return getText(specialHandlingReprice);
	}

	public void validateETAMoreThan365(String newTransferNo) {
		enterTransferNumberInReceiveHome(newTransferNo);
		boolean transferNo = isDisplayedWithoutWait(idToclickOnNewTransferIdInReceivingHome);
		softassert.assertEquals(transferNo, false);
		

	}

	public void validateReceiveTransferDoesNotDisplayTransferOlderThan30Days(String transferNo) {
		enterTransferNumberInReceiveHome(transferNo);

		transferNumberNotDisplayed();
		

	}

	public void transferNumberNotDisplayed() {
		boolean transferNoNotVisible = isDisplayedWithoutWait(idToclickOnNewTransferIdInReceivingHome);
		softassert.assertEquals(transferNoNotVisible, false);
	}

	
	public void validateDateForTransferNumber(String transferNumber ){
		searchForReceiveTransferFromDB(transferNumber);
		verifyTransferNumberIsNotDisplayed();
	}
	// method to off the wifi
	public void wifi(){
		System.out.println(wifiStatus());
		toggleWifi();
		System.out.println("***********");
		System.out.println(wifiStatus());
		
		
	}

	public void validateSpecialHandlingInReceivingTransfer(String transferNumber, String skuNumber) {
		enterTransferNumberInReceiveHome(transferNumber);
		clickOnFirstReceiveOnReceiveTransferHome();
		List<MobileElement> skuNumberListOnReceiveTransferDetailPage = getSkuValueInReceivingTransfer();
		int index = -1;
		for (int i = 0; i < skuNumberListOnReceiveTransferDetailPage.size(); i++) {
			String skuValuetmp = skuNumberListOnReceiveTransferDetailPage.get(i).getText().substring(5);
			if (skuValuetmp.equals(skuNumber)) {
				index = i;
				logger.info("Index of SKU ------ " + index);
			}
		}
		
		skuNumberListOnReceiveTransferDetailPage.get(index).click();
		
		String specialHandlingForTransfer = getSpecialHandlingSkuDetailPage();
		logger.info("specialHandling is " + specialHandlingForTransfer);
		softassert.assertEquals(specialHandlingForTransfer, "Special Order");

		
		
		
	}

	public List<MobileElement> getSkuValueInReceivingTransfer() {
		  return getListText(skuNoAfterReceiveTransfer);
		
		
	}

   public void validateReceiveTransferHomePageHeading(){
		
		String receiveStoreTransferHeading = getTextOnReceiveTransferHomePage();
		assertEquals(receiveStoreTransferHeading, "Receive Store Transfers");
		logger.info("Heading In receiveStoreTransfer Home Page is "+receiveStoreTransferHeading);
	}
	
	public void validateGobackInHomePage()
	{    elementClick(receiveStoreTransferHeading);
		elementClick(backButtonInTransferHomePage);
		
		String headingInTransferPage = getText(pageTitleId);
		assertEquals(headingInTransferPage, "STORE TRANSFER");
		logger.info("Heading In Transfer HomePage is "+headingInTransferPage);
	}

	public void validateStoreConceptForSameBrandInReceiveStoreTransfersScreen(String TranferNumber, String wsStoreConcept) {
		     searchForReceiveTransfer(TranferNumber);
			String capturedStoreConcept=getStoreConceptOnTransferHome();
			Assert.assertEquals(capturedStoreConcept, wsStoreConcept);
			logger.info("Sourcestore Store concept is " + capturedStoreConcept);
			}

	public void validateStoreConceptForCrossBrandInReceiveStoreTransfersScreen(String TranferNumber, String StoreConcept) {
		searchForReceiveTransfer(TranferNumber);
		String capturedStoreConcept=getStoreConceptOnTransferHome();
		Assert.assertEquals(capturedStoreConcept, StoreConcept);
		logger.info("Sourcestore Store concept is " + capturedStoreConcept);
	}

	public void validateLabelsInReceiveStoreTransfersHomePage(SoftAssert softassert) {
		 logger.info("To Validate if all the labels are displayed in the home page");
		 
			
		    boolean isStoreLabelDisplayed = isDisplayed(storeLabel);
			softassert.assertTrue(isStoreLabelDisplayed);
			
			boolean isPendingSkuQtyLabelDisplayed = isDisplayed(pendingskuQtyLabel);
			softassert.assertTrue(isPendingSkuQtyLabelDisplayed);
			
			boolean isETALabelDisplayed = isDisplayed(etaLabel);
			softassert.assertTrue(isETALabelDisplayed);
			
			logger.info("All the labels are displayed in the Home Page");
		
	}
	
      public void scrollInReceiveTransferHomePage(){
		
		MobileElement element=driver.findElementByClassName("android.support.v7.widget.RecyclerView");
		
		 String isScrollable=element.getAttribute("scrollable");
         logger.info("Scrollable flag for ReceiveTransfer HOMEPAGE is :"+isScrollable);
         assertEquals(isScrollable, "true");
         
         List<MobileElement> transferNumberList=driver.findElementsById("com.si:id/listST_TransferList_TransferNo");
         
         boolean isScrolled= scrollDownByElement(transferNumberList);
         assertTrue(isScrolled);
	}
	
	public void scrollInReceiveTransferDetailPage(String transferNumberCreated){
		
		searchForReceiveTransfer(transferNumberCreated);
		clickOnTransferNumber();
		
		MobileElement element=driver.findElementByClassName("android.support.v7.widget.RecyclerView");
		
		String isScrollable=element.getAttribute("scrollable");
        logger.info("Scrollable flag for ReceiveTransfer DetailPage is :"+isScrollable);
        assertEquals(isScrollable, "true");
        
        List<MobileElement>  skuNumberListOnTransferDetailPage = getSkuNumberListOnTransferDetailPage();
        boolean isScrolled= scrollDownByElement(skuNumberListOnTransferDetailPage);
        assertTrue(isScrolled);
        
	}
	
   public void validateSearchExitInReceiveTransferHomePage(String transferNumber) throws InterruptedException{
    	
	      elementClick(searchBar);
		  setText(searchBarTextBox, transferNumber);
			
		   boolean keyboardBefore=driver.isKeyboardShown();
			logger.info("Keyboard Displayed flag before search Exit in ReceiveTransfer :"+keyboardBefore);
			
			Thread.sleep(1000);
			TouchAction touchAction = new TouchAction(driver);
			touchAction.tap(PointOption.point(650, 190)).perform();
			
			boolean keyboardAfter=driver.isKeyboardShown();
			logger.info("Keyboard Displayed flag after search Exit in ReceiveTransfer:"+keyboardAfter);
			assertFalse(keyboardAfter);
		
	    }
   
   
   public void editQuantityOfTransferForCompletelyReceived(String transferNumber, String receivedQty) throws ParseException {
	   searchForReceiveTransfer(transferNumber);
		clickOnTransferNumber();
		clickOnSkuNoAfterReceiveTransfer();
		editSkuQty(receivedQty);
		
	}
	
   public void validateReceivedQuantityEditInTransferDetailPage(String transferNumber,String storeNumber) throws ParseException  {
		SoftAssert softassert= new SoftAssert();
		
		boolean isTransferDisplayed = searchForReceiveTransfer(transferNumber);
		Assert.assertTrue(isTransferDisplayed);

		clickOnTransferNumber();

		int totalPendingQtyBeforeEdit = Integer.parseInt(getTotalPendingSkuQtyOnTransferDetailPage().substring(9));
		int receviedQtyBeforeEdit = Integer.parseInt(getSpecificSkuReceivedQtyOnTransferDetailPage());
		int receivedQuantityToEdit=receviedQtyBeforeEdit+1;
		
		logger.info("Pending QTY Before Edit is " + totalPendingQtyBeforeEdit);
		logger.info("Received QTY Before Edit is " + receviedQtyBeforeEdit);
		
		editSkuReceivedQuantityInDetailPage(String.valueOf(receivedQuantityToEdit));
		
		int totalPendingQtyAfterEdit = Integer.parseInt(getTotalPendingSkuQtyOnTransferDetailPage().substring(9));
		int receviedQtyAfterEdit = Integer.parseInt(getSpecificSkuReceivedQtyOnTransferDetailPage());
		
		logger.info("Pending QTY After Edit is " + totalPendingQtyAfterEdit);
		logger.info("Received QTY After Edit is " + receviedQtyAfterEdit);
		
		
		assertEquals(totalPendingQtyAfterEdit, totalPendingQtyBeforeEdit-1);
		assertEquals(receviedQtyAfterEdit, receivedQuantityToEdit);
		
		clickOnSkuNoAfterReceiveTransfer();
		String skuNumber=getText(skuNumberOnTransferSummery);
		
		int receivedQuantityInSkuDetailPage = Integer.parseInt(getSkuReceivedQtySkuDetailPage());
		logger.info("Received QTY in Sku Detail Page " + receivedQuantityInSkuDetailPage);
		assertEquals(receivedQuantityInSkuDetailPage, receivedQuantityToEdit);
		
		clickGoBackOnSkuDetailPage();
		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		clickOnOkButtonAfterSubmittingSku();
		clickOnContinueScanning();
		
		String skuScannedTime =BaseUtil.getTodayDate("MM/dd/yyyy HH:mm");
		logger.info("Current ScannedTime is "+skuScannedTime);
		mongoDB.ValidateReceivedQTYAndScannedTimeInTransferInDB(transferNumber, skuNumber,skuScannedTime,String.valueOf(receivedQuantityToEdit), softassert, storeNumber);
		softassert.assertAll();
	}
   
   public void editSkuReceivedQuantityInDetailPage(String receivedQuantityToEdit){
	   clickOnReceivedSkuQuantity();
	   sendTextToEditReceivedSkuQty(receivedQuantityToEdit);
   }
   
	public void validateReceivedQuantityEditInTransferDetailPageForNewSkuAdded(String transferNumber,
			String storeNumber, String sku) {

		boolean isTransferDisplayed = searchForReceiveTransfer(transferNumber);
		Assert.assertTrue(isTransferDisplayed);

		clickOnTransferNumber();
		String totalPendingQtyBeforeAddingSku = getTotalPendingSkuQtyOnTransferDetailPage().substring(9);
		clickOnPlusSign();
		enterSkuNumber(sku);
		clickSearchButton();
		clickAddButtonOnBottom();

		//validating totalpending Sku QTY
		String totalPendingQtyAfterAddingSku = getTotalPendingSkuQtyOnTransferDetailPage().substring(9);
		logger.info("Pending QTY After Adding Sku is " + totalPendingQtyAfterAddingSku);
		assertEquals(totalPendingQtyBeforeAddingSku, totalPendingQtyAfterAddingSku);

		// validating SKU Number on TransferDetailPage
		ArrayList<MobileElement> skuNumberListOnTransferDetailPage = getSkuNumberListOnTransferDetailPage();
		int index = -1;
		for (int i = 0; i < skuNumberListOnTransferDetailPage.size(); i++) {
			String skuValuetmp = skuNumberListOnTransferDetailPage.get(i).getText().substring(5);
			if (skuValuetmp.equals(sku)) {
				index = i;
				logger.info("Index of SKU ------ " + index);
			}
		}

		String skuNumberOnTransferDetailPage = skuNumberListOnTransferDetailPage.get(index).getText().substring(5);
		assertEquals(skuNumberOnTransferDetailPage, sku);

		// validating Received Sku QTY

		List<MobileElement> skuReceivedQtyListOnTransferDetailPage = getSkuReceivedQtyListOnTransferDetailPage();
		String skuReceviedQty = skuReceivedQtyListOnTransferDetailPage.get(index).getText();
		assertEquals(skuReceviedQty, "1");

		// validating pending Sku QTY
		List<MobileElement> skuQtyListOnTransferDetailPage = getSkuQtyListOnTransferDetailPage();
		String skuPendingQty = skuQtyListOnTransferDetailPage.get(index).getText().substring(1);
		assertEquals(skuPendingQty, "0");

		MobileElement element = skuReceivedQtyListOnTransferDetailPage.get(index);
		editSkuReceivedQuantityInDetailPageForNewSkuAdded(element, "2");

		int totalPendingQtyAfterEdit = Integer.parseInt(getTotalPendingSkuQtyOnTransferDetailPage().substring(9));
		logger.info("Pending QTY After Edit is " + totalPendingQtyAfterEdit);
		assertEquals(totalPendingQtyBeforeAddingSku, String.valueOf(totalPendingQtyAfterEdit));

		skuReceivedQtyListOnTransferDetailPage = null;
		skuReceivedQtyListOnTransferDetailPage = getSkuReceivedQtyListOnTransferDetailPage();
		String receviedQtyAfterEdit = skuReceivedQtyListOnTransferDetailPage.get(index).getText();
		logger.info("Received QTY After Edit is " + receviedQtyAfterEdit);
		softassert.assertEquals(receviedQtyAfterEdit, "2");

		skuNumberListOnTransferDetailPage.get(index).click();
		String skuNumberToReceive = getSkuNumber();
		Assert.assertEquals(skuNumberToReceive, sku);

		String receivedSkuQty = getText(recdSkuValueAfterEdit);
		softassert.assertEquals(receivedSkuQty, "2");

		String receivedSkuQtyAfterEdit = validateTransferCanBeEditedAfterAddingSku("3");
		softassert.assertEquals(receivedSkuQtyAfterEdit, "3");
		elementClick(backButtonOnReceiveTransfer);

		skuReceivedQtyListOnTransferDetailPage = getSkuReceivedQtyListOnTransferDetailPage();
		String receviedQtyForNewSku = skuReceivedQtyListOnTransferDetailPage.get(index).getText();
		logger.info("Received QTY After Edit in Detail Page " + receviedQtyAfterEdit);
		softassert.assertEquals(receviedQtyForNewSku, "3");

		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		clickOnOkButtonAfterSubmittingSku();
		clickOnContinueScanning();

	}
   
   public void editSkuReceivedQuantityInDetailPageForNewSkuAdded(MobileElement element,String receivedQuantityToEdit){
	   element.click();
	   element.clear();
	   element.sendKeys(receivedQuantityToEdit);
	   clickSearchButton();
   }
   
	
	}

