package com.pdt.Pom;

public @interface index {

}
