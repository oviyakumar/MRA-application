package com.pdt.Pom;

import static com.util.BaseUtil.getTodayDate;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.util.BaseUtil;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.AndroidBasePage;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;

public class GlobalSearchPage extends AndroidBasePage {
	
	final static Logger logger = Logger.getLogger(GlobalSearchPage.class.getName());
	ValidateFromMongoDB mongoDB = new ValidateFromMongoDB();

	protected By saveSpecialHandlingForCartonSku = By.id("com.si:id/btnGSDC_EditSKU_Save");
	protected By visualSetUpSpecialHandling = By
			.xpath("//android.widget.TextView[normalize-space(@text)='Visual Set Up']");
	protected By dropDownSpecialHandlingForCarton = By.id("com.si:id/spinnerGSDC_EditSKU_SplHandling");
	protected By editSpecialHandlingForcarton = By.id("com.si:id/imgDCShip_CartonDetails_Edit");
	protected By skuDescriptionInCartonSearch = By.id("com.si:id/liDCShip_CartonDetails_SKUDesc");
	protected By cartonNoInGlobalSearchDetail = By.id("com.si:id/lblDCShip_CartonDetails_Header");
	protected By dcShipmentSkuInGlobalSearch = By.xpath("//android.widget.TextView[@text='1023998']");

	protected By specialOrderSpecialHandlingForSku = By.id("com.si:id/liGSST_SKUDetails_SplHandling");
	protected By saveSkuInSpecialHandling = By.id("com.si:id/btnGSST_EditSKU_Save");
	protected By specialHandlingSpecialOrderForSku = By
			.xpath("//android.widget.TextView[normalize-space(@text)='Special Order']");
	protected By errorMsgNoSkuFound = By.id("com.si:id/lblGS_Home_ErrorMsg");
	protected By skuNumberOnGlobalSearch = By.id("com.si:id/liGSPO_SKUDetails_SKUNo");
	protected By goBackOnGlobalSearch = By.id("com.si:id/btnGS_Home_Back");
	protected By purchaseOrderInGlobalSearch = By.id("com.si:id/lblGSPO_SKUDetails_PONo");
	protected By transferNoInGlobalSearchResult = By.id("com.si:id/lblGSST_SKUDetails_TransferNo");
	protected By receivedSKUQty = By.id("com.si:id/liDCShip_CartonDetails_RecSKUQty");
	protected By shippedSKUQty = By.id("com.si:id/liDCShip_CartonDetails_ShipSKUQty");
	protected By receivedSkuQtyInTransfer = By.id("com.si:id/liGSST_SKUDetails_RecQty");
	protected By dcShipmentDetailSpecialHandling = By.id("com.si:id/liDCShip_CartonDetails_SplHandling");
	protected By dcShipmentDetailInGlobalSearch = By.id("com.si:id/liDCShip_CartonDetails_SKUNo");
	protected By clickOnCancelInSpecialHandling = By.id("com.si:id/btnGSPO_EditSKU_Cancel");
	protected By saveSpecialHandlingInPO = By.id("com.si:id/btnGSPO_EditSKU_Save");
	protected By backOrderSpecialHandlingForPO = By.xpath("//android.widget.TextView[@text='Backorder']");
	protected By spinnerSpecialHandlingForPO = By.id("com.si:id/spinnerGSPO_EditSKU_SplHandling");
	protected By spinnerSpecialHandlingForTransferSKU = By.id("com.si:id/spinnerGSST_EditSKU_SplHandling");

	protected By editImage = By.id("com.si:id/imgGSPO_SKUDetails_Edit");
	protected By transferNoNotFoundMsgInSendStoreTransfer = By
			.xpath("//android.widget.TextView[normalize-space(@text)='No items available matching this number']");
	protected By skuNumberInGlobalSearch = By.xpath("//android.widget.TextView[@text='5739995']");
	protected By cartonSkuInGlobalSearchDetail = By.id("com.si:id/liDCShip_CartonDetails_SKUNo");
	protected By skuQtyOnTransferDetails = By.id("com.si:id/liGSST_SKUDetails_Qty");
	protected By skuDescOnTransferDetails = By.id("com.si:id/liGSST_SKUDetails_SKUDesc");
	protected By skuDescOnPODetails = By.id("com.si:id/liGSPO_SKUDetails_SKUDesc");
	protected By skuNoOnTransferDetail = By.id("com.si:id/liGSST_SKUDetails_SKUNo");
	protected By goBackButtonOnCartonSearchInGlobalSearch = By.id("com.si:id/btnDCShip_CartonDetails_Back");
	protected By goBackButtonOnSkuDetailsInGlobalSearch = By.id("com.si:id/btnGSST_SKUDetails_Back");
	protected By goBackButtonForPOInGlobalSearch = By.id("com.si:id/btnGSPO_SKUDetails_Back");
	// protected By saveSpecialHandling = By.id("com.si:id/btnGSST_EditSKU_Save");
	protected By saveSpecialHandling = By.xpath("//android.widget.Button[@text='SAVE']");
	protected By editSpecialHandling = By.id("com.si:id/imgGSST_SKUDetails_Edit");
	protected By spinnerSpecialHandling = By.id("com.si:id/spinnerGSST_EditSKU_SplHandling");
	protected By rePriceSpecialHandling = By.xpath("//android.widget.TextView[@text='Re-Price']");
	protected By specialHandlingAfterEdit = By.id("com.si:id/liGSST_SKUDetails_SplHandling");
	protected By globalSearch = By.id("com.si:id/imgGlobalSearch");
	protected By spinnerSearchBar = By.id("com.si:id/spinnerGS_Home");
	protected By scannedTimeOnGlobalSearch = By.id("com.si:id/liGS_Home_Date");
	// protected By cartonNumberSearchBox =
	// By.id("com.si:id/txtGS_Home_CartonSearch");
	protected By searchFromAnyCriteria = By.id("com.si:id/txtGS_Home_CartonSearch");
	protected By searchImage = By.id("com.si:id/imgGS_Home_Search");
	protected By cartonListView = By.xpath("//android.widget.TextView[@text='Carton']");
	protected By transferIDListView = By.xpath("//android.widget.TextView[@text='Transfer']");
	protected By POListView = By.xpath("//android.widget.TextView[@text='PO']");
	protected By skuListView = By.xpath("//android.widget.TextView[@text='SKU']");
	protected By displayedDetailInGlobalSearch = By.id("com.si:id/liGS_Home_Number");

	// protected By cartonListView =By.id("com.si:id/txtGS_Home_CartonSearch");
	protected By cartonNumberDisplayedAfterSearch = By.id("com.si:id/liGS_Home_Number");
	protected By cartonAcceptedImage = By.id("com.si:id/liGS_Home_Date");
	protected By transferNumberDisplayedInGlobalSearch = By.id("com.si:id/liGS_Home_Number");
	protected By etaONGlobalSearch = By.id("com.si:id/liGS_Home_Date");
	protected By editImageToEditSku = By.id("com.si:id/imgGSST_SKUDetails_Edit");
	protected By dcShipmentLabel = By.xpath("//android.widget.TextView[normalize-space(@text)='DC SHIPMENT']");
	protected By storeTransferLabel = By.xpath("//android.widget.TextView[normalize-space(@text)='STORE TRANSFER']");
	protected By purchaseOrderLabel = By.xpath("//android.widget.TextView[normalize-space(@text)='PURCHASE ORDER']");
	// By.xpath("//android.widget.TextView[normalize-space(@text)='Go Back']");
	protected By cartonSkuDamagedQty=By.id("com.si:id/liDCShip_CartonDetails_DamSKUQty");
	protected By POspecialHandling=By.id("com.si:id/liGSPO_SKUDetails_SplHandling");
	protected By skuQuantityOnPOSku=By.id("com.si:id/liGSPO_SKUDetails_SKUQty");
	protected By skuReceivedQtyOnPOSku=By.id("com.si:id/liGSPO_SKUDetails_RecQty");
	protected By noSkusAvailableMessage=By.id("android:id/message");
	protected By noSkusAvailableMessageOkButton=By.id("android:id/button1");
	
	HomePage homePage = new HomePage();
	AuditingPage auditingPage = new AuditingPage();
	AuditingInStoreDamagesScanPage auditingInStoreDamagesScanPage = new AuditingInStoreDamagesScanPage();
	SendAndReceiveTransferPage sendAndReceiveTransferPage = new SendAndReceiveTransferPage();
	ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
	ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();

	public void clickOnGoBackOfGlobalSearch() {
		elementClick(goBackOnGlobalSearch);
	}

	public boolean cartonAcceptedImageDisplayed() {
		return isDisplayed(cartonAcceptedImage);
	}

	public String getCartonNumber() {
		return getText(cartonNumberDisplayedAfterSearch);
	}

	public void clickOnTextBox() {
		elementClick(searchFromAnyCriteria);

	}

	public void clickOnGlobalSearch() {
		elementClick(globalSearch);
	}

	public void setSkuInSpecialHandling(String TransferId,String storeNumber) throws ParseException {
		SoftAssert assertion = new SoftAssert();
		clickOnGlobalSearch();
		searchForTransferID(TransferId);
		//clickOnTransferIDForDetails();
		
		MobileElement skuElement=driver.findElementById("com.si:id/recyclerViewGS_Home_ST").findElementsById("com.si:id/liGS_Home_Number").get(0);
		skuElement.click();
		
		WebElement longPressSpecialHandling = driver.findElement(By.id("com.si:id/liGSST_SKUDetails_SplHandling"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(longPressSpecialHandling))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(longPressSpecialHandling.getRect().getX() - 10,
						longPressSpecialHandling.getRect().getY()))
				.release().perform();
		enterSpecialHandlingValue();
		
		//validate time in db
		String specialHandlingSetTime =BaseUtil.getTodayDate("MM/dd/yyyy HH:mm");
		logger.info("Current SpeciaHandlingSetTime is "+specialHandlingSetTime);
			
		String specialHandlingValue = rePriceSpecialHandlingDisplayed();
		assertion.assertEquals(specialHandlingValue, "Re-Price");
		
		String skuNumber = getSkuNumberonTransfer();
		
		mongoDB.ValidateSpecialHandlingAndTimeInDBForStoreTransfer(TransferId, skuNumber, specialHandlingSetTime, assertion,storeNumber);
		assertion.assertAll();

	}

	public String rePriceSpecialHandlingDisplayed() {
		return getText(specialHandlingAfterEdit);
	}

	public void enterSpecialHandlingValue() {
		elementClick(editSpecialHandling);
		elementClick(spinnerSpecialHandling);
		elementClick(rePriceSpecialHandling);
		elementClick(saveSpecialHandling);
	}

	public void clickOnTransferIDForDetails() {
		elementClick(displayedDetailInGlobalSearch);
	}

	public void searchForTransferID(String newTransferId) {
		elementClick(spinnerSearchBar);
		elementClick(transferIDListView);
		setText(searchFromAnyCriteria, newTransferId);
		elementClick(searchImage);

	}

	public void validateTheUNReceivedTransferScenario(String transferNumber,String storeNumber) throws ParseException {
		clickOnGlobalSearch();
		searchForTransferID(transferNumber);
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		validateFromMongoDB.validateTranferNumberAndETAFromDB(transferNumber, storeNumber);

	}

	public void clickOnSpinnerSearchBar() {
		elementClick(spinnerSearchBar);
	}

	public void clickOnCartonFromSpinnerSearch() {
		elementClick(cartonListView);
		fluentWait(searchFromAnyCriteria, 60, 5);

	}

	public void enterCartonNumber(String cartonNumber) {

		setText(searchFromAnyCriteria, cartonNumber);
		elementClick(searchImage);

	}

	public void searchDCShipmentCartonNumberInGlobalSearch(String cartonNumber, SoftAssert assertion) {
		
		clickOnGlobalSearch();
		clickOnSpinnerSearchBar();
		clickOnCartonFromSpinnerSearch();
		clickOnTextBox();
		enterCartonNumber(cartonNumber);

		String cartonNumberAfterSearch = getCartonNumber();
		assertion.assertEquals(cartonNumberAfterSearch, cartonNumber);

		boolean imageDisplayed = cartonAcceptedImageDisplayed();
		assertion.assertTrue(imageDisplayed);
		assertion.assertAll();

	}
public void searchCartonNumberInGlobalSearch(String cartonNumber, SoftAssert assertion) {
		
		clickOnGlobalSearch();
		clickOnSpinnerSearchBar();
		clickOnCartonFromSpinnerSearch();
		clickOnTextBox();
		enterCartonNumber(cartonNumber);

		String cartonNumberAfterSearch = getCartonNumber();
		assertion.assertEquals(cartonNumberAfterSearch, cartonNumber);

		boolean imageDisplayed = cartonAcceptedImageDisplayed();
		assertion.assertTrue(imageDisplayed);
		assertion.assertAll();

	}

	public void clickOnTransferIDForTransferDetail() {
		elementClick(displayedDetailInGlobalSearch);
	}

	public String getSkuNumberonTransfer() {
		return getText(skuNoOnTransferDetail);
	}

	public String getSkuDescriptionOnTransfer() {
		return getText(skuDescOnTransferDetails);
	}

	public String getSkuQtyOnTransfer() {
		return getText(skuQtyOnTransferDetails);
	}
	
	public String getReceivedSkuQtyOnTransfer() {
		return getText(receivedSkuQtyInTransfer);
	}

	public void validateSkuDetailsInGlobalSearch() {
		SoftAssert assertion = new SoftAssert();
		clickOnTransferIDForTransferDetail();

		String skuNumber = getSkuNumberonTransfer();
		assertion.assertEquals("5739995", skuNumber);

		String skuDesc = getSkuDescriptionOnTransfer();
		assertion.assertEquals("Roccbox Pizza Oven, Gray", skuDesc);

		String skuQty = getSkuQtyOnTransfer();
		assertion.assertEquals("1", skuQty);
		assertion.assertAll();

	}

	public void clickOnDisplayedCartonOnGlobalSearch() {
		elementClick(displayedDetailInGlobalSearch);
	}

	public void clickOnDisplayedSkusOnGlobalSearch() {
		elementClick(displayedDetailInGlobalSearch);
	}

	public boolean skuDetailScreenDisplayed() {
		return isDisplayed(cartonSkuInGlobalSearchDetail);
	}

	public void clickOnGoBackButtonToValidateSearch() {
		elementClick(goBackButtonOnCartonSearchInGlobalSearch);
	}

	public void clickOnGoBackButtonValidateSkuDetailInGlobalSearch() {
		elementClick(goBackButtonOnSkuDetailsInGlobalSearch);
	}

	public String getValueOfCartonInGlobalSearch() {
		return getText(displayedDetailInGlobalSearch);
	}

	public void validateTheGoBackResult(String cartonNumber) {
		SoftAssert assertion = new SoftAssert();
		clickOnDisplayedCartonOnGlobalSearch();
		boolean skuValueDisplayed = skuDetailScreenDisplayed();
		assertion.assertEquals(true, skuValueDisplayed);
		clickOnGoBackButtonToValidateSearch();
		String cartonNoDisplayedInSearch = getValueOfCartonInGlobalSearch();
		assertion.assertEquals(cartonNumber, cartonNoDisplayedInSearch);

	}

	public void clickOnSkuFromSpinnerBar() {
		elementClick(skuListView);

	}

	public void clickOnFirstSkuNumberInSearchResult() {
		driver.findElements(By.id("com.si:id/liGS_Home_Number")).get(0).click();
	}

	public String validateSkuNoDisplayed() {
		return driver.findElements(By.id("com.si:id/liGS_Home_Number")).get(0).getText();
	}

	public boolean isSkuNoDisplayed() {
		return isDisplayed(skuNumberInGlobalSearch);
	}

	public void validateGoBackSearchInGlobalSearch(String skuNumber, SoftAssert assertion) {
		
		clickOnGlobalSearch();
		clickOnSpinnerSearchBar();
		clickOnSkuFromSpinnerBar();
		setText(searchFromAnyCriteria, skuNumber);
		elementClick(searchImage);
		clickOnFirstSkuNumberInSearchResult();

		boolean isSkuNoDisplayed = isSkuNoDisplayed();
		assertion.assertEquals(true, isSkuNoDisplayed);

		clickOnGoBackButtonValidateSkuDetailInGlobalSearch();

		String skuNumberDisplayedOnGlobalSearch = validateSkuNoDisplayed();
		assertion.assertEquals("5739995", skuNumberDisplayedOnGlobalSearch);
		assertion.assertAll();

	}

	public boolean validateTransferIDNotFoundInSendStore(String transferNumber) {
		SoftAssert assertion = new SoftAssert();
		searchForTransferID(transferNumber);
		boolean errorMsgDisplayed = isErrorMsgDisplayed();
		assertion.assertTrue(errorMsgDisplayed);
		assertion.assertAll();

		return isDisplayed(transferNoNotFoundMsgInSendStoreTransfer);
	}

	public String getTransferNoOnGlobalSearch() {
		return getText(transferNumberDisplayedInGlobalSearch);

	}

	public String getETAOnGlobalSearch() {
		return getText(etaONGlobalSearch);

	}

	public void validateSkuCannotBeEdited() throws InterruptedException {
		
		clickOnTransferIDForDetails();
		
        
		WebElement skuNo = driver.findElements(By.id("com.si:id/liGSST_SKUDetails_SKUNo")).get(0);
		logger.info("Validating if the edit icon is displayed for the partially received Sku Number");
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();

		boolean editImageDisplayed = isDisplayed(editImageToEditSku);
		Assert.assertTrue(editImageDisplayed);
		logger.info("edit icon displayed = "+editImageDisplayed );

		Thread.sleep(5000);
//
//		new TouchAction(driver)
//				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
//						.withDuration(Duration.ofMillis(500)))
//				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() + 10, skuNo.getRect().getY()))
//				.release().perform();
        clickOnGoBackButtonForTransferNo();
        clickOnTransferIDForDetails();
		WebElement skuNo1 = driver.findElements(By.id("com.si:id/liGSST_SKUDetails_SKUNo")).get(1);
		logger.info("Validating if the edit icon is not displayed for the completely  received Sku Number");
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo1))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo1.getRect().getX() - 10, skuNo1.getRect().getY()))
				.release().perform();
		boolean editImageNotDisplayed = isDisplayedWithoutWait(editImageToEditSku);
		Assert.assertFalse(editImageNotDisplayed);
		logger.info("edit icon displayed = "+editImageNotDisplayed );
		


	}

	public void validateRecdSkuNotEdited() {
		SoftAssert assertion = new SoftAssert();
		clickOnTransferIDForDetails();

		WebElement skuNo = driver.findElements(By.id("com.si:id/liGSST_SKUDetails_SKUNo")).get(0);
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		boolean editImageNotDisplayed = isDisplayedWithoutWait(editImageToEditSku);
		assertion.assertFalse(editImageNotDisplayed);

		WebElement skuNo1 = driver.findElements(By.id("com.si:id/liGSST_SKUDetails_SKUNo")).get(1);
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo1))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo1.getRect().getY()))
				.release().perform();
		boolean editImageDisplayed = isDisplayedWithoutWait(editImageToEditSku);
		assertion.assertFalse(editImageDisplayed);
		assertion.assertAll();

	}
	
	public void validateNotAbleToEditReceivedSKU() {
		clickOnTransferIDForDetails();
		WebElement skuNo = driver.findElements(By.id("com.si:id/liGSST_SKUDetails_SKUNo")).get(0);
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		boolean editImageNotDisplayed = isDisplayedWithoutWait(editImageToEditSku);
		assertFalse(editImageNotDisplayed);
		

	}

	public void validateReceivedTransferDateInDB(String transferNumber,String storeNumber) throws Exception {
		clickOnGoBackButtonValidateSkuDetailInGlobalSearch();
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		validateFromMongoDB.validateRecedTransferDateInDB(transferNumber, storeNumber);

	}

	public String getScannedTimeOnGlobalSearch() {
		return getText(scannedTimeOnGlobalSearch);

	}
	
	public String getSpecialHandlingInPOSKU(){
		return getText(POspecialHandling);
	}
	
	public String getDescriptionInPOSKU(){
		return getText(skuDescOnPODetails);
	}
	
	public String getSkuQuantityInPOSKU(){
		return getText(skuQuantityOnPOSku);
	}
	
	public String getSkuReceivedQuantityInPOSKU(){
		return getText(skuReceivedQtyOnPOSku);
	}

	public void receivingPOwithSpecialHandling(String PONumber, SoftAssert assertion,String storeNumber) throws ParseException {

		clickOnGlobalSearch();
		clickOnSpinnerSearchBar();
		selectPO();
		enterPONumber(PONumber);
		elementClick(searchImage);
		String uiPONumber = getPurchaseOrderNo();
		Assert.assertEquals(uiPONumber, PONumber);
		
		MobileElement skuElement=driver.findElementById("com.si:id/recyclerViewGS_Home_PO").findElementsById("com.si:id/liGS_Home_Number").get(0);
		skuElement.click();

		//clickOnDisplayedSkusOnGlobalSearch();
		editSpecialHandlingForPoSKU();
		String POSkuNumber=getText(skuNumberOnGlobalSearch);
		
		//validate time in db
		String specialHandlingSetTime =BaseUtil.getTodayDate("MM/dd/yyyy HH:mm");
		logger.info("Current SpeciaHandlingSetTime is "+specialHandlingSetTime);
		mongoDB.ValidateSpecialHandlingAndTimeInPOInDB(PONumber, POSkuNumber, specialHandlingSetTime, assertion, storeNumber);
	}

	public void editSpecialHandlingForPoSKU() {
		WebElement longPressSpecialHandling = driver.findElement(By.id("com.si:id/liGSPO_SKUDetails_SKUNo"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(longPressSpecialHandling))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(longPressSpecialHandling.getRect().getX() - 10,
						longPressSpecialHandling.getRect().getY()))
				.release().perform();
		clickOnEditImage();
		enterSpecialHandlingValueForPO();

	}

	public void enterSpecialHandlingValueForPO() {

		elementClick(spinnerSpecialHandlingForPO);
		elementClick(backOrderSpecialHandlingForPO);
		elementClick(saveSpecialHandlingInPO);

	}

	public void clickOnEditImage() {

		elementClick(editImage);
	}

	public void selectPO() {
		elementClick(POListView);

	}

	public void enterPONumber(String pONumber) {
		setText(searchFromAnyCriteria, pONumber);
		elementClick(searchImage);

	}

	public void receivingPOwithSpecialHandlingWhenCancelled(String poNumber) {
		clickOnGlobalSearch();
		clickOnSpinnerSearchBar();
		selectPO();
		enterPONumber(poNumber);
		elementClick(searchImage);
		clickOnDisplayedSkusOnGlobalSearch();
		validateWhenSpecialHandlingCancelled();

	}

	public void validateWhenSpecialHandlingCancelled() {
		WebElement longPressSpecialHandling = driver.findElement(By.id("com.si:id/liGSPO_SKUDetails_SKUNo"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(longPressSpecialHandling))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(longPressSpecialHandling.getRect().getX() - 10,
						longPressSpecialHandling.getRect().getY()))
				.release().perform();
		clickOnEditImage();
		elementClick(spinnerSpecialHandlingForPO);
		elementClick(backOrderSpecialHandlingForPO);
		elementClick(clickOnCancelInSpecialHandling);

	}

	public void enterSkuNumber(String skuNumber) {
		setText(searchFromAnyCriteria, skuNumber);

	}

	

	public boolean isDcShipmentDisplayed() {
		return isDisplayed(dcShipmentLabel);
	}

	public boolean isStoreTransferDisplayed() {
		return isDisplayed(storeTransferLabel);
	}

	public boolean isPurchaseOrderDisplayed() {
		return isDisplayed(purchaseOrderLabel);
	}

	public void validateGoBackSearchInGlobalSearchForPO(String poNumber) {
		SoftAssert assertion = new SoftAssert();
		clickOnGlobalSearch();
		clickOnSpinnerSearchBar();
		selectPO();
		enterPONumber(poNumber);
		elementClick(searchImage);
		clickOnPOInGlobalSearch();
		clickOnGoBackBtnForPO();
		String purchaseOrderNo = getPurchaseOrderNo();
		assertion.assertEquals(purchaseOrderNo, poNumber);
		assertion.assertAll();
		
	}

	public String getPurchaseOrderNo() {
		return getText(displayedDetailInGlobalSearch);

	}

	public void clickOnPOInGlobalSearch() {
		elementClick(displayedDetailInGlobalSearch);

	}

	public void clickOnGoBackBtnForPO() {
		elementClick(goBackButtonForPOInGlobalSearch);

	}

	public void validateGoBackSearchInGlobalSearchForTransferNo(String transferNo) {
		SoftAssert assertion = new SoftAssert();
		clickOnGlobalSearch();
		searchForTransferID(transferNo);

		clickOnTransferIDForTransferDetail();
		clickOnGoBackButtonForTransferNo();
		boolean transferNoDisplayed = isDisplayed(displayedDetailInGlobalSearch);
		assertion.assertTrue(transferNoDisplayed);
		assertion.assertAll();

	}

	private void clickOnGoBackButtonForTransferNo() {
		elementClick(goBackButtonOnSkuDetailsInGlobalSearch);
	}

	public void enterTransferNo() {

	}

	public void validateHomePageDisplayed() {
		SoftAssert assertion = new SoftAssert();
		clickOnGlobalSearch();
		clickOnGoBackOfGlobalSearch();
		boolean homeScreenDisplayed = homePage.isHomeScreen();
		assertion.assertTrue(homeScreenDisplayed);
		assertion.assertAll();

	}

	public void validateAuditingPageDisplayed() {
		SoftAssert assertion = new SoftAssert();
		homePage.clickOnAuditing();
		clickOnGlobalSearch();
		clickOnGoBackOfGlobalSearch();
		boolean inStoreDamages = auditingPage.isStoreDamagesDisplayed();
		assertion.assertEquals(inStoreDamages, true);
		assertion.assertAll();

	}

	public void validateInStoreDamagesDisplayed() {
		SoftAssert assertion = new SoftAssert();
		auditingPage.clickInStoreDamages();
		clickOnGlobalSearch();
		clickOnGoBackOfGlobalSearch();
		boolean isPlusSignDisplayed = auditingInStoreDamagesScanPage.isPlusSignDisplayed();
		assertion.assertEquals(isPlusSignDisplayed, true);
		assertion.assertAll();

	}

	public void validateAddDamagedSkuPageDisplayed() {
		SoftAssert assertion = new SoftAssert();
		auditingInStoreDamagesScanPage.clickOnAddButton();
		clickOnGlobalSearch();
		clickOnGoBackOfGlobalSearch();
		boolean isAddDamagedSkuDisplayed = auditingInStoreDamagesScanPage.isSearchBarAddDamagedSkuDisplayed();
		assertion.assertEquals(isAddDamagedSkuDisplayed, true);
		assertion.assertAll();

	}

	public void editAndSaveSpecialHandlingForPOSku(String skuNumber) {
		SoftAssert assertion = new SoftAssert();
		clickOnGlobalSearch();
		enterSkuNumber(skuNumber);
		elementClick(searchImage);
		boolean purchaseOrder = isPurchaseOrderDisplayed();
		assertion.assertTrue(purchaseOrder);
		elementClick(displayedDetailInGlobalSearch);
		// driver.findElements(By.id("com.si:id/liGS_Home_Number")).get(2).click();

		WebElement longPressSpecialHandling = driver.findElement(By.id("com.si:id/liGSPO_SKUDetails_SKUNo"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(longPressSpecialHandling))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(longPressSpecialHandling.getRect().getX() - 10,
						longPressSpecialHandling.getRect().getY()))
				.release().perform();
		clickOnEditImage();
		enterSpecialHandlingValueForPO();

		String skuNo = getSkuNo();
		assertion.assertEquals(skuNo, skuNumber);

		boolean backOrderSpecialHandling = isSpecialHandlingDisplayed();
		assertion.assertTrue(backOrderSpecialHandling);

		String purchanseOrder = getPurchaseOrderValue();
		assertion.assertEquals(purchanseOrder, "11188572");

		String skuDesc = getSkuDescOnPODetails();
		assertion.assertEquals(skuDesc, "Steamer");
		assertion.assertAll();

	}

	public String getSkuDescOnPODetails() {
		return getText(skuDescOnPODetails);

	}

	public String getSkuNo() {
		return getText(skuNumberOnGlobalSearch);
	}

	public boolean isSpecialHandlingDisplayed() {
		return isDisplayed(backOrderSpecialHandlingForPO);
	}

	public String getPurchaseOrderValue() {
		return getText(purchaseOrderInGlobalSearch).substring(15);
	}

	public void validateTheErrorMsgNoSkuFound(String skuNumber) {
		SoftAssert assertion = new SoftAssert();
		clickOnGlobalSearch();
		enterSkuNumber(skuNumber);
		elementClick(searchImage);

		boolean errorMsgDisplayed = isErrorMsgDisplayed();
		assertion.assertTrue(errorMsgDisplayed);
		assertion.assertAll();

	}

	public boolean isErrorMsgDisplayed() {
		return isDisplayed(errorMsgNoSkuFound);

	}

	public void validateSkuDetailsForStoreTransfer(String skuNumber) {
		SoftAssert assertion = new SoftAssert();
		clickOnGlobalSearch();
		enterSkuNumber(skuNumber);
		elementClick(searchImage);
		clickOnTransferIDForDetails();
		String skuNumberForStoreTransfer = getSkuNumberonTransfer();
		assertion.assertEquals("5739995", skuNumberForStoreTransfer);

		String skuDesc = getSkuDescriptionOnTransfer();
		assertion.assertEquals("Roccbox Pizza Oven, Gray", skuDesc);

		String skuQty = getSkuQtyOnTransfer();
		assertion.assertEquals("1", skuQty);
		assertion.assertAll();

	}

	public void setSpecialHandlingForAStoreTransferSku(String skuNumber) {
		SoftAssert assertion = new SoftAssert();
		WebElement longPressSpecialHandling = driver.findElement(By.id("com.si:id/liGSST_SKUDetails_SKUNo"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(longPressSpecialHandling))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(longPressSpecialHandling.getRect().getX() - 10,
						longPressSpecialHandling.getRect().getY()))
				.release().perform();
		elementClick(editSpecialHandling);
		enterSpecialHandlingForASku();
		String specialHandlingForSku = getSpecialHandlingValue();
		assertion.assertEquals(specialHandlingForSku, "Special Order");
		assertion.assertAll();
		homePage.clickOnMenuBar();
		homePage.clickOnStoreTransferOnSideMenuBar();
		sendAndReceiveTransferPage.clickOnReceiveStoreTransfer();

	}

	public String getSpecialHandlingValue() {
		return getText(specialOrderSpecialHandlingForSku);
	}
	
	public String getCartonSkuQty(){
		return getText(receivedSKUQty);
	}
	
	public String getCartonSkuShippedQty(){
		return getText(shippedSKUQty);
	}
	
	
	public String getCartonSkuDamagedQty(){
		return getText(cartonSkuDamagedQty);
	}

	private void enterSpecialHandlingForASku() {
		elementClick(spinnerSpecialHandlingForTransferSKU);
		elementClick(specialHandlingSpecialOrderForSku);
		elementClick(saveSkuInSpecialHandling);

	}

	public void validateReceivedTransferETA30DaysLessOrMoreInGlobalSearch(String skuNumber)
			throws InterruptedException {
		SoftAssert assertion = new SoftAssert();
		clickOnGlobalSearch();
		enterSkuNumber(skuNumber);
		elementClick(searchImage);
		fluentWait(errorMsgNoSkuFound);
		isDisplayedWithoutWait(errorMsgNoSkuFound);
		boolean errorMsgDisplayed = isErrorMsgDisplayed();
		assertion.assertTrue(errorMsgDisplayed);
		assertion.assertAll();

	}

	public void receivingPOMoreThan30DaysInGlobalSearch(String poNumber) {
		SoftAssert assertion = new SoftAssert();
		clickOnGlobalSearch();
		clickOnSpinnerSearchBar();
		selectPO();
		enterPONumber(poNumber);
		elementClick(searchImage);
		fluentWait(errorMsgNoSkuFound);
		isDisplayedWithoutWait(errorMsgNoSkuFound);
		boolean errorMsgDisplayed = isErrorMsgDisplayed();
		assertion.assertTrue(errorMsgDisplayed);
		assertion.assertAll();

	}

	public void validateSKUDetailsForCartonSku(String skuNumber, String cartonNumber,String storeNumber) throws ParseException {
		
		clickOnGlobalSearch();
		enterSkuNumber(skuNumber);
		elementClick(searchImage);
		
		MobileElement skuElement=driver.findElementById("com.si:id/recyclerViewGS_Home_DCShip").findElementsById("com.si:id/liGS_Home_Number").get(0);
		skuElement.click();
		
		//elementClick(dcShipmentSkuInGlobalSearch);

		String cartonNo = getCartonNumberInGlobalSearch().substring(8);
		assertEquals(cartonNo, cartonNumber);
		
		
		String skuNo = getSkuNumberForCarton();
		assertEquals(skuNo, skuNumber);

		//validate sku Detail in db
		mongoDB.validateSkuDetailsInGlobalSearchForCarton(cartonNumber, storeNumber);

		
	}

	public void validateSpecialHandlingInDcShipment(String cartonNumber) {

		receivingShipment.clickOnScanButton();
		receivingShipmentScanPage.clickAddButton();
		receivingShipmentScanPage.enterCartonNumber(cartonNumber);
		receivingShipmentScanPage.clickSearchButton();
		receivingShipmentScanPage.clickOnAddButtonOnBottom();
		receivingShipmentScanPage.reEnter4DigitsToValidateInGlobalSearch(cartonNumber);
		receivingShipmentScanPage.clickOnEnterButtonAfterFourDigits();

		String textVisualSetUp = receivingShipmentScanPage.getSpecialHandlingText();
		Assert.assertEquals(textVisualSetUp, "Visual Set Up");

		
		receivingShipmentScanPage.clickOkButtonOnSpecialHandlingMessageBox();

	}

	public void markSpecialHandlingInCartonSku(String cartonNumber,String storeNumber) throws ParseException {
		
		WebElement longPressSpecialHandling = driver.findElement(By.id("com.si:id/liDCShip_CartonDetails_SKUDesc"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(longPressSpecialHandling))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(longPressSpecialHandling.getRect().getX() - 10,
						longPressSpecialHandling.getRect().getY()))
				.release().perform();

		elementClick(editSpecialHandlingForcarton);
		elementClick(dropDownSpecialHandlingForCarton);
		elementClick(visualSetUpSpecialHandling);
		elementClick(saveSpecialHandlingForCartonSku);
		
		String savedTime =BaseUtil.getTodayDate("MM/dd/yyyy HH:mm");
		logger.info("Current SpecialHandlingSavedTime is "+savedTime);

		String specialHandlingForCartonSku = getSpecialHandlingForCarton();
		Assert.assertEquals(specialHandlingForCartonSku, "Visual Set Up");
		
		//validate lastDocumentUpdate Time in DB and specialHandling code
		mongoDB.validateSpecialHandlingInGlobalSearchForCarton(cartonNumber, storeNumber, savedTime);
		
		

	}

	public String getSpecialHandlingForCarton() {
		return getText(dcShipmentDetailSpecialHandling);

	}

	public String getSkuDescForCarton() {
		return getText(skuDescriptionInCartonSearch);

	}

	public String getSkuNumberForCarton() {
		return getText(dcShipmentDetailInGlobalSearch);

	}

	public String getCartonNumberInGlobalSearch() {
		return getText(cartonNoInGlobalSearchDetail);

	}

	public void validateCartonETAMoreThan31Days(String skuNumber) {
		SoftAssert assertion = new SoftAssert();
		clickOnGlobalSearch();
		enterSkuNumber(skuNumber);
		elementClick(searchImage);
		fluentWait(errorMsgNoSkuFound);
		isDisplayedWithoutWait(errorMsgNoSkuFound);
		boolean errorMsgDisplayed = isErrorMsgDisplayed();
		assertion.assertTrue(errorMsgDisplayed);
		assertion.assertAll();

	}

	public void markSpecialHandlingForCarton(String cartonNumber, SoftAssert assertion) throws InterruptedException {
		
		clickOnDisplayedCartonOnGlobalSearch();
		WebElement longPressSpecialHandling = driver.findElement(By.id("com.si:id/liDCShip_CartonDetails_SKUDesc"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(longPressSpecialHandling))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(longPressSpecialHandling.getRect().getX() - 10,
						longPressSpecialHandling.getRect().getY()))
				.release().perform();
		elementClick(editSpecialHandlingForcarton);
		elementClick(dropDownSpecialHandlingForCarton);
		elementClick(visualSetUpSpecialHandling);
		elementClick(saveSpecialHandlingForCartonSku);
		String specialHandlingForCarton = getSpecialHandlingForCarton();
		assertion.assertEquals(specialHandlingForCarton, "Visual Set Up");

		homePage.clickOnMenuBar();
		homePage.clickOnDCShipmentsOnSideMenuBar();
		validateSpecialHandlingInDcShipment(cartonNumber);
		assertion.assertAll();

	}

	public void validateCartonAndETA(String cartonNumber, SoftAssert assertion) {
		
		clickOnGlobalSearch();
		clickOnSpinnerSearchBar();
		clickOnCartonFromSpinnerSearch();
		enterCartonNumber(cartonNumber);
		String cartonNo = getCartonNumber();
		assertion.assertEquals(cartonNo, cartonNumber);
		

	}

	public void markSpecialHandlingForCartonETAMoreThan365(String cartonNumber) {
		SoftAssert assertion = new SoftAssert();
		clickOnGlobalSearch();
		clickOnSpinnerSearchBar();
		clickOnCartonFromSpinnerSearch();
		enterCartonNumber(cartonNumber);
		boolean errorMsgDisplayed = isErrorMsgDisplayed();
		assertion.assertTrue(errorMsgDisplayed);
		assertion.assertAll();

	}

	public void validateRecdCartonSearchableInGlobalSearchFor365Days(String cartonNumber) {
		SoftAssert assertion = new SoftAssert();
		clickOnGlobalSearch();
		clickOnSpinnerSearchBar();
		clickOnCartonFromSpinnerSearch();
		enterCartonNumber(cartonNumber);
		String cartonNo = getCartonNumber();
		assertion.assertEquals(cartonNo, cartonNumber);
		assertion.assertAll();

	}
	
	public void validateThreeSKUDisplayedInGlobalSearch(String skuNumber) throws ParseException, InterruptedException {
		SoftAssert assertion = new SoftAssert();
		// clickOnTextBox();
		clickOnGlobalSearch();
		enterSkuNumber(skuNumber);
		elementClick(searchImage);
		boolean dcShipment = isDcShipmentDisplayed();
		assertion.assertTrue(dcShipment);

		boolean storeTransfer = isStoreTransferDisplayed();
		assertion.assertTrue(storeTransfer);

		boolean purchaseOrder = isPurchaseOrderDisplayed();
		assertion.assertTrue(purchaseOrder);
		
		isDisplayedSkuNumberInGlobalSearch(skuNumber,assertion);
		////
		scrollRecyclerViewListAndValidate();
        
		assertion.assertAll();

		

	}

	public void isDisplayedSkuNumberInGlobalSearch(String skuNumber, SoftAssert assertion) {
		
		List<MobileElement> skuNumberOnGlobalSearch = driver.findElements(By.id("com.si:id/liGS_Home_Number"));

		logger.info("Size of Sku Number list : "+skuNumberOnGlobalSearch.size());
		assertion.assertEquals(skuNumberOnGlobalSearch.size(), 6);
		
		for (int i = 0; i < skuNumberOnGlobalSearch.size(); i++) {
			String skuValue = getText(displayedDetailInGlobalSearch);
			assertion.assertEquals(skuValue, skuNumber);
		}

	}
	
	public void scrollRecyclerViewListAndValidate() throws ParseException, InterruptedException{
		
		List<String> headingList=  new ArrayList<String>(3);
		headingList.add("DC SHIPMENT");
		headingList.add("STORE TRANSFER");
		headingList.add("PURCHASE ORDER");
		
		List<MobileElement> recyclerViewList = driver.findElementsByClassName("android.support.v7.widget.RecyclerView");
				                                 //driver.findElements(By.id("com.si:id/recyclerViewGS_Home_DCShip"));
		logger.info("Size of recyclerViewList is "+recyclerViewList.size());
		assertEquals(recyclerViewList.size(), 3);
		
		for (int i = 0; i < recyclerViewList.size(); i++) {
			logger.info(headingList.get(i));
		
            List<MobileElement> skuNumberOnGlobalSearch=recyclerViewList.get(i).findElementsById("com.si:id/liGS_Home_Number");
            logger.info("Size of sku list before scroll for recycler ["+i+"] is :"+skuNumberOnGlobalSearch.size());
             int sizeofSkuList=skuNumberOnGlobalSearch.size();
             assertEquals(sizeofSkuList, 2);
             
             String isScrollable=recyclerViewList.get(i).getAttribute("scrollable");
             logger.info("Scrollable flag for recycler ["+i+"] is :"+isScrollable);
             assertEquals(isScrollable, "true");
             
             List<MobileElement> datelistOnGlobalSearch=  recyclerViewList.get(i).findElementsById("com.si:id/liGS_Home_Date");
             logger.info("Size of DateList  before scroll for recycler ["+i+"] is :"+datelistOnGlobalSearch.size());
     		
			Thread.sleep(2000);
			
            boolean isScrolled= scrollDownByElement(skuNumberOnGlobalSearch);
            assertTrue(isScrolled);
             
             List<MobileElement> skuListAfterScroll=recyclerViewList.get(i).findElementsById("com.si:id/liGS_Home_Number");
             skuNumberOnGlobalSearch.addAll(skuListAfterScroll);
             logger.info("Size of sku list after scroll for recycler ["+i+"] is :"+skuNumberOnGlobalSearch.size());
 			
 			
 			boolean value=false;
 			if(skuNumberOnGlobalSearch.size()>=3){
 				value=true;
 			}
 			 assertTrue(value);
		
 			List<MobileElement> tmpDatelistAfterScroll=  recyclerViewList.get(i).findElementsById("com.si:id/liGS_Home_Date");
 			datelistOnGlobalSearch.addAll(tmpDatelistAfterScroll);
 			logger.info("Size of DateList  after scroll for recycler ["+i+"] is :"+datelistOnGlobalSearch.size());
     		
     		validateDateOnGlobalSearch(datelistOnGlobalSearch);
	
			Thread.sleep(3000);
		
		}
		

	}
	
	public void validateDateOnGlobalSearch(List<MobileElement> datelistOnGlobalSearch) throws ParseException{
		
		LinkedHashSet<String> dateSetAfterScroll= new LinkedHashSet<String>();
 		
 		for(int m=0; m<datelistOnGlobalSearch.size(); m++){
 			String stringDate=datelistOnGlobalSearch.get(m).getText();
 			logger.info(m+" is "+stringDate);
 			dateSetAfterScroll.add(stringDate);
 		}
 		
 		logger.info("Size of DateHashSet  after adding value is "+dateSetAfterScroll.size());
 		
       ArrayList<String> datelist= new ArrayList<String>(dateSetAfterScroll);
		
       logger.info("Size of Datelist after conversion is "+datelist.size());
		
	   for (int i = 0; i <datelist.size()-1; i++) {
		
		String date1=datelist.get(i);
		String date2=datelist.get(i+1);
		
		logger.info("date1 "+date1+": date2 "+date2);
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date datefirst = dateFormat.parse(date1);
		Date datesecond = dateFormat.parse(date2);
		boolean datevalue=false;
		if(datefirst.after(datesecond)){
			datevalue=true;
		}
		logger.info("Boolean value after comparing 2 date is "+datevalue);
		assertTrue(datevalue);
		logger.info(date1+" is after "+date2);
	}
	   
	}
	
	public void validateSearchExitInGlobalSearch(String skuNumber) throws InterruptedException{
    	
		    elementClick(searchFromAnyCriteria);
		    setText(searchFromAnyCriteria, skuNumber);
			
		    boolean keyboardBefore=driver.isKeyboardShown();
			logger.info("Keyboard Displayed flag before search Exit in GlobalSearch :"+keyboardBefore);
			
			Thread.sleep(1000);
			TouchAction touchAction = new TouchAction(driver);
			touchAction.tap(PointOption.point(650, 300)).perform();
			
			boolean keyboardAfter=driver.isKeyboardShown();
			logger.info("Keyboard Displayed flag after search Exit in GlobalSearch:"+keyboardAfter);
			assertFalse(keyboardAfter);
		
	    }
	
public void enterCartonNumberInGlobalSearch(String cartonNumber) {
		
		clickOnGlobalSearch();
		clickOnSpinnerSearchBar();
		clickOnCartonFromSpinnerSearch();
		enterCartonNumber(cartonNumber);
		
	}

public void enterPONumberInGlobalSearch(String PONumber) {

	clickOnGlobalSearch();
	clickOnSpinnerSearchBar();
	selectPO();
	enterPONumber(PONumber);
}

public void enterTransferNumberInGlobalSearch(String transferNumber) {

	clickOnGlobalSearch();
	clickOnSpinnerSearchBar();
	elementClick(transferIDListView);
	setText(searchFromAnyCriteria, transferNumber);
	elementClick(searchImage);
}

public void validateDetailsofOrphanCartonWithSkus(String cartonNumber) {
	enterCartonNumberInGlobalSearch(cartonNumber);
	validateOrphanCartonDetailInHomeScreen(cartonNumber);
	
}

private void validateOrphanCartonDetailInHomeScreen(String cartonNumber) {
	String cartonNo = getCartonNumber();
	Assert.assertEquals(cartonNo, cartonNumber);
	logger.info("Displayed Carton Number--> "+cartonNo);
	String TodayDate = getTodayDate("yyyy-MM-dd");
	String ScannedTime=getScannedTimeOnGlobalSearch();
	Assert.assertEquals(TodayDate, ScannedTime);
	logger.info("Displayed ScannedTime--> "+ScannedTime);
	
	Screen s= new Screen();
	Pattern tickimagepattern = new Pattern("tick_image.PNG"); 
	
	boolean foundtick=false;
	if (s.exists(tickimagepattern) != null){
		foundtick=true;
		logger.info("Tick image found");
	}
	
	Assert.assertTrue(foundtick);
	
}
	


}
