package com.pdt.Pom;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.sql.SQLException;
import java.text.ParseException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.util.DataBase.OracleDBConnection;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.AndroidBasePage;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import ru.yandex.qatools.allure.annotations.Step;

public class SendStoreTransferPage extends AndroidBasePage {
	final static Logger logger = Logger.getLogger(SendStoreTransferPage.class.getName());
	SoftAssert softassertion = new SoftAssert();
	SkuDetailTransferPage skuDetailTransferPage = new SkuDetailTransferPage();
	protected By transferNoInSendStore = By.id("com.si:id/lblSendST_SKUDescDetails_TransferNo");

	protected By transferNumberOnTransferSummeryScreen = By
			.xpath("//android.widget.TextView[@resource-id='com.si:id/lblSendST_TransferSummary_TransferNo']");
	protected By goBackOnAddSku = By.id("com.si:id/btnSendST_AddSKU_Back");
	protected By duplicateInvalidSkuNumberMessage = By.id("com.si:id/lblSendST_AddSKU_SKUNo");
	// com.si:id/btnSendST_AddSKU_Add
	protected By cancelButton = By.id("com.si:id/btnTemplate_AddStore_Cancel");

	protected By incorrectStoreEntryMessage = By.id("com.si:id/lblTemplate_AddStore_Error");
	protected By addedSkuNumber = By.id("com.si:id/lblSendST_AddSKU_SKUNo");
	protected By addedSkuDescription = By.id("com.si:id/lblSendST_AddSKU_SKUDesc");
	protected By enterRecevingStoreNumber = By.id("com.si:id/lblTemplate_AddStore_Message");
	protected By ToStoreNumber = By.id("com.si:id/liSendST_TransferList_ToStore");
	protected By totalskuQtyHome = By
			.xpath("//android.widget.TextView[@resource-id='com.si:id/liSendST_TransferList_SKUQty']");
	protected By submit = By.id("com.si:id/btnSendST_TransferSummary_Submit");
	protected By specificskuNumberList = By
			.xpath("//android.widget.TextView[@resource-id='com.si:id/liSendST_SKUDetails_SKUNo']");
	protected By skuNumberOnTransferDetailPage = By.id("com.si:id/liSendST_SKUDetails_SKUNo");

	protected By tickMark = By.id("com.si:id/liSendST_SKUDetails_ArrowImage");

	protected By totalskuQty = By.id("com.si:id/lblSendST_SKUDetails_TotalQty");
	protected By specificSkuQty = By
			.xpath("//android.widget.TextView[@resource-id='com.si:id/liSendST_SKUDetails_SKUQty']");

	protected By transferNumber = By.id("com.si:id/lblSendST_SKUDetails_TransferNo");

	protected By transferNumberHome = By
			.xpath("//android.widget.TextView[@resource-id='com.si:id/listSendST_TransferList_TransferNo']");
	protected By totalSkuQtyHome = By
			.xpath("//android.widget.TextView[@resource-id='com.si:id/liSendST_TransferList_SKUQty']");

	protected By transfer = By.id("com.si:id/btnSendST_TransferList_NewTransfer");
	protected By storeNumberToTransfer = By.id("com.si:id/txtTemplate_AddStore_StoreNo");
	protected By enterButton = By.id("com.si:id/btnTemplate_AddStore_Enter");
	protected By plusSignBtnToAddSku = By.id("com.si:id/btnSendST_SKUDetails_Add");
	protected By transferNumberSearchBar = By.id("com.si:id/search_bar");

	protected By searchBarTextBox = By.id("com.si:id/search_src_text");

	protected By cancelBtnOnEnterRecvgStoreNo = By.id("com.si:id/btnTemplate_AddStore_Cancel");

	protected By skuDescriptionOnSkuDetails = By
			.xpath("//android.widget.TextView[normalize-space(@text)='SKU Description']");

	protected By actualSkuDescription = By.xpath("com.si:id/liSendST_SKUDetails_SKUDesc");
	protected By qtyOnSkuDetails = By.id("com.si:id/liSendST_SKUDetails_SKUQty");
	protected By gobackBtnOnSkuDetails = By.id("com.si:id/btnViewSendST_SKUDescDetails_back");

	protected By goBackButton = By.id("com.si:id/btnSendST_SKUDetails_Back");
	protected By SkuWithTransferNumber = By.id("com.si:id/liSendST_SKUDetails_SKUNo");

	protected By addButtonOnBottom = By.id("com.si:id/btnSendST_AddSKU_Add");
	protected By plusSignOnBottom = By.id("com.si:id/btnSendST_SKUDetails_Add");

	protected By searchButtonOnKeyboard = By.id("com.si:id/LytAddSKUScan");
	protected By enter3SkuDigit = By.id("com.si:id/EdtSKUDigits");
	protected By transferOrderinProgress = By.id("com.si:id/listSendST_TransferList_TransferNo");
	protected By transferNumberLabel = By.id("com.si:id/lblSendST_SKUDetails_TransferNo");
	protected By totalQtyZeroByDefault = By.xpath("//android.widget.TextView[normalize-space(@text)='TOTAL QTY 0']");
	protected By startScanningSkuLabelsMsg = By.xpath(
			"//android.widget.TextView[normalize-space(@text)='Start scanning SKU labels to add to transfer order']");
	protected By transferNumberOnTransferSummery = By.id("com.si:id/listSendST_TransferList_TransferNo");
	protected By destinationStoreNumberOnTransferSummeryScreen = By.id("com.si:id/liSendST_TransferList_ToStore");
	protected By totalSquQtyOnTransferSummeryScreen = By.id("com.si:id/liSendST_TransferList_SKUQty");
	protected By searchButtonOnSkuTransfer = By.id("com.si:id/search_button");
	// protected By clickOnQtyToViewTransferOrderInProgress =
	// By.id("com.si:id/liSendST_SKUDetails_SKUQty");

	protected By transferSummery = By.id("com.si:id/btnSendST_SKUDetails_Summary");
	protected By submitTransferSummery = By.id("com.si:id/btnSendST_TransferSummary_Submit");
	protected By continueScanningTransferSummery = By.id("com.si:id/btnSendST_TransferSummary_Submit");
	protected By transferOrderSuccessfullySubmittedMsg = By
			.xpath("//android.widget.TextView[normalize-space(@text)='Transfer Order Submitted Successfully']");
	protected By OkButtonAfterSucceesfullMsg = By.id("android:id/button1");
	protected By totalSentSkuQtyOnTransferSummery = By.id("com.si:id/lblSendST_TransferSummary_TotalSKUQty");
	protected By destinationStoreNumber = By.id("com.si:id/lblSendST_TransferSummary_ToStore");
	protected By createdOnDateOnTransferSummery = By.id("com.si:id/lblSendST_TransferSummary_CreatedDate");
	protected By transferNoOnTransferSummery = By.id("com.si:id/listSendST_TransferList_TransferNo");
	protected By transferHomeBtn = By.id("com.si:id/btnSendST_TransferSummary_TransferHome");
	protected By skuNoToBeTransferred = By.xpath("//android.widget.TextView(@text, 'SKU#5739995')");

	protected By transferNumberOnTransferSummeryPage = By.id("com.si:id/lblSendST_TransferSummary_TransferNo");
	// Ids by ovi
	protected By skuediticon = By.xpath("com.si:id/imgSendST_SKUDetails_Edit");
	protected By firsttransfernumbertransferhome = By.id("com.si:id/listSendST_TransferList_TransferNo");
	protected By editicon = By.id("com.si:id/imgSendST_SKUDetails_Edit");
	protected By editskuqty = By.id("com.si:id/txtSendST_EditSKU_SKUQty");
	protected By savebutton = By.id("com.si:id/btnSendST_EditSKU_Save");
	protected By cancelbutton = By.id("com.si:id/btnSendST_EditSKU_Cancel");
	protected By alertPopUpForZeroQty = By.id("android:id/message");
	protected By okButtonAlertPopUp = By.id("android:id/button1");
	protected By defaultMessage = By.id("com.si:id/lblSendST_SKUDetails_Message");
	protected By enterStoreNumberMessage = By.id("com.si:id/lblTemplate_AddStore_Message");
	protected By addSkuHeading = By.id("com.si:id/lblSendST_AddSKU_Header");
	protected By transferNumberOnSkuDetailPage=By.id("com.si:id/lblSendST_SKUDescDetails_TransferNo");
	protected By skuLabel = By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']");
	protected By skuDescLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='SKU Description']");
	protected By skuQtyLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='SKU QTY']");
	
	protected By toStoreLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='TO STORE']");
	protected By totalskuQtyLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='TOTAL SKU QTY']");
	protected By cancelTransferButton=By.id("com.si:id/btnSendST_SKUDetails_Cancel");
	protected By alertPopUpMsg=By.id("com.si:id/lblSKUQtyMessage");
	protected By alertPopUpNoBtn=By.id("com.si:id/btnPopUpNo");
	protected By alertPopUpYesBtn=By.id("com.si:id/btnPopUpYes");
	protected By sendTransferHomePageHeading=By.id("com.si:id/lblSendST_TransferList_Header");
	protected By transferInProgressMsg=By.xpath("//android.widget.TextView[normalize-space(@text)='TRANSFER Transfer order in progress']");
	protected By alertMessagePopup = By.id("android:id/message");
	
	HomePage homePage = new HomePage();
	ValidateFromMongoDB mongoDB= new ValidateFromMongoDB();
	
	
	public String getSkuQtyOntransferDetailpage() {
		return driver.findElements(qtyOnSkuDetails).get(0).getText();
	}

	public void validatationInSendStoreTransferforforInvalidSkuNumber(String storeNumber, String inValidSkuNumber) {
		SoftAssert softassertion = new SoftAssert();
		clickOnTransfer();
		enterReceivingStoreNumber(storeNumber);
		clickOnEnter();
		clickOnPlusSign();
		enterSkuNumber(inValidSkuNumber);
		clickSearchButton();

		String invalidSkuNumberMessage = getDuplicateInvalidSkuNumberMessage();
		softassertion.assertEquals("SKU Number not found", invalidSkuNumberMessage);

		elementClick(duplicateInvalidSkuNumberMessage);

		boolean addBtnNotEnabled = isAddButtonEnabled();
		softassertion.assertEquals(false, addBtnNotEnabled);
		clickOnGoBackButtonOnAddSku();
		softassertion.assertAll();
	}

	public String validatationInSendStoreTransferforforDuplicateSkuNumber(String storeNumber, String skuNumber) {
		
		SoftAssert softassertion = new SoftAssert();
		clickOnPlusSign();
		enterSkuNumber(skuNumber);
		clickSearchButton();
		clickAddButtonOnBottom();

		clickOnPlusSign();
		enterSkuNumber(skuNumber);
		clickSearchButton();

		String duplicateSkuNumberMessage = getDuplicateInvalidSkuNumberMessage();
		softassertion.assertEquals("Duplicate SKU number. Please try again", duplicateSkuNumberMessage);
		elementClick(duplicateInvalidSkuNumberMessage);
		boolean addBtnNotEnabled = isAddButtonEnabled();
		softassertion.assertEquals(false, addBtnNotEnabled);
		
		clickOnGoBackButtonOnAddSku();
		
		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		clickOnOkButtonOnSuccessfullySubmittedMsg();
		fluentWait(transferNumberOnTransferSummeryPage);
		String transferNumber = getTransferNumberOnTransferSummaryPage().substring(10);
		logger.info("TransferNumber Created is " + transferNumber);
		softassertion.assertAll();
		return transferNumber;

	}

	public boolean isAddButtonEnabled() {
		return isEnabled(addButtonOnBottom);
	}

	public void clickOnGoBackButtonOnAddSku() {
		elementClick(goBackOnAddSku);
	}

	public String getDuplicateInvalidSkuNumberMessage() {
		return getText(duplicateInvalidSkuNumberMessage);

	}

	public void pressBackButton() {
		// driver.pressKey(new KeyEvent(AndroidKey.BACK));
		driver.pressKeyCode(AndroidKeyCode.BACK);
	}

	// used by ruthra SRA236
	public void validatationInSendStoreTransferforSameOrInvalidStoreNumber(String storeNumber) {
		SoftAssert softassertion = new SoftAssert();
		clickOnTransfer();
		enterReceivingStoreNumber(storeNumber);
		clickOnEnterToVerifyErrorMsg();

		boolean isErrorMessageDisplayed = verifyIncorrectStoreErrorMessage();
		softassertion.assertTrue(isErrorMessageDisplayed);

		String incorrectStoreEntryMessage = getIncorrectStoreEntryMessage();
		softassertion.assertEquals("Incorrect Entry. Please enter again", incorrectStoreEntryMessage);
		clickOnCancel();
		softassertion.assertAll();
	}

	public boolean verifyIncorrectStoreErrorMessage() {
		return isDisplayed(incorrectStoreEntryMessage);

	}

	public void clickOnCancel() {
		elementClick(cancelButton);

	}

	public String getIncorrectStoreEntryMessage() {
		return getText(incorrectStoreEntryMessage);
	}

	public String validatationInSendStoreTransfer(String storeNumber, String skuNumber) throws ClassNotFoundException, SQLException {
		SoftAssert softassertion = new SoftAssert();
		OracleDBConnection oracleDB= new OracleDBConnection();
		clickOnTransfer();
		String msgToEnterRecevingStoreNumber = validateMsgToEnterRecevingStoreNumber();
		softassertion.assertEquals("Please enter valid receiving store number", msgToEnterRecevingStoreNumber);

		enterReceivingStoreNumber(storeNumber);
		clickOnEnter();
		clickOnPlusSign();
		enterSkuNumber(skuNumber);
		clickSearchButton();

		String addedSkuNumber = getAddedSkuNumber();
		softassertion.assertEquals(skuNumber, addedSkuNumber);
		logger.info("AddedSkuNumber " + addedSkuNumber);
		
		String addedSkuDescription=getAddedSkuDescription();
		HashMap<String, String>  skuValueMap=oracleDB.getSkuPriceFromOracleDB(skuNumber,storeNumber);
		String skudescriptionDB=skuValueMap.get("skuDescShort");
		logger.info("Sku shortDescription from OracleDB :"+skudescriptionDB);
		softassertion.assertEquals(skudescriptionDB, addedSkuDescription);
		
		clickAddButtonOnBottom();

		String skuNumberOnDetailPage = getSkuNoOnTransferDetailPage().substring(5);
		softassertion.assertEquals(skuNumber, skuNumberOnDetailPage);
		logger.info("skuNumberOnDetailPage " + skuNumberOnDetailPage);

		String specificSkuQtyOnTransferDetailPage = getSpecificSkuQtyOnTransferDetailPage().substring(4);

		softassertion.assertEquals("1", specificSkuQtyOnTransferDetailPage);
		logger.info("SkuQtyOnTransferDetailPage" + specificSkuQtyOnTransferDetailPage);

		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		clickOnOkButtonOnSuccessfullySubmittedMsg();
		fluentWait(transferNumberOnTransferSummeryPage);
		String transferNumber = getTransferNumberOnTransferSummaryPage().substring(10);
		logger.info("TransferNumber Created is " + transferNumber);
		clickOnTransferHome();
		softassertion.assertAll();
		return transferNumber;

	}

	public String getAddedSkuNumber() {
		return getText(addedSkuNumber);
	}
	public String getAddedSkuDescription() {
		return getText(addedSkuDescription);
	}

	public String validateMsgToEnterRecevingStoreNumber() {
		return getText(enterRecevingStoreNumber);
	}

	public String createTransferAndFetchTransferId(String storeNumber, String skuNumber) {
		clickOnTransfer();
		enterReceivingStoreNumber(storeNumber);
		clickOnEnter();
		clickOnPlusSign();
		enterSkuNumber(skuNumber);
		clickSearchButton();
		clickAddButtonOnBottom();
		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		clickOnOkButtonOnSuccessfullySubmittedMsg();
		clickOnTransferHome();
		clickOnfirstTransferNumberOnSendSendTransfer();

		String newTranferID = getTransferNoOnTransferDetailPage().substring(10);
		System.out.println(newTranferID);
		return newTranferID;

	}

	// By oviya

	public String getTransferNumberOnHomeScreen() {
		return getText(transferNumberHome);
	}

	// created By oviya for SRA-1219

	public String CreatedTransferOrderIsDisplayedInHomePage() throws InterruptedException {
		clickOnOkButtonOnSuccessfullySubmittedMsg();
		Thread.sleep(15000);
		fluentWait(transferNumberOnTransferSummeryPage);
		String transferNumber = getTransferNumberOnTransferSummaryPage().substring(10);

		clickOnTransferHome();
		elementClick(transferNumberSearchBar);
		setText(searchBarTextBox, transferNumber);
		clickSearchButton();
		String TransferNumberOnHomeScreen = getTransferNumberOnHomeScreen().substring(10);
		softassertion.assertEquals(transferNumber, TransferNumberOnHomeScreen);
		return TransferNumberOnHomeScreen;

	}

	// created By oviya

	public void ValidateIfCreatedTransferOrderIsUpdated() {
		clickOnOkButtonOnSuccessfullySubmittedMsg();
		clickOnTransferHome();
		String skuQtyOnTransferHome = getSkuQtyOntransferHome();
		Assert.assertEquals("1", skuQtyOnTransferHome);
		String destinationStoreNoOnTransferHome = getDestinationStoreNumberOnTransferHome();
		Assert.assertEquals("2", destinationStoreNoOnTransferHome);

	}

	public String getDestinationStoreNumberOnTransferHome() {
		return getText(ToStoreNumber);
	}
	public String getStoreConceptOnTransferHome() {
		return getText(ToStoreNumber).substring(0, 2);
	}


	public String getSkuQtyOntransferHome() {
		return getText(totalskuQtyHome);
	}

	// created by oviya
	public String createTransfer(String storeNumber, String skuNumber, SoftAssert localassert) throws ParseException {
		clickOnTransfer();
		String enterStoreNumberMessage=captureEnterStoreNumberMessage();
		localassert.assertEquals(enterStoreNumberMessage, "Please enter valid receiving store number");
		logger.info("Displayed Message is --> " +enterStoreNumberMessage);
		enterReceivingStoreNumber(storeNumber);
		clickOnEnter();
		String defaultMessage=captureDefaultMessageInSendTransfersPage();
		localassert.assertEquals(defaultMessage, "Start scanning SKU labels to add to transfer order");
		logger.info("Displayed Message is --> " +defaultMessage);
		clickOnPlusSign();
		String addSkuHeading=captureAddSkuHeading();
		localassert.assertEquals(addSkuHeading, "Add SKU to Store Transfer");
		logger.info("Displayed Heading is --> " +addSkuHeading);
		enterSkuNumber(skuNumber);
		clickSearchButton();
		String skuDescription=captureSkuDescriptionInAddSkuPage();
		clickAddButtonOnBottom();
		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		return skuDescription;
}
	public String captureSkuDescriptionInAddSkuPage() {
		return getText(addedSkuDescription);
}
	public String captureAddSkuHeading() {
		return getText(addSkuHeading);
}
	public String captureEnterStoreNumberMessage() {
		return getText(enterStoreNumberMessage);
}
	
	public String captureDefaultMessageInSendTransfersPage() {
		return getText(defaultMessage);
}

	public String SubmittedMessage() {
		return getText(transferOrderSuccessfullySubmittedMsg);
}

	// By oviya

	public void clickOnfirstTransferNumberOnSendSendTransfer() {
		driver.findElements(transferNoOnTransferSummery).get(0).click();
	}

	// By oviya
	public void TransferOrderCanNotBeEditedOnceSubmitted(String transferNumberCreated) {
		searchForTransferNumber(transferNumberCreated);
		clickOnfirstTransferNumberOnSendSendTransfer();
		AddIconIsNotDisplayed();
		SubmitButtonIsNotDisplayed();

	}

	// By oviya
	public void SubmitButtonIsNotDisplayed() {
		clickOnTransferSummery();
		boolean submitButtonNotfound = isDisplayedWithoutWait(submit);
		System.out.println(submitButtonNotfound);
		Assert.assertFalse(submitButtonNotfound);

	}

	// By oviya
	public void AddIconIsNotDisplayed() {
		boolean plusSignNotfound = isDisplayedWithoutWait(plusSignBtnToAddSku);
		System.out.println(plusSignNotfound);
		Assert.assertFalse(plusSignNotfound);
	}

	public String getPrintedDateOnTransferSummery() {
		return getText(createdOnDateOnTransferSummery);
	}

	public void validateTheTransferCreatedOnTransferHome(String storeNumber, String skuNumber) {

		clickOnTransfer();
		enterReceivingStoreNumber(storeNumber);
		clickOnEnter();
		clickOnPlusSign();
		enterSkuNumber(skuNumber);
		clickSearchButton();
		clickAddButtonOnBottom();
		clickOnTransferSummery();
		clickOnSubmitTransferSummery();

		String SubmittedMessage = validateSubmitMsg();
		Assert.assertEquals(SubmittedMessage, "Transfer Order Submitted Successfully");

		clickOnOkButtonOnSuccessfullySubmittedMsg();
		clickOnTransferHome();
		clickOnfirstTransferNumberOnSendStoreTransfer();
		clickOnTransferSummery();

	}

	public String createTransferforMultipleSkuQTYValidation(String storeNumber, String skuNumber1, String skuNumber2)
			throws InterruptedException {

		clickOnTransfer();
		enterReceivingStoreNumber(storeNumber);
		clickOnEnter();
		clickOnPlusSign();
		enterSkuNumber(skuNumber1);

		clickSearchButton();
		clickAddButtonOnBottom();

		clickOnPlusSign();
		enterSkuNumber(skuNumber2);

		clickSearchButton();
		clickAddButtonOnBottom();

		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		clickOnOkButtonOnSuccessfullySubmittedMsg();

		fluentWait(transferNumberOnTransferSummeryPage);
		String transferNumber = getTransferNumberOnTransferSummaryPage().substring(10);
		logger.info("TransferNumber Created is " + transferNumber);
		clickOnTransferHome();
		return transferNumber;

	}

	/*
	 * public void createTransferforMultipleSkuQTYValidation(String storeNumber)
	 * {
	 * 
	 * clickOnTransfer(); enterReceivingStoreNumber(storeNumber);
	 * clickOnEnter(); clickOnPlusSign(); enterSkuNumber("5739995");
	 * clickSearchButton(); clickAddButtonOnBottom();
	 * 
	 * clickOnPlusSign(); enterSkuNumber("1023998"); clickSearchButton();
	 * clickAddButtonOnBottom();
	 * 
	 * clickOnTransferSummery(); clickOnSubmitTransferSummery();
	 * clickOnOkButtonOnSuccessfullySubmittedMsg(); clickOnTransferHome();
	 * 
	 * }
	 */

	public String getSpecificSkuQtyOnTransferDetailPage() {
		return getText(specificSkuQty);
	}
	// public List<WebElement> getSpecificSkuValueOnTransferDetailPage() {
	//
	//
	// List<WebElement>
	// skuNumbers=driver.findElements(By.id("com.si:id/liSendST_SKUDetails_SKUNo"));
	// //for(int i=0; i)
	//
	//
	//
	// }
	//

	public String getSKuQty() {
		return getText(qtyOnSkuDetails);
	}

	public String getSkuNumber() {
		return getText(SkuWithTransferNumber);

	}

	public void clickOnTransferNumber() {
		multipleElementClick(transferNumberHome, 0);
	}

	public String getSkuNoOnTransferDetailPage() {
		return getText(skuNumberOnTransferDetailPage);
	}

	// added by ruthra
	// public String getStoreNumberOntransferHomePage() {
	// return driver.findElements(storeNumberHome).get(0).getText();
	//
	// }

	// added by ruthra
	// public String getSkuQtyOntransferHomePage() {
	// return driver.findElements(totalskuQtyHome).get(0).getText();
	// }

	// added by ruthra
	public String getTransferNoOnTransferDetailPage() {
		return getText(transferNumber);
	}

	// added by ruthra
	public String getTotalQtyOnTransferDetailPage() {
		return getText(totalskuQty);
	}

	// added by ruthra
	public List<MobileElement> getQtyOnTransferDetailPage() {
		return getListText(specificSkuQty);
	}

	// added by ruthra
	public boolean IsGoBackDisplayed() {
		return isDisplayed(goBackButton);
	}

	// added by ruthra
	public boolean IsTickMarkDisplayed() {
		return isDisplayed(tickMark);
	}

	// added by ruthra
	public boolean IsTransferDisplayed() {
		return isDisplayed(transfer);
	}

	public String getSkuQtyOntransferHomePage() {
		return driver.findElements(totalSkuQtyHome).get(0).getText();
	}

	public ArrayList<MobileElement> getSpecificSkuNumberListOnTransferDetailPage() {
		return (ArrayList<MobileElement>) getListText(specificskuNumberList);
	}

	/*
	 * // used for Ruthra test case 786 public void
	 * createTransferforSingleSkuQTYValidation(String storeNumber, String
	 * skuNumber) {
	 * 
	 * clickOnTransfer(); enterReceivingStoreNumber(storeNumber);
	 * clickOnEnter(); clickOnPlusSign(); enterSkuNumber(skuNumber);
	 * clickSearchButton(); clickAddButtonOnBottom(); clickOnTransferSummery();
	 * clickOnSubmitTransferSummery();
	 * 
	 * clickOnOkButtonOnSuccessfullySubmittedMsg(); clickOnTransferHome();
	 * clickOnfirstTransferNumberOnSendStoreTransfer();
	 * 
	 * }
	 */

	// added by ruthra used for SRA149
	public String createTransferforSingleSku(String storeNumber, String Sku) throws InterruptedException {

		clickOnTransfer();
		enterReceivingStoreNumber(storeNumber);
		clickOnEnter();
		clickOnPlusSign();
		enterSkuNumber(Sku);
		clickSearchButton();
		clickAddButtonOnBottom();
		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		clickOnOkButtonOnSuccessfullySubmittedMsg();
		fluentWait(transferNumberOnTransferSummeryPage);
		String transferNumber = getTransferNumberOnTransferSummaryPage().substring(10);
		logger.info("TransferNumber Created is " + transferNumber);
		clickOnTransferHome();
		return transferNumber;

	}

	public String getTransferNumberOnTransferSummaryPage() {
		return getText(transferNumberOnTransferSummeryScreen);
	}

	public String createTransferToValidateInReceivingTransfer(String storeNumber, String skuNumber) {

		clickOnTransfer();
		enterReceivingStoreNumber(storeNumber);
		clickOnEnter();
		clickOnPlusSign();
		enterSkuNumber(skuNumber);

		clickSearchButton();

		clickAddButtonOnBottom();
		clickOnTransferSummery();
		clickOnSubmitTransferSummery();

		clickOnOkButtonOnSuccessfullySubmittedMsg();
		String transferNumber = getTransferNumberOnTransferSummaryPage().substring(10);

		clickOnTransferHome();
		return transferNumber;

	}

	public String getTransferNoOnTransferHome() {
		return driver
				.findElements(By
						.xpath("//android.widget.TextView[@resource-id='com.si:id/listSendST_TransferList_TransferNo']"))
				.get(0).getText();

	}

	public String validateSubmitMsg() {

		return getText(transferOrderSuccessfullySubmittedMsg);
	}

	public void clickOnTheNewTransferOnTransferHome() {
		elementClick(transferNumberHome);

	}

	public List<MobileElement> getSpecificSkuQtyListOnTransferDetailPage() {
		return getListText(specificSkuQty);
	}

	// used By Harmeet to see recently submitted transfer detail
	public String getTransferNumberOnHomePage() {
		return driver.findElements(transferNumberHome).get(0).getText();

	}

	public void clickOnTransferHome() {
		elementClick(transferHomeBtn);
		fluentWait(transferNumberHome);
		
	}

	public String getSkuQtyOnTransferSummery() {
		return getText(totalSentSkuQtyOnTransferSummery);
	}

	public String getDestinationStoreNumberOnTransferSummery() {
		return getText(destinationStoreNumber);
	}

	public String getcreatedOnDateOnTransferSummery() {
		return getText(createdOnDateOnTransferSummery);

	}

	public void clickOnTransferInProgress() {
		elementClick(transferOrderinProgress);
	}

	public void clickOnTransferSummery() {
		elementClick(transferSummery);
	}

	public void clickOnSubmitTransferSummery() {
		elementClick(submitTransferSummery);
	}

	public void clickOnOkButtonOnSuccessfullySubmittedMsg() {
		elementClick(OkButtonAfterSucceesfullMsg);
	}

	public void clickOnfirstTransferNumberOnSendStoreTransfer() {
		driver.findElements(transferNoOnTransferSummery).get(0).click();
		// String getTransferNumber= getText(transferNoOnTransferSummery);
		// System.out.println(getTransferNumber);
	}

	public void enterSendStoreTransferNo() {

	}

	public void validateTheTransferSummeryDetail(String transferNumber) {
		SoftAssert softassertion=new SoftAssert();
		searchForTransferNumber(transferNumber);
		elementClick(transferNumberHome);
		clickOnTransferSummery();

		String skuQtyOnTransferSummery = getSkuQtyOnTransferSummery();
		softassertion.assertEquals(skuQtyOnTransferSummery, "3");

		 String destinationStoreNoOnTransferSummery =getDestinationStoreNumberOnTransferSummery();
		 
		 softassertion.assertEquals("WS 2", destinationStoreNoOnTransferSummery);

		String transferNo = getTransferNumberOnTransferSummaryPage().substring(10);
		softassertion.assertEquals("212343", transferNo);
		softassertion.assertAll();
		

	}

	public String getTotalQty() {
		return getText(totalSquQtyOnTransferSummeryScreen);
	}

	public String getDestinationStoreNumber() {
		return getText(destinationStoreNumberOnTransferSummeryScreen);

	}

	public String getTransferNumber() {
		return getText(transferNumberOnTransferSummery);

	}

	public boolean searchForTransferNumber(String sendTransferNumber) {
		elementClick(transferNumberSearchBar);
		setText(searchBarTextBox, sendTransferNumber);
		clickSearchButton();
		return isDisplayed(transferNumberOnTransferSummery);
	}

	public boolean transferNumberLabelDisplayed() {
		return isDisplayed(transferNumberLabel);
	}

	public boolean totalQtyZeroByDefaultDisplayed() {
		return isDisplayed(totalQtyZeroByDefault);
	}

	public String captureAlertMessageForZeroQty() {
		return getText(alertPopUpForZeroQty);
	}
	public void clickOnOkForAlertPopUp() {
		elementClick(okButtonAlertPopUp);
	}
	public String validateMsgToStartScan() {
		return getText(startScanningSkuLabelsMsg);
	}

	public void initiatePartialSendStoreTransfer(String storeNumber) {
		clickOnTransfer();
		enterReceivingStoreNumber(storeNumber);
		clickOnEnter();

		boolean transferNumberDisplayed = transferNumberLabelDisplayed();
		Assert.assertTrue(transferNumberDisplayed);

		boolean SkuQtyAsZeroDisplayed = totalQtyZeroByDefaultDisplayed();
		Assert.assertTrue(SkuQtyAsZeroDisplayed);

		String msgToStartScan = validateMsgToStartScan();
		Assert.assertEquals("Start scanning SKU labels to add to transfer order", msgToStartScan);

	}

	public void clickOnGoBackButton() {
		elementClick(goBackButton);
	}

	public void initiateTransfer(String storeNumber) throws ParseException {

		clickOnTransfer();
		enterReceivingStoreNumber(storeNumber);
		clickOnEnter();
		clickOnPlusSign();
		enterSkuNumber("5739995");

		clickSearchButton();
		clickAddButtonOnBottom();
		clickOnGoBackButton();

	}

	public void clickOnTransfer() {
		elementClick(transfer);

	}

	public void enterReceivingStoreNumber(String storeNumber) {
		fluentWait(storeNumberToTransfer);
		setText(storeNumberToTransfer, storeNumber);

	}

	public void clickOnEnter() {
		elementClick(enterButton);
		fluentWait(plusSignOnBottom, 20, 2);

	}

	public void clickOnEnterToVerifyErrorMsg() {
		elementClick(enterButton);
	}

	public void clickOnPlusSign() {
		fluentWait(plusSignOnBottom, 20, 2);
		elementClick(plusSignOnBottom);

	}

	public void enterSkuNumber(String skuNumber) {
		// fluentWait(searchButtonOnSkuTransfer);
		elementClick(searchButtonOnSkuTransfer);
		setText(searchBarTextBox, skuNumber);

	}

	public void clickAddButtonOnBottom() {
		fluentWaitForElementToBeEnabled(addButtonOnBottom, 20, 2);
		elementClick(addButtonOnBottom);

	}

	public void clickSearchButton() {

		TouchAction touchAction = new TouchAction(driver);
		touchAction.tap(PointOption.point(700, 1200)).perform();

		// Below coordinates with tap button work with emulator only and not on
		// PDT
		// touchAction.tap(PointOption.point(1000, 1700)).perform();

		// Below tap method with coordinates work with PDT

		// Above method is used to click on the coordinates of search button if
		// in any case that doesnot work , below method can be used which uses
		// the
		// enter button on keyboard(if at all that works)

		// pressEnter();

	}

	public void enter3LastSkuDigits(String skuNumber) {

		setText(enter3SkuDigit, skuNumber.substring(skuNumber.length() - 3, skuNumber.length()));
	}

	public boolean transferOrderisDisplayed() {
		return isDisplayed(transferOrderinProgress);
	}
	
	public void clickOnTransferCancelButton() {
		logger.info("Clicking on cancel Button");    
		elementClick(cancelTransferButton);

	}
	
	public String getTransferCancelAlertPopUpMessage() {
		return getText(alertPopUpMsg);
	}
	
	public void clickOnNoButton() {
		logger.info("Clicking on NO Button in alert POPUP page");    
		elementClick(alertPopUpNoBtn);

	}
	
	public void clickOnYesButton() {
		logger.info("Clicking on Yes Button in alert POPUP page");    
		elementClick(alertPopUpYesBtn);

	}
	
	public String getErrorPopUpMessage() {
		return getText(alertMessagePopup);
	}
	
	public void clickOnInProgressTransfer() {
		logger.info("Clicking on In Progress Transfer");    
		elementClick(transferInProgressMsg);

	}

	// Created By OVI for SRA-1218
	public void editSkuQtyForNewTransfer(String destinationStore, String skuQty) {
		clickOnTransfer();
		enterReceivingStoreNumber(destinationStore);
		clickOnEnter();
		clickOnAddSku();
		enterSkuNumber("6999788");
		clickSearchButton();
		clickAddButtonOnBottom();
		clickOnSkuNumberOnTransferDetailPage();
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnEditButton();
		setSkuQty(skuQty);
		logger.info("Edited Sku Qty is------> " + skuQty);
		clickOnSaveButton();
		String EditedSkuQty = getSkuQtyOntransferDetailpage();
		logger.info("Saved Sku Qty is------> " + skuQty);
		Assert.assertEquals(skuQty, EditedSkuQty);
	}

	public void validateAbleToEditReceivedQtyUpTo99(String skuQty) {
		clickOnSkuNumberOnTransferDetailPage();
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnEditButton();
		setSkuQty(skuQty);
		logger.info("Edited Sku Qty is------> " + skuQty);
		clickOnSaveButton();
		String EditedSkuQty = getSkuQtyOntransferDetailpage();
		logger.info("Saved Sku Qty is------> " + EditedSkuQty);
		Assert.assertEquals(skuQty, EditedSkuQty);
	}
	public void validateErrorMessageForReceivedQty0(String skuQty) {
		clickOnSkuNumberOnTransferDetailPage();
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnEditButton();
		setSkuQty(skuQty);
		logger.info("Edited Sku Qty is------> " + skuQty);
		clickOnSaveButton();
		String AlertMessage=captureAlertMessageForZeroQty();
		Assert.assertEquals(AlertMessage, "Please enter valid SKU Quantity");
		logger.info("Displayed Alert message is------> " + AlertMessage);
		clickOnOkForAlertPopUp();
		clickOnCancelButton();
	}

	public void validateNotAbletoEditReceivedQtyAbove99(String skuQty) {
		clickOnSkuNumberOnTransferDetailPage();
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnEditButton();
		setSkuQty(skuQty);
		logger.info("Edited Sku Qty is------> " + skuQty);
		int sizeOfReceivedQty = getText(editskuqty).length();
		logger.info("Length of received SKU QTY entered------> " + sizeOfReceivedQty);
		assertEquals(2, sizeOfReceivedQty);
		clickOnCancelButton();
	}

	public String cancelEditSkuQtyForNewTransfer(String skuNumber) {
		String skuQtyBeforeEditing = getSkuQtyOntransferDetailpage();
		logger.info("Saved Sku Qty is------> " + skuQtyBeforeEditing);
		clickOnSkuNumberOnTransferDetailPage();
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnEditButton();
		setSkuQty(skuNumber);
		logger.info("Canceled Sku Qty is------> " + skuNumber);
		clickOnCancelButton();
		String EditedSkuQty = getSkuQtyOntransferDetailpage();
		logger.info("Saved Sku Qty is------> " + EditedSkuQty);
		Assert.assertEquals(skuQtyBeforeEditing, EditedSkuQty);
		elementClick(gobackBtnOnSkuDetails);
		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		clickOnOkButtonOnSuccessfullySubmittedMsg();
		fluentWait(transferNumberOnTransferSummeryPage);
		String transferNumber = getTransferNumberOnTransferSummaryPage().substring(10);
		logger.info("TransferNumber Created is " + transferNumber);
		return transferNumber;
	}

	public void clickOnSkuNumberOnTransferDetailPage() {
		elementClick(skuNumberOnTransferDetailPage);
	}

	public void clickOnAddSku() {
		fluentWait(plusSignBtnToAddSku, 20, 5);
		elementClick(plusSignBtnToAddSku);

	}

	public void clickOnCancelButton() {
		elementClick(cancelbutton);
	}

	public void clickOnSaveButton() {
		elementClick(savebutton);
	}

	public void clickOnEditButton() {
		elementClick(editicon);
	}

	public void setSkuQty(String skuqty) {
		fluentWait(editskuqty);
		elementClick(editskuqty);
		clearTextField(editskuqty);
		setText(editskuqty, skuqty);
		clickSearchButton();
	}

	public String createTransferforSingleSkuwithQty(String storeNumber, String Sku, String skuQty)
			throws InterruptedException {

		clickOnTransfer();
		enterReceivingStoreNumber(storeNumber);
		clickOnEnter();
		clickOnPlusSign();
		enterSkuNumber(Sku);
		clickSearchButton();
		clickAddButtonOnBottom();
		editSkuQuantity(skuQty);
		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		clickOnOkButtonOnSuccessfullySubmittedMsg();
		fluentWait(transferNumberOnTransferSummeryPage);
		String transferNumber = getTransferNumberOnTransferSummaryPage().substring(10);
		System.out.println("TransferNumber " + transferNumber);
		clickOnTransferHome();
		return transferNumber;

	}

	public void editSkuQuantity(String skuQty) {
		clickOnSkuNumberOnTransferDetailPage();
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnEditButton();
		setSkuQty(skuQty);
		clickOnSaveButton();
		elementClick(gobackBtnOnSkuDetails);
	}

	public String createTransferforMultipleSkuWithQty(String storeNumber, String skuNumber1, String skuNumber2,
			String skuQty) throws InterruptedException {

		clickOnTransfer();
		enterReceivingStoreNumber(storeNumber);
		clickOnEnter();
		clickOnPlusSign();
		enterSkuNumber(skuNumber1);
		clickSearchButton();
		clickAddButtonOnBottom();
		editSkuQuantity(skuQty);
		clickOnPlusSign();
		enterSkuNumber(skuNumber2);
		clickSearchButton();
		clickAddButtonOnBottom();

		clickOnTransferSummery();
		clickOnSubmitTransferSummery();
		clickOnOkButtonOnSuccessfullySubmittedMsg();

		fluentWait(transferNumberOnTransferSummeryPage);
		String transferNumber = getTransferNumberOnTransferSummaryPage().substring(10);
		System.out.println("TransferNumber " + transferNumber);
		clickOnTransferHome();
		return transferNumber;

	}

	public String getTotalSkuQtyFromTransferSummaryPage(String transferNumberCreated) {
		elementClick(transferNumberSearchBar);
		setText(searchBarTextBox, transferNumberCreated);
		clickSearchButton();
		clickOnTransferNumber();
		clickOnTransferSummery();
		String skuQtyOnTransferSummery = getSkuQtyOnTransferSummery();
		return skuQtyOnTransferSummery;
	}

	//// added by ruthra used for SRA786
	public void validationInTransferDetailPageForSingleSku(SoftAssert softassertion) {
		clickOnfirstTransferNumberOnSendStoreTransfer();
		softassertion.assertTrue(IsGoBackDisplayed());
		softassertion.assertTrue(IsTickMarkDisplayed());

		String transferNumLabel = getTransferNoOnTransferDetailPage().substring(0, 5);
		softassertion.assertEquals(transferNumLabel, "Trans");

		String totalQtyLabel = getTotalQtyOnTransferDetailPage().substring(0, 9);
		softassertion.assertEquals(totalQtyLabel, "TOTAL QTY");

		String specificSkuQtyOnTransferDetailPage = getSKuQty();
		softassertion.assertEquals(specificSkuQtyOnTransferDetailPage, "QTY 1");

		String skuNumber = getSkuNumber();
		softassertion.assertEquals(skuNumber, "SKU# 5739995");
		
	}

	// added by ruthra used for SRA786
	public void validationInTransferDetailPageForMultipleSku(String transferNumberCreated, String skuNumber1,
			String skuNumber2,SoftAssert softassertion) {
		String transferNumberHomePage = getTransferNumberOnHomePage();
		String totalSkuQtyHomePage = getSkuQtyOntransferHomePage();

		softassertion.assertEquals(totalSkuQtyHomePage, "2");
		clickOnfirstTransferNumberOnSendStoreTransfer();

		String transferNumberTransferDetailPage = getTransferNoOnTransferDetailPage().substring(10);
		String transferNumberHomeSubstring = transferNumberHomePage
				.substring(transferNumberHomePage.lastIndexOf(transferNumberTransferDetailPage));
		softassertion.assertEquals(transferNumberHomeSubstring, transferNumberTransferDetailPage);

		String totalSkuQtyTransferDetailPage = getTotalQtyOnTransferDetailPage().substring(10);
		softassertion.assertEquals(totalSkuQtyTransferDetailPage, totalSkuQtyHomePage);

		String totalQtyLabel = getTotalQtyOnTransferDetailPage();
		softassertion.assertEquals(totalQtyLabel, "TOTAL QTY 2");

		List<MobileElement> specificSkuQtyListOnTransferDetailPage = getSpecificSkuQtyListOnTransferDetailPage();
		int specificSkuQtySum = 0;
		for (int j = 0; j < specificSkuQtyListOnTransferDetailPage.size(); j++) {
			String specificSkuQty = specificSkuQtyListOnTransferDetailPage.get(j).getText().substring(4);
			int i = Integer.parseInt(specificSkuQty);
			specificSkuQtySum = specificSkuQtySum + i;
		}

		String specificSkuqtySumString = String.valueOf(specificSkuQtySum);
		softassertion.assertEquals(specificSkuqtySumString, totalSkuQtyTransferDetailPage);

		ArrayList<MobileElement> specificSkuNumberListOnTransferDetailPage = getSpecificSkuNumberListOnTransferDetailPage();
		String specificSkuNumberOnTransferDetailPage1 = specificSkuNumberListOnTransferDetailPage.get(0).getText().substring(5);
		softassertion.assertEquals(specificSkuNumberOnTransferDetailPage1, skuNumber1);
		String specificSkuNumberOnTransferDetailPage2 = specificSkuNumberListOnTransferDetailPage.get(1).getText().substring(5);
		softassertion.assertEquals(specificSkuNumberOnTransferDetailPage2, skuNumber2);
		
	}

	// added by ruthra used for SRA786
	public void validateSkuDetailPageForSingleSku(String skuNumber, String transferNumberCreated,SoftAssert softassertion) {
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		// String transferNumberHomePage = getTransferNumberOnHomePage();
		// clickOnfirstTransferNumberOnSendStoreTransfer();

		String skuNoOnTransferDetailPage = getSkuNoOnTransferDetailPage().substring(5);
		String specificSkuQtyOnTransferDetailPage = getSpecificSkuQtyOnTransferDetailPage().substring(4);

		// String transferNumberHomePageSubstring = transferNumberHomePage.substring(10);
		clickOnSkuNumberOnTransferDetailPage();
		String transferNumberOnSkuDetailPage = skuDetailTransferPage.getTransferNumberOnSkuDetailPage().substring(10);
		softassertion.assertEquals(transferNumberCreated, transferNumberOnSkuDetailPage);

		String skuNumberOnSkuDetailPage = skuDetailTransferPage.getSkuNumberOnSkuDetailPage();
		softassertion.assertEquals(skuNumberOnSkuDetailPage, skuNumber);
		softassertion.assertEquals(skuNumberOnSkuDetailPage, skuNoOnTransferDetailPage);

		String skuQtyOnSkuDetailPage = skuDetailTransferPage.getskuQtyOnSkuDetailPage();
		softassertion.assertEquals(skuQtyOnSkuDetailPage, specificSkuQtyOnTransferDetailPage);
		softassertion.assertEquals(skuQtyOnSkuDetailPage, "1");
		
		logger.info("To validate the sku labels displayed in the sku detail page");
		validateSkuLabel(softassertion);
		
		clickOnGoBackButtonInSkuDetailPage();
		String toolbarHeading=sendnReceivetransfer.captureStoreTransfersHeader();
		softassertion.assertEquals(toolbarHeading, "SENDING");
		logger.info(toolbarHeading +" Heading is Displayed");
		
		
	}

	
	private void clickOnGoBackButtonInSkuDetailPage() {
		elementClick(gobackBtnOnSkuDetails);
		
	}

	private void validateSkuLabel(SoftAssert softassertion) {
		boolean isTransferLabelDisplayed = isDisplayed(transferNumberOnSkuDetailPage);
		softassertion.assertTrue(isTransferLabelDisplayed);
		
		boolean isSkuLabelDisplayed = isDisplayed(skuLabel);
		softassertion.assertTrue(isSkuLabelDisplayed);
		
		boolean isSkuDescLabelDisplayed = isDisplayed(skuDescLabel);
		softassertion.assertTrue(isSkuDescLabelDisplayed);
		
		boolean isSkuQtyLabelDisplayed = isDisplayed(skuQtyLabel);
		softassertion.assertTrue(isSkuQtyLabelDisplayed);

		logger.info("All the sku labels are displayed in the sku detail page");	
		
	}

	// added by ruthra used for SRA786
	public void validateSkuDetailPageForMultipleSku(SoftAssert softassertion ) {

		//clickOnfirstTransferNumberOnSendStoreTransfer();

		ArrayList<MobileElement> specificSkuNumberListOnTransferDetailPage = getSpecificSkuNumberListOnTransferDetailPage();
		for (int i = 0; i < specificSkuNumberListOnTransferDetailPage.size(); i++) {
			specificSkuNumberListOnTransferDetailPage = null;
			specificSkuNumberListOnTransferDetailPage = getSpecificSkuNumberListOnTransferDetailPage();
			String specificSkuNumberOnTransferDetailPage = specificSkuNumberListOnTransferDetailPage.get(i).getText()
					.substring(5);
			logger.info("SkuNumberOnTransferDetailPage " + specificSkuNumberOnTransferDetailPage);

			List<MobileElement> specificSkuQtyListOnTransferDetailPage = getSpecificSkuQtyListOnTransferDetailPage();
			String specificSkuQtyOnTransferDetailPage = specificSkuQtyListOnTransferDetailPage.get(i).getText()
					.substring(4);
			logger.info("SkuQtyOnTransferDetailPage" + specificSkuQtyOnTransferDetailPage);

			specificSkuNumberListOnTransferDetailPage.get(i).click();

			String skuNumberOnSkuDetailPage = skuDetailTransferPage.getSkuNumberOnSkuDetailPage();
			logger.info("SKU Number in Sku Detail Page" + skuNumberOnSkuDetailPage);
			softassertion.assertEquals(specificSkuNumberOnTransferDetailPage, skuNumberOnSkuDetailPage);

			String skuQtyOnSkuDetailPage = skuDetailTransferPage.getskuQtyOnSkuDetailPage();
			softassertion.assertEquals(specificSkuQtyOnTransferDetailPage, skuQtyOnSkuDetailPage);

			skuDetailTransferPage.clickGobackBtnOnSkuDetailPage();
			
		}
	}

	public void validateStoreConceptForSameBrandInSendStoreTransfersScreen(String TransferNumber, String wsStoreConcept) {
		searchForTransferNumber(TransferNumber);
		String capturedStoreConcept=getStoreConceptOnTransferHome();
		Assert.assertEquals(capturedStoreConcept, wsStoreConcept);
		logger.info("Destinationstore Store concept is " + capturedStoreConcept);
		
	}

	public void validateStoreConceptForCrossBrandInSendStoreTransfersScreen(String TranferNumber, String StoreConcept) {
		searchForTransferNumber(TranferNumber);
		String capturedStoreConcept=getStoreConceptOnTransferHome();
		Assert.assertEquals(capturedStoreConcept, StoreConcept);
		logger.info("Destinationstore Store concept is " + capturedStoreConcept);
	}

	public void validateButtonsInTransferSummaryPage(SoftAssert localassert) {
		clickOnOkButtonOnSuccessfullySubmittedMsg();
		localassert.assertFalse(isDisplayedWithoutWait(continueScanningTransferSummery));
		localassert.assertFalse(isDisplayedWithoutWait(submitTransferSummery));
		}
	public void validateDetailsOfCreatedTransferInHomepageForRTVStores(SoftAssert softassert, String transferNumberCreated, String toStoreNumber) {
		validateLabelsInSendStoreTransfersHomePage(softassert);
		String DisplayedTransferNumber=getTransferNumberOnHomeScreen().substring(10);
		logger.info("Displayed Transfer Number is---> "+DisplayedTransferNumber);
		softassert.assertEquals(DisplayedTransferNumber, transferNumberCreated);
		String DisplayedToStore=getDestinationStoreNumberOnTransferHome();
		softassert.assertEquals(toStoreNumber, DisplayedToStore);
		logger.info("Displayed To Store Number is---> "+DisplayedToStore);
		
		String DisplayedTotalSkuQTY=getSkuQtyOntransferHome();
		softassert.assertEquals(DisplayedTotalSkuQTY, "1");
		logger.info("Displayed Total Sku Qty is---> "+DisplayedTotalSkuQTY);
	}
	

	public void validateLabelsInSendStoreTransfersHomePage(SoftAssert softassert) {
        logger.info("To Validate if all the labels are displayed in the home page");
		
	    boolean isToStoreLabelDisplayed = isDisplayed(toStoreLabel);
		softassert.assertTrue(isToStoreLabelDisplayed);
		
		boolean isTotalSkuQtyLabelDisplayed = isDisplayed(totalskuQtyLabel);
		softassert.assertTrue(isTotalSkuQtyLabelDisplayed);
		
		logger.info("All the labels are displayed in the Home Page");
	}
	
    public void scrollInSendTransferHomePage(){
		
		MobileElement element=driver.findElementByClassName("android.support.v7.widget.RecyclerView");
		
		 String isScrollable=element.getAttribute("scrollable");
         logger.info("Scrollable flag for SendTransfer HOMEPAGE is :"+isScrollable);
         assertEquals(isScrollable, "true");
         
         List<MobileElement> transferNumberList=driver.findElementsById("com.si:id/listSendST_TransferList_TransferNo");
         
         boolean isScrolled= scrollDownByElement(transferNumberList);
         assertTrue(isScrolled);
	}
	
	public void scrollInSendTransferDetailPage(String transferNumberCreated){
		
		searchForTransferNumber(transferNumberCreated);
		clickOnTransferNumber();
		
		MobileElement element=driver.findElementByClassName("android.support.v7.widget.RecyclerView");
		
		String isScrollable=element.getAttribute("scrollable");
        logger.info("Scrollable flag for SendTransfer DetailPage is :"+isScrollable);
        assertEquals(isScrollable, "true");
        
        List<MobileElement>  skuNumberListOnTransferDetailPage = getSpecificSkuNumberListOnTransferDetailPage();
        boolean isScrolled= scrollDownByElement(skuNumberListOnTransferDetailPage);
        assertTrue(isScrolled);
        
	}
	
	public void validateSearchExitInSendTransferHomePage(String transferNumber) throws InterruptedException{
    	
		elementClick(transferNumberSearchBar);
		setText(searchBarTextBox, transferNumber);
			
		   boolean keyboardBefore=driver.isKeyboardShown();
			logger.info("Keyboard Displayed flag before search Exit in SendTransfer :"+keyboardBefore);
			
			Thread.sleep(1000);
			TouchAction touchAction = new TouchAction(driver);
			touchAction.tap(PointOption.point(650, 190)).perform();
			
			boolean keyboardAfter=driver.isKeyboardShown();
			logger.info("Keyboard Displayed flag after search Exit in SendTransfer:"+keyboardAfter);
			assertFalse(keyboardAfter);
		
	    }

	public void validateCancelButtonIsEnabledBeforeAddingSku(String storeNumber, String Sku) throws InterruptedException {

		clickOnTransfer();
		enterReceivingStoreNumber(storeNumber);
		clickOnEnter();
		
		boolean isCancelButnDisplayed = isDisplayed(cancelTransferButton);
		Assert.assertTrue(isCancelButnDisplayed);
		
		boolean isCancelButnEnabled=isEnabled(cancelTransferButton);
		Assert.assertTrue(isCancelButnEnabled);
		
		logger.info("Cancel Button is Enabled");            
		
		/*clickOnPlusSign();
		enterSkuNumber(Sku);
		clickSearchButton();
		clickAddButtonOnBottom();*/
		//clickOnTransferSummery();
		
		
		/*clickOnSubmitTransferSummery();
		clickOnOkButtonOnSuccessfullySubmittedMsg();
		fluentWait(transferNumberOnTransferSummeryPage);
		String transferNumber = getTransferNumberOnTransferSummaryPage().substring(10);
		logger.info("TransferNumber Created is " + transferNumber);
		clickOnTransferHome();
		return transferNumber;*/

	}
	
	public void validateSummaryButtonIsDisabledBeforeAddingSku() {
		
		boolean isSummaryButtonNotEnabled=isEnabled(transferSummery);
		Assert.assertFalse(isSummaryButtonNotEnabled,"Summary Button is enabled");
		logger.info("Summary Button is not Enabled");        
		      
	}
	@Step("Check clicking on Yes Button transfer is cancel and Home Page is dispalyed")
	public void cancleTransferBeforeAddingSku() {

		clickOnTransferCancelButton();
		String alertPopupMessage=getTransferCancelAlertPopUpMessage();
		Assert.assertEquals(alertPopupMessage, "This action will discard this Store Transfer. Do you wish to continue?");
		clickOnNoButton();
		boolean isdefaultMsgDispalyed=isDisplayed(startScanningSkuLabelsMsg);
		Assert.assertTrue(isdefaultMsgDispalyed,"Default Message in transfer Page is not Displayed");
		logger.info("Default Message is displayed In Home Page");   
		
		clickOnTransferCancelButton();
		String alertPopupMsg=getTransferCancelAlertPopUpMessage();
		Assert.assertEquals(alertPopupMsg, "This action will discard this Store Transfer. Do you wish to continue?");
		clickOnYesButton();
		logger.info("Check clicking on Yes Button transfer is canceled and Home Page is displayed"); 
		
		boolean isHomePageHeadingDisplayed=isDisplayed(sendTransferHomePageHeading);
		Assert.assertTrue(isHomePageHeadingDisplayed,"Send Store Transfers Heading is not Displayed");
		logger.info("Send Store Transfers Heading is Displayed");  
		
		logger.info("Check transfer In progress message is not displayed in Home Page"); 
		boolean istransferInProgressMsgNotDispalyed =isDisplayedWithoutWait(transferInProgressMsg);
		Assert.assertFalse(istransferInProgressMsgNotDispalyed);
		logger.info("Transfer In Progress Message is not Displayed");  

	}
	
	
	@Step("Check clicking on Yes Button transfer is cancel and Home Page is dispalyed")
	public void cancleTransferAfterAddingSku(String storeNumber, String Sku) {
		clickOnTransfer();
		enterReceivingStoreNumber(storeNumber);
		clickOnEnter();	
		clickOnPlusSign();
		enterSkuNumber(Sku);
		clickSearchButton();
		clickAddButtonOnBottom();
		
		boolean isCancelButtonEnabled=isEnabled(cancelTransferButton);
		Assert.assertTrue(isCancelButtonEnabled);
		logger.info("Cancel Button is Enabled"); 
		
		globalWait();
		boolean isSummaryButtonEnabled=isEnabled(transferSummery);
		Assert.assertTrue(isSummaryButtonEnabled,"Summary Button is not enabled");
		logger.info("Summary Button is Enabled");   
		
		logger.info("Clicking on GoBack Button");   
		clickOnGoBackButton();
		logger.info("Check transfer In progress message is displayed in Home Page"); 
		boolean istransferInProgressMsgDisplayed =isDisplayed(transferInProgressMsg);
		Assert.assertTrue(istransferInProgressMsgDisplayed,"Transfer In Progress Message is not Displayed");
		logger.info("Transfer In Progress Message is Displayed");  
		
		logger.info("Check Not able to Create a new transfer when another trasfer in progress");  
		clickOnTransfer();
		
		String errorMessage=getErrorPopUpMessage();
		Assert.assertEquals(errorMessage, "Please submit pending transfer order before creating a new one");
		logger.info(errorMessage+ " Error Message is Displayed");  
		clickOnOkButtonOnSuccessfullySubmittedMsg();
		
		clickOnInProgressTransfer();
		
		clickOnTransferCancelButton();
		String alertPopupMessage=getTransferCancelAlertPopUpMessage();
		Assert.assertEquals(alertPopupMessage, "This action will discard this Store Transfer. Do you wish to continue?");
		clickOnNoButton();
		boolean isSKUAddedDisplayed=isDisplayed(skuNumberOnTransferDetailPage);
		Assert.assertTrue(isSKUAddedDisplayed,"Added SKU is not displayed");
		logger.info("SKU added is displayed In detail Page");   
		
		clickOnTransferCancelButton();
		String alertPopupMsg=getTransferCancelAlertPopUpMessage();
		Assert.assertEquals(alertPopupMsg, "This action will discard this Store Transfer. Do you wish to continue?");
		clickOnYesButton();
		logger.info("Check clicking on Yes Button transfer is canceled and Home Page is displayed"); 
		
		boolean isHomePageHeadingDisplayed=isDisplayed(sendTransferHomePageHeading);
		Assert.assertTrue(isHomePageHeadingDisplayed,"Send Store Transfers Heading is not Displayed");
		logger.info("Send Store Transfers Heading is Displayed");  
		
		logger.info("Check transfer In progress message is not displayed in Home Page"); 
		boolean istransferInProgressMsgNotDispalyed =isDisplayedWithoutWait(transferInProgressMsg);
		Assert.assertFalse(istransferInProgressMsgNotDispalyed,"Transfer In Progress Message is  Displayed");
		logger.info("Transfer In Progress Message is not Displayed");  
	}
	
	
	@Step("Check clicking on Yes Button transfer is cancel and Home Page is dispalyed for Cross Brand")
	public void cancleTransferAfterAddingSkuForCrossBrand(String storeNumber, String Sku) {
		clickOnTransfer();
		enterReceivingStoreNumber(storeNumber);
		clickOnEnter();	
		clickOnPlusSign();
		enterSkuNumber(Sku);
		clickSearchButton();
		clickAddButtonOnBottom();
		
		boolean isCancelButtonEnabled=isEnabled(cancelTransferButton);
		Assert.assertTrue(isCancelButtonEnabled);
		logger.info("Cancel Button is Enabled");  
		
		boolean isSummaryButtonEnabled=isEnabled(transferSummery);
		Assert.assertFalse(isSummaryButtonEnabled,"Summary Button is not enabled");
		logger.info("Summary Button is Enabled");   
		
		clickOnTransferCancelButton();
		String alertPopupMessage=getTransferCancelAlertPopUpMessage();
		Assert.assertEquals(alertPopupMessage, "This action will discard this Store Transfer. Do you wish to continue?");
		clickOnNoButton();
		boolean isSKUAddedDisplayed=isDisplayed(skuNumberOnTransferDetailPage);
		Assert.assertTrue(isSKUAddedDisplayed,"Added SKU is not displayed");
		logger.info("SKU added is displayed In detail Page");   
		
		clickOnTransferCancelButton();
		String alertPopupMsg=getTransferCancelAlertPopUpMessage();
		Assert.assertEquals(alertPopupMsg, "This action will discard this Store Transfer. Do you wish to continue?");
		clickOnYesButton();
		logger.info("Check clicking on Yes Button transfer is canceled and Home Page is displayed"); 
		
		boolean isHomePageHeadingDisplayed=isDisplayed(sendTransferHomePageHeading);
		Assert.assertTrue(isHomePageHeadingDisplayed,"Send Store Transfers Heading is not Displayed");
		logger.info("Send Store Transfers Heading is Displayed");  
	}
	
	@Step("Check whether submitted transfer cannot be Canceled")
	public String ValidateSubmittedTransferOrder(String storeNumber, String Sku) throws InterruptedException {
		String transferNumber=createTransferforSingleSku(storeNumber, Sku);
		searchForTransferNumber(transferNumber);
		clickOnfirstTransferNumberOnSendSendTransfer();
		
		logger.info("Check Cancel Button is not enabled for submitted transfer"); 
		boolean isCancelButtonNotEnabled=isEnabled(cancelTransferButton);
		Assert.assertFalse(isCancelButtonNotEnabled,"Cancel Button is Enabled");
		logger.info("Cancel Button is not Enabled");  
		
		boolean isSummaryButtonEnabled=isEnabled(transferSummery);
		Assert.assertTrue(isSummaryButtonEnabled,"Summary Button is not enabled");
		logger.info("Summary Button is Enabled");   
		
		logger.info("Clicking on GoBack Button");   
		clickOnGoBackButton();
		return transferNumber;
	}
	
	@Step("Check whether canceled transfer order is not available in DB")
	public void ValidateCanceledTransferOrderInDB(String storeNumber, String Sku, String transferNumber) throws ParseException {
		clickOnTransfer();
		enterReceivingStoreNumber(storeNumber);
		clickOnEnter();	
		clickOnPlusSign();
		enterSkuNumber(Sku);
		clickSearchButton();
		clickAddButtonOnBottom();
		
		boolean isCancelButtonEnabled=isEnabled(cancelTransferButton);
		Assert.assertTrue(isCancelButtonEnabled);
		logger.info("Cancel Button is Enabled"); 
		
		clickOnTransferCancelButton();
		String alertPopupMsg=getTransferCancelAlertPopUpMessage();
		Assert.assertEquals(alertPopupMsg, "This action will discard this Store Transfer. Do you wish to continue?");
		clickOnYesButton();
		logger.info("Check clicking on Yes Button transfer is canceled and Home Page is displayed"); 
		
		boolean isHomePageHeadingDisplayed=isDisplayed(sendTransferHomePageHeading);
		Assert.assertTrue(isHomePageHeadingDisplayed,"Send Store Transfers Heading is not Displayed");
		logger.info("Send Store Transfers Heading is Displayed");
		
		int canceledTransfer=Integer.parseInt(transferNumber)+1;
		mongoDB.validateCanceledTransferInDB(String.valueOf(canceledTransfer), storeNumber);
		
		
	}

	@Step("Check whether transfer Order can be Canceled after Logout")
	public void ValidateCancelTransferOrderAfterLogout(String storeNumber, String Sku) 
	{
	clickOnTransfer();
	enterReceivingStoreNumber(storeNumber);
	clickOnEnter();	
	clickOnPlusSign();
	enterSkuNumber(Sku);
	clickSearchButton();
	clickAddButtonOnBottom();
	
	boolean isCancelButtonEnabled=isEnabled(cancelTransferButton);
	Assert.assertTrue(isCancelButtonEnabled);
	logger.info("Cancel Button is Enabled"); 
	
	globalWait();
	boolean isSummaryButtonEnabled=isEnabled(transferSummery);
	Assert.assertTrue(isSummaryButtonEnabled,"Summary Button is not enabled");
	logger.info("Summary Button is Enabled");   
	
	logger.info("Clicking on GoBack Button");   
	clickOnGoBackButton();
	logger.info("Check transfer In progress message is displayed in Home Page"); 
	boolean istransferInProgressMsgDisplayed =isDisplayed(transferInProgressMsg);
	Assert.assertTrue(istransferInProgressMsgDisplayed,"Transfer In Progress Message is not Displayed");
	logger.info("Transfer In Progress Message is Displayed");  
	
	
	
}
	
	@Step("Check whether transfer Order can be Canceled after Logout")
	public void CancelTransferOrderAfterLogout() 
	{
		clickOnInProgressTransfer();
		
		logger.info("Check clicking on Yes Button transfer is canceled and Home Page is displayed"); 
		clickOnTransferCancelButton();
		String alertPopupMsg=getTransferCancelAlertPopUpMessage();
		Assert.assertEquals(alertPopupMsg, "This action will discard this Store Transfer. Do you wish to continue?");
		clickOnYesButton();
		
		
		boolean isHomePageHeadingDisplayed=isDisplayed(sendTransferHomePageHeading);
		Assert.assertTrue(isHomePageHeadingDisplayed,"Send Store Transfers Heading is not Displayed");
		logger.info("Send Store Transfers Heading is Displayed");  
		
		logger.info("Check transfer In progress message is not displayed in Home Page"); 
		boolean istransferInProgressMsgNotDispalyed =isDisplayedWithoutWait(transferInProgressMsg);
		Assert.assertFalse(istransferInProgressMsgNotDispalyed,"Transfer In Progress Message is  Displayed");
		logger.info("Transfer In Progress Message is not Displayed");  
	}
}
