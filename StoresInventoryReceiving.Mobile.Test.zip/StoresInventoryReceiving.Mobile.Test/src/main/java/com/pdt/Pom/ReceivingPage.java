package com.pdt.Pom;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.web.template.AndroidBasePage;

public class ReceivingPage extends AndroidBasePage {
	final static Logger logger = Logger.getLogger(ReceivingPage.class.getName());
	
	protected By purchaseOrders=By.id("com.si:id/btnRec_Home_PO");
	protected By DcShipment = By.id("com.si:id/btnRec_Home_DCShip");
	protected By StoreToStoreTransfer=By.id("com.si:id/btnRec_Home_ST");
	protected By receivingHomeHeading=By.id("com.si:id/txtToolbarTitle");
	

	public  void clickOnDcShipment() {
		logger.info("Clicking on DC Shipment Button");
		fluentWait(DcShipment);
		elementClick(DcShipment);
	}
	
	public void clickOnStoreToStoreTransfer() {
		logger.info("Clicking on StoreTransfer Button");
		elementClick(StoreToStoreTransfer);
	}
	
	public void clickOnPurchaseOrder() {
		logger.info("Clicking on Purchase Order Button");
		elementClick(purchaseOrders);
	}
	
	public boolean isDcShpmentDisplayed() {
		return isDisplayed(DcShipment);
	}
	
	public boolean isPurchaseOrdersDisplayed() {
		return isDisplayed(purchaseOrders);
	}
	
	public boolean isStoreToStoreTransferDisplayed() {
		return isDisplayed(StoreToStoreTransfer);
	}

	
	
	
	
	
	}
