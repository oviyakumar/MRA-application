package com.web.template;

import static com.util.BaseUtil.makeScreenShot;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.UpdateOptions;
import com.pdt.Pom.HomePage;
import com.util.AndroidDriverConfig;
import com.util.AppiumHandler;
import com.util.DataBase.MongoDBManager;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import ru.yandex.qatools.allure.annotations.Step;

public class BaseTest {

	// private static final Logger LOG = Logger.getLogger(BaseTest.class.getName());

	public String testNgSuiteName;
	public String testNgTestName;
	protected AndroidDriverConfig androidDriverConfig = new AndroidDriverConfig();
	final static Logger logger = Logger.getLogger(BaseTest.class.getName());
	protected AppiumHandler appiumHandler;
	

	@BeforeMethod(alwaysRun = true)
	public void setup() throws IOException {
		androidDriverConfig.clearData();
    }

	@BeforeSuite //@BeforeClass
	public void startTestMRA(final ITestContext testContext) throws Exception {
		//TODO uncomment the following to run appium server programmatically.
       // Before uncommenting appium shoud be installing using node i.e. > npm install -f appium or npm install -g appium 
	  // and ANDRIOD_HOME environment variable needs to be set.
       appiumHandler = new AppiumHandler();
	 appiumHandler.startAppiumServer();

	//	appiumHandler.startServerWithCmd();
		androidDriverConfig.setAndroidDriver();
		testNgSuiteName = testContext.getCurrentXmlTest().getSuite().getName();
		testNgTestName = testContext.getName();
		
	}

	/*
	 * @BeforeSuite public void startTest(final ITestContext testContext) throws
	 * Exception { androidDriverConfig.setAndroidDriver(); testNgSuiteName =
	 * testContext.getCurrentXmlTest().getSuite().getName(); testNgTestName =
	 * testContext.getName();
	 * 
	 * AppiumDriverLocalService
	 * service=AppiumDriverLocalService.buildDefaultService(); service.start();
	 * logger.info("Starting appium server");
	 * 
	 * }
	 */
	
	
	@AfterMethod(alwaysRun = true)
	public void logout(){
		HomePage home=new HomePage();
		
		if(home.isMenuBarDisplayed()){
		home.clickOnMenuBar();
		home.logout();
		logger.info("Logged out successfully");	
		}
		else{
			logger.info("Login Skipped");		
			}
	}
	
	@AfterSuite(alwaysRun = true)
	public void afterSuite() {
		androidDriverConfig.quitDriver();
		//close appium server
       appiumHandler.stopServer();
	//	appiumHandler.stopServerWithCmd();
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		/* Close all JDBC connections */
		MongoDBManager.closeDBConnection();
	}

	@SuppressWarnings("static-access")
	protected String getProperty(String propertyName) {
		return androidDriverConfig.getProperty(propertyName);
	}

	private String getJsonFromFile(String fileName) throws IOException {
		fileName = "/test_baselines/" + fileName;
		URL url = getClass().getResource(fileName);
		File file = new File(url.getPath());
		String jsonString = FileUtils.readFileToString(file, "UTF-8");
		return jsonString;
	}

	protected void updateDocToStoreTransferDb(Document doc) {
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		update(doc, collection);
		logger.info("Record is updated in storeToStore transfer collection ");
	}

	private void update(Document doc, MongoCollection<Document> collection) {
		Bson filter = Filters.eq("_id", doc.getObjectId("_id"));
		UpdateOptions options = new UpdateOptions();
		options.upsert(true);
		collection.replaceOne(filter, doc, options);
	}
	private void updateOrphanCollection(Document doc, MongoCollection<Document> collection) {
		Bson filter = Filters.eq("_id", doc.get("_id"));
		UpdateOptions options = new UpdateOptions();
		options.upsert(true);
		collection.replaceOne(filter, doc, options);
	}

	protected void deleteStoreTransfer(String transferID) {
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		Bson filter = Filters.eq("TransferNumber", transferID);
		collection.deleteOne(filter);
		logger.info("Transfer Number " + transferID + " is deleted from DB");
	}
	protected void deleteOrphanCarton(String createdOrphanCarton) {
		MongoCollection<Document> collection = MongoDBManager.getOrphanCartonCollection();
		Bson filter = Filters.eq("CartonNumber", createdOrphanCarton);
		collection.deleteOne(filter);
		logger.info("Carton Number " + createdOrphanCarton + " is deleted from DB");
	}


	protected void updateTestData(String fileName) throws FileNotFoundException, IOException {
		Document doc = createDocFromFile(fileName);
		updateDocToDb(doc);

	}

	protected void updateDocToDb(Document doc) {
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		update(doc, collection);
		logger.info("Record is updated in Dc Shipment ");
	}

	protected void updateDocInPOCollection(Document doc) {
		MongoCollection<Document> collection = MongoDBManager.getPurchaseOrderCollection();
		update(doc, collection);
		logger.info("Record is updated in PO collection ");

	}
	protected void updateDocInOrphanCartonCollection(Document doc) {
		MongoCollection<Document> collection = MongoDBManager.getOrphanCartonCollection();
		updateOrphanCollection(doc, collection);
		logger.info("Record is updated in orphan carton collection ");

	}
	protected void updateDocInStoreCollection(Document doc) {
		MongoCollection<Document> collection = MongoDBManager.getInStoreDamageCollection();
		update(doc, collection);
		logger.info("Record is updated in In-Store Damages collection ");

	}
	protected void updateDocInPLUCollection(Document doc) {
		MongoCollection<Document> collection = MongoDBManager.getPLUCollection();
		update(doc, collection);
		logger.info("Record is updated in PLU collection ");
	}
	

	protected Document createDocFromFile(String fileName) throws IOException {
		String jsonString = getJsonFromFile(fileName);
		Document doc = Document.parse(jsonString);
		logger.info("JSON document is created ");
		return doc;
	}
	
	public static final void makeScreenCapture(final String fileName, final AndroidDriver<MobileElement> md) {

		if (md != null) {
		makeScreenShot(fileName, md);
		} else {
		logger.error("Can't create screenshot [" + fileName + "], MobileDriver [null]");
		}
		}

	
	@Step("Get the filePath")
	public String getImageFilePath(String fileName){
		fileName = "/image/" + fileName;
		URL url = getClass().getResource(fileName);
		File file = new File(url.getPath());
		String filePath = file.getAbsolutePath();
		logger.info("filePath "+filePath);
		return filePath;
	}
	

}
